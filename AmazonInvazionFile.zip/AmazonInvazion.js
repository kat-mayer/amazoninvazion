(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"AmazonInvazion_atlas_", frames: [[4238,3695,1788,254],[6510,1982,1414,326],[4238,2969,2336,480],[6357,1496,1726,484],[6357,656,1260,838],[4238,3451,2172,242],[4238,2119,2270,848],[6357,0,1820,654],[2119,2119,2117,2117],[7689,2310,290,360],[6576,3022,512,512],[7619,656,512,512],[7175,2310,512,512],[4238,0,2117,2117],[2119,0,2117,2117],[7619,1170,510,290],[7175,2824,512,512],[0,2119,2117,2117],[0,0,2117,2117],[6576,2310,597,710]]}
];


// symbols:



(lib._1998 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._1999 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._2004 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._2006 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib._2012 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib._2014 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib._2018 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib._20188 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Image = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Image_1 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Image_2 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Image_3 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Image_4 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Image_0 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Image_0_1 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Image_0_2 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Image_0_3 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Image_1_1 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Image_1_2 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CRight1 = function() {
	this.initialize(ss["AmazonInvazion_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#AA221D").s().p("AEjBDIAAgtIhaAAIAAgrIhZAAIAAArIjfAAIAAgrIhaAAIAAArIhZAAIAAAtIhaAAIAAhYIAtAAIAAgtIENAAIAAAtIAsAAIAAgtIAsAAIAAAtIAtAAIAAgtIEMAAIAAAtIAtAAIAABYg");
	this.shape.setTransform(42.5,55.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AFPDgIAAgtIkMAAIAAAtIgtAAIAAllIAtAAIAAgtIAtAAIAAgtIDfAAIAAAtIAtAAIAAGSgAEjBaIAsAAIAAgtIgsAAgABDBaIAtAAIAAgtICzAAIAAgtIizAAIAAAtIgtAAgABwhYICzAAIAAAsIAsAAIAAgsIgsAAIAAgtIizAAgABDgsIAtAAIAAgsIgtAAgAhCDgIAAgtIkNAAIAAAtIgtAAIAAmSIAtAAIAAgtIDgAAIAAAtIAtAAIAAAtIAsAAIAAFlgAhvBaIAtAAIAAgtIgtAAgAlPBaIAtAAIAAgtICzAAIAAgtIizAAIAAAtIgtAAgAkihYICzAAIAAAsIAtAAIAAgsIgtAAIAAgtIizAAgAlPgsIAtAAIAAgsIgtAAg");
	this.shape_1.setTransform(42.5,26.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AEjFQIAAgtIBZAAIAAAtgAl8FQIAAgtIBaAAIAAAtgAF8EjIAAhZIgtAAIAAgtIkMAAIAAgtIEMAAIAAAtIAtAAIAAmSIAtAAIAAIYgADJEjIAAgtIBaAAIAAAtgAhvEjIAAgtIhaAAIAAgsIBaAAIAAAsIDfAAIAAgsIBZAAIAAAsIhZAAIAAAtgAkiEjIAAgtIBZAAIAAAtgAkiEjgAmoEjIAAoYIAsAAIAAgtIAtAAIAAgtIDgAAIAAAtIjgAAIAAAtIgtAAIAAGSIAtAAIAAgtIENAAIAAAtIkNAAIAAAtIgtAAIAABZgAAWDKIAAgtIAtAAIAAAtgAhCDKIAAgtIAsAAIAAAtgABDCdgAgWCdIAAllIgsAAIAAgtIgtAAIAAgtIAtAAIAAAtIAsAAIAAAtIAsAAIAAFlgAgWCdgAEjAXIAAgsIAsAAIAAAsgABDAXIAAgsIAtAAIAAAsgAhvAXIAAgsIAtAAIAAAsgAlPAXIAAgsIAtAAIAAAsgABwgVIAAgtICzAAIAAAtgABwgVgAkigVIAAgtICzAAIAAAtgAkigVgAEjhvIAAgsIizAAIAAgtICzAAIAAAtIAsAAIAAAsgABDhvIAAgsIAtAAIAAAsgAhvhvIAAgsIizAAIAAgtICzAAIAAAtIAtAAIAAAsgAlPhvIAAgsIAtAAIAAAsgAAWjIIAAgtIAtAAIAAAtgAAWjIgAFPj1IAAgtIAtAAIAAAtgABDj1IAAgtIAtAAIAAAtgABwkiIAAgtIDfAAIAAAtgABwkig");
	this.shape_2.setTransform(42.5,33.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(0,0,85,67.1), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AmNCfIAAifIA1AAIAAg0IA1AAIAAg1IA1AAIAAA1ICgAAIAAhrIA1AAIAAA2IA0AAIAAA1IA1AAIAAA0ICfAAIAAA1IBrAAIAAA1IA0AAIAAA1gAlYA1IA1AAIAAA1ICfAAIAAhqIg1AAIAAA1IhqAAIAAg1Ig1AAg");
	this.shape.setTransform(45.175,15.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AlzCFIAAg1Ig1AAIAAg1IA1AAIMcAAIAAA1Ig1AAIAAA1gAkIgaIAAg1Ig2AAIAAg1IA2AAIAAA1IBqAAIAAg1IA1AAIAABqg");
	this.shape_1.setTransform(42.5,29.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(0,0,85,42.5), null);


(lib.Symbol2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#006F38").s().p("AkXEYIAAhQIIvAAIAABQgAB4B4IAAhQIhQAAIAABQIhPAAIAAhQIhQAAIAAhPIBQAAIAABPIBPAAIAAhPIBQAAIAABPIBQAAIAAhPIBQAAIAABPIhQAAIAABQgAjHB4IAAhQIhQAAIAAhPIBQAAIAABPIBQAAIAABQgAh3AogAB4h3IAAhQIhQAAIAAhQIBQAAIAABQIBQAAIAAhQIBQAAIAABQIhQAAIAABQgAgnh3IAAhQIhQAAIAAhQIBQAAIAABQIBPAAIAABQgAjHh3IAAhQIhQAAIAAhQIBQAAIAABQIBQAAIAABQgAh3jHg");
	this.shape_2.setTransform(52,76);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#AB7B4D").s().p("AG4KAItvAAIhQAAIAAigIBQAAIAAp/IhQAAIAAigICgAAIAAigIBQAAIAAigIIvAAIAACgIBQAAIAACgICgAAIAACgIhQAAIAAJ/IBQAAIAACggAkXGQIIvAAIAAhQIovAAgAB4CgIAABQIBQAAIAAhQIBQAAIAAhQIhQAAIAABQIhQAAIAAhQIhQAAIAABQIhPAAIAAhQIhQAAIAABQIBQAAIAABQIBPAAIAAhQgAkXCgIBQAAIAABQIBQAAIAAhQIhQAAIAAhQIhQAAgAAohPIBQAAIAABPIBQAAIAAhPIBQAAIAAhQIhQAAIAABQIhQAAIAAhQIhQAAgAh3hPIBQAAIAABPIBPAAIAAhPIhPAAIAAhQIhQAAgAkXhPIBQAAIAABPIBQAAIAAhPIhQAAIAAhQIhQAAgAjHk/IGPAAIAAhQIhQAAIAAhQIjvAAIAABQIhQAAg");
	this.shape_3.setTransform(52,64);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#7A4A1D").s().p("AFoBQIAAhQIBQAAIAABQgAm3BQIAAhQIBQAAIAABQgAG4AAIAAhPIBQAAIAABPgAoHAAIAAhPIBQAAIAABPg");
	this.shape_4.setTransform(52,136);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#916033").s().p("AG4HgIAAhQIhQAAIAABQIrPAAIAAhQIhQAAIAAhQINvAAIAABQIBQAAIAABQgAoHHgIAAhQIBQAAIAABQgAm3GQgAG4CgIAAp/IBQAAIAAJ/gAoHCgIAAp/IBQAAIAAJ/g");
	this.shape_5.setTransform(52,96);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2_1, new cjs.Rectangle(0,0,104,144), null);


(lib.JeffBezos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#220C07").s().p("ABkAyIAAhjIBkAAIAABjgAjGAyIAAhjIBjAAIAABjg");
	this.shape.setTransform(248.65,244.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EED7C6").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_1.setTransform(273.6,174.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B9786D").s().p("AiUCWIAAhkIksAAIAAhjIhkAAIAAhkIBkAAIAABkIOBAAIAABjIjHAAIAABkgAHBgxIAAhkIBkAAIAABkgAHBgxg");
	this.shape_2.setTransform(243.65,274.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#040A0C").s().p("AGPBkIAAjHIBkAAIAABjIBkAAIAABkgApWBkIAAhkIDIAAIAABkg");
	this.shape_3.setTransform(248.625,169.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AGPDHIAAhjIhkAAIAAhkIAAhjIBkAAIAAhjIBkAAIAABjIBjAAIAABjIhjAAIAAhjIhkAAIAADHIDHAAIAABjgAq6DHIAAjHIBkAAIAABkIDIAAIAABjgAJWBkIAAhkIBkAAIAABkgApWAAIAAhjIDIAAIAABjgApWAAg");
	this.shape_4.setTransform(248.65,169.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#442823").s().p("ALsBkIAAhkIjHAAIhkAAIhkAAIAABkIhkAAIAAjHIJXAAIAADHgAlcBkIAAhkImQAAIAAhjIJXAAIAADHgAtPBkIAAhkIBjAAIAABkg");
	this.shape_5.setTransform(243.675,149.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EFC4AE").s().p("Ax7D5IAAjHIhkAAIAAkqIDIAAIAABjIhkAAIAABkIBkAAIAAEqgAQYCWIAAjHIBkAAIAAhkIhkAAIAAhjIDIAAIAAEqIhkAAIAABkg");
	this.shape_6.setTransform(233.675,204.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AiVcEIAAhjIjHAAIAAhkIhkAAIAAhkIhkAAIAAhkIDIAAIAABkIBkAAIAABkIDHAAIAABkIJWAAIAAhkIBkAAIAAhkIBjAAIAADIIhjAAIAABjgALsXZIAAjIIBkAAIAAhjIBkAAIAADHIhkAAIAABkgALsXZgArrV1IAAjHIBjAAIAABjIBkAAIAABkgAO0SuIAAjIIBkAAIAADIgAO0SugAuzSuIAAjIIhkAAIAAhkIhkAAIAAhkIhkAAIAAhjIhjAAIAAksIhkAAIAAq5IDHAAIAApXIBkAAIAAjIIBkAAIAAkrIDIAAIAAhkIBkAAIAAhkIBjAAIAAhkIDIAAIAAhjIOBAAIAABjIDIAAIAABkIBjAAIAABkIBkAAIAABkIBkAAIAADHIBkAAIAADIIBkAAIAAErIBkAAIAAGQIBjAAIAABjIBkAAIAAJWIhkAAIAAnyIhjAAIAAhkIhkAAIAAmPIhkAAIAAkrIhkAAIAAjIIhkAAIAAjHIhkAAIAAhkIhjAAIAAhkIhkAAIAAhkIjIAAIAAhkIq5AAIAABkIjIAAIAABkIhkAAIAABkIhjAAIAABkIjIAAIAAErIhkAAIAADIIhkAAIAAJWIjHAAIAAHyIBjAAIAAEsIBkAAIAABkIBkAAIAABjIBkAAIAABkIBkAAIAADIIBkAAIAABkgAQYPmIAAjIIBkAAIAAjHIBkAAIAAjIIBjAAIAADIIhjAAIAADHIhkAAIAADIgAQYPmg");
	this.shape_7.setTransform(233.675,179.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EDC0A9").s().p("AhjGPIAAhkIhjAAIhkAAIAAjHIBkAAIAAhkIBjAAIAAmOIErAAIAABkIAAGOIBjAAIAADHIhjAAIhkAAIAABkg");
	this.shape_8.setTransform(248.65,209.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F9DDC5").s().p("AgxahIAAhkIjHAAIAAhkIhkAAIAAhkIjIAAIAAhkIhkAAIAAhjIhjAAIAAhkIhkAAIAAjIIhkAAIAAhkIhkAAIAAhjIhkAAIAAhkIhkAAIAAksIBkAAIAADIIBkAAIAAkrIhkAAIAAhkIBkAAIAAhkIjIAAIAAErIhjAAIAAnyIDHAAIAApWIBkAAIAAjIIBkAAIAAkrIDIAAIAAhkIBjAAIAAhkIBkAAIAAhkIDIAAIAAhkIK5AAIAABkIDIAAIAABkIBkAAIAABkIBjAAIAABkIBkAAIAADHIBkAAIAADIIBkAAIAAErIBkAAIAAGPIBkAAIAABkIBjAAIAAHyIhjAAIAADIIhkAAIAADHIhkAAIAADIIhkAAIAADIIhkAAIAABjIhkAAIAADIIhjAAIAABkIhkAAIAABkgAnAOCIBkAAIAABkIErAAIAABkIGOAAIAAhkIDIAAIAAhkIBkAAIAAhkIhkAAIAABkIuBAAIAAhkIhkAAgAiVJXIBkAAIAABkIBjAAIDHAAIBkAAIAAhkIBkAAIAAjIIhkAAIAAmPIBkAAIBkAAIAABkIDHAAIAAhkIBkAAIAAhjIhkAAIAAhkIhjAAIAAhjIDHAAIAABjIBkAAIAAjHIpXAAIAADHIBkAAIAAhjIBkAAIAABjIhkAAIAABkIhkAAIkrAAIAAGOIhjAAIAABkIhkAAgAQYGPIBkAAIAAhkIBkAAIAAkrIjIAAIAABkIBkAAIAABkIhkAAgAokBkIEsAAIAAhkIAAhjIAAhkIDHAAIAAjHIpXAAIAABkIGQAAIAABjIjIAAIAABkIhkAAgArrjHIBjAAIAAhjIhjAAg");
	this.shape_9.setTransform(233.675,179.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.JeffBezos, new cjs.Rectangle(89,0,289.4,359.3), null);


(lib.ZapposBezos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_0_2();
	this.instance.parent = this;
	this.instance.setTransform(61,115,0.769,0.4517);

	this.instance_1 = new lib.Image_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(236,379,0.2011,0.2011);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ADIV4IAAhkIkrAAIAAhkIBjAAIAAksIjHAAIAAhkIDHAAIAAksIBkAAIAAEsIDIAAIAABkIjIAAIAAEsIBkAAIAABkIBkAAIAABkgAjHV4IAAhkIBkAAIAABkgAEsMgIAAhkIBkAAIAABkgAEsMggAkrMgIAAhkIhkAAIAAjIIhkAAIAAhkIjIAAIAAhkIhkAAIAAhkIhkAAIAAhkIhkAAIAAhkIhkAAIAAhjIhkAAIAAjIIhkAAIAAhkIhkAAIAAhkIhkAAIAAjIIhkAAIAAjIIhkAAIAAhkIhkAAIAAksIBkAAIAADIIBkAAIAABkIBkAAIAADIIBkAAIAADIIBkAAIAABkIBkAAIAABkIBkAAIAADIIBkAAIAABkIBkAAIAABjIBkAAIAABkIBkAAIAABkIBkAAIAABkIDIAAIAABkIBkAAIAAEsIBkAAIAABkgAGQK8IAAjIIBkAAIAADIgAH0H0IAAjIIDIAAIAAhkIBkAAIAAhkIBkAAIAAhkIBkAAIAAhjIBkAAIAAhkIDIAAIAAhkIBkAAIAADIIjIAAIAABjIhkAAIAABkIhkAAIAABkIhkAAIAABkIhkAAIAABkIjIAAIAABkgAH0H0gAV4krIAAjIIBkAAIAAhkIBkAAIAAmQIBkAAIAAmQIBkAAIAAH0IhkAAIAAGQIhkAAIAABkIhkAAIAABkg");
	this.shape.setTransform(260,370);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ZapposBezos, new cjs.Rectangle(61,115,392.2,395), null);


(lib.PillPackPlane = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_4();
	this.instance.parent = this;
	this.instance.setTransform(256,207,0.1875,0.1875,0,0,180);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#808080").s().p("AkqCWIAAjHIBjAAIAAhkIBkAAIDGAAIAABkIBkAAIAABjIBlAAIAABkg");
	this.shape.setTransform(339.55,245.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#489ED7").s().p("AnyNSIAAksIBkAAIAAhkInzAAIAAhkIjIAAIAAhkIhkAAIAABkIjHAAIAABkIksAAIAAksIBkAAIAAhkIBkAAIAAhjIhkAAIAAhkIhkAAIAAhkIhkAAIAAhkIhjAAIAAn0IGPAAIAABkIBkAAIAABkIBjAAIAABkIDIAAIAABkMAlaAAAIAABkIBkAAIAABkIjIAAIAAhkMglaAAAIAAhkIjHAAIAAhkIhkAAIAAhkIhkAAIAAhkIjIAAIAAEsIBkAAIAABkIBkAAIAABkIBkAAIAABkIBkAAIAAErIhkAAIAABkIhkAAIAABkIBkAAIAAhkIDHAAIAAhkIBkAAIAAhkIDIAAIAADIIDHAAIAABkIHzAAIAAhkIDIAAIAABkIEqAAIAAhkIBkAAIAAhkIBkAAIAADIIV1AAIAAjIIhkAAIAAhkIhjAAIAAhjIhkAAIAAhkIhkAAIAAhkIDIAAIAABkIBjAAIAABkIBkAAIAABjIBkAAIAAGQI49AAIAABkIhkAAIAAhkInyAAIAADIIhjAAIAABkIGOAAIAABkgAAALuIAAhkIBkAAIAABkgABkKKIAAhkIBjAAIAABkgABkKKgADHImg");
	this.shape_1.setTransform(209.825,255.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AmOLuIAAhkIBjAAIAAjIIHzAAIAABkIhkAAIAABkIhkAAIAABkgAGQFeIAAjIIhkAAIAABkIhkAAIAABkIkqAAIAAhkIjJAAIAABkInyAAIAAhkIjIAAIAAjIIjHAAIAABkIhlAAIAABkIjHAAIAAhkIBkAAIAAkrIhkAAIAAhkIhkAAIAAhkIhkAAIAAhkIhkAAIAAksIDIAAIAABkIBkAAIAABkIBkAAIAABkIDIAAIAABkMAlaAAAIAABkIhkAAIAABkIhkAAIAADHIJXAAIBjAAIAABkIBkAAIAADIgAmOgxIBjAAIAABjIGPAAIAABkIBkAAIAAhkIBkAAIAAhjIBkAAIAAjIImQAAIAABkImOAAgA48FeIAAhkIBkAAIAABkgA3YD6g");
	this.shape_2.setTransform(209.8,255.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.PillPackPlane, new cjs.Rectangle(20.2,170.3,379.3,170), null);


(lib.HotAirBalloon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_0_3();
	this.instance.parent = this;
	this.instance.setTransform(85,-2,0.6719,0.6719);

	this.instance_1 = new lib.Image_2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(195.75,341.8,0.2871,0.2871);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AnANSIAAhkIhkAAIAAhkIhjAAIAAhkIhlAAIAAhkIhkAAIAAjIIhjAAIAAq7IBjAAIAAksIBkAAIAAGQIhkAAIAAHzIBkAAIAADIIBlAAIAABkIBjAAIAABkIBkAAIAABkIBkAAIAADIgAFdLuIAAhkIBkAAIAAjIIBkAAIAAhkIBkAAIAAjIIBkAAIAAmPIBjAAIAAhkIhjAAIAAksIhkAAIAAjIIBkAAIAABkIBjAAIAAEsIBkAAIAAEsIhkAAIAAGPIhjAAIAADIIhkAAIAABkIhkAAIAADIg");
	this.shape.setTransform(264.7,285.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.HotAirBalloon, new cjs.Rectangle(85,-2,344,490.8), null);


(lib.Blimp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_3();
	this.instance.parent = this;
	this.instance.setTransform(78.75,92.8,0.6426,0.6426);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5F449E").s().p("APmAyIAAhjIBkAAIAABjgAMfAyIAAhjIBjAAIAABjgAJXAyIAAhjIBkAAIAABjgAq5AyIAAhjIBjAAIAABjgAuBAyIAAhjIBkAAIAABjgAxJAyIAAhjIBkAAIAABjg");
	this.shape.setTransform(239.725,375.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AErVGIAAjIIhjAAIAAhkIpXAAIAABkIhjAAIAADIIsfAAIAAjIIhkAAIAAhkIkrAAIAAhkIhjAAIAAhkIhkAAIAAhkIhkAAIAAhkIhkAAIAAhkIhkAAIAAhkIhkAAIAADIIjHAAIAAn0IBjAAIAAmPIhjAAIAApYIBjAAIAABkIBkAAIAADIIBkAAIAAjIIBkAAIAAhkIBkAAIAAhkIBkAAIAAhkIBkAAIAAhkIBjAAIAAhkIBkAAIAAhkMAx5AAAIAABkIBjAAIAABkIBkAAIAABkIBkAAIAABkIBkAAIAABkIBjAAIAABkIBkAAIAABkIBkAAIAABkIBkAAIAABkIBkAAIAAJXIhkAAIAABkIhkAAIAABkIhkAAIAABkIhkAAIAABkIhjAAIAABkIhkAAIAABkIhkAAIAABkIhkAAIAABkIhjAAIAABkImPAAIAABkIhlAAIAADIgAOCTiIBjAAIAAhkIhjAAgAK6TiIBkAAIAAhkIhkAAgAHzTiIBkAAIAAhkIhkAAgAsdTiIBjAAIAAhkIhjAAgAvlTiIBkAAIAAhkIhkAAgAytTiIBkAAIAAhkIhkAAgA11LuIAADIMArqAAAIAAjIIBkAAIAAn0IhkAAIAAjIIBkAAIAAxLIhkAAIAAhkMgtNAAAIAABkIhkAAIAABkIhkAAIAAMgIBkAAIAAPnIBkAAIAAhkg");
	this.shape_1.setTransform(249.75,255.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Blimp, new cjs.Rectangle(0.3,92.8,499,329), null);


(lib.Instructions = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instructions = new cjs.Text("HOW-TO PLAY:\n\nCLICK TO THE RIGHT OR TO THE LEFT \nOF THE CHARACTER TO MOVE THEM.", "42px 'Silom'");
	this.instructions.name = "instructions";
	this.instructions.lineHeight = 56;
	this.instructions.lineWidth = 830;
	this.instructions.parent = this;
	this.instructions.setTransform(-70,-176);

	this.timeline.addTween(cjs.Tween.get(this.instructions).wait(1));

}).prototype = getMCSymbolPrototype(lib.Instructions, new cjs.Rectangle(-72,-178,834,231.1), null);


(lib.HitCircle2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgtAfQgTgNAAgSQAAgRATgOQATgNAaAAQAbAAATANQATAOAAARQAAASgTANQgTAOgbAAQgaAAgTgOg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.HitCircle2, new cjs.Rectangle(-6.5,-4.5,13,9), null);


(lib.HitBoxCircle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0000FF").ss(1,1,1).p("AA/AAQAAAagTASQgSASgaAAQgZAAgTgSQgSgSAAgaQAAgZASgSQATgSAZAAQAaAAASASQATASAAAZg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0033FF").s().p("AgrArQgTgRABgaQgBgZATgSQASgSAZAAQAaAAASASQASASAAAZQAAAagSARQgSATgaAAQgZAAgSgTg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.HitBoxCircle, new cjs.Rectangle(-7.2,-7.2,14.5,14.4), null);


(lib.CongratsText = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.scoreupdate = new cjs.Text("0", "38px 'Silom'", "#ED9B38");
	this.scoreupdate.name = "scoreupdate";
	this.scoreupdate.lineHeight = 50;
	this.scoreupdate.parent = this;
	this.scoreupdate.setTransform(-125.5,29.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgfAgIAAg/IA/AAIAAA/g");
	this.shape.setTransform(-100.675,212.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhOCPIAAkdICdAAIAAAgIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAgg");
	this.shape_1.setTransform(-118.075,201.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgPCPQgfgBgQgPQgQgQAAggIAgAAIAAAFQAAANAKAHQAJAHAMAAQAQAAAHgIQAIgJAAgPQAAgMgJgLIhDhJQgSgVAAgYIAAgQQAAgaASgTQATgTAaAAIAfAAQA8AAADBAIgfAAQgFgggZAAQgRAAgHAIQgJAIAAAQQAAAMAJALIBDBJQASAWAAAXIAAAQQAAAagSATQgTATgaAAg");
	this.shape_2.setTransform(-140.225,201.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgfCPIAAkdIA+AAIAAEdg");
	this.shape_3.setTransform(-160.8,201.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAgCPIAAhgQAAgNgKgJQgIgJgOAAIgfAAIAAB/Ig/AAIAAkdIB+AAQAaAAASATQATATAAAaIAAARQAAAWgOATQgPATggABIgCAAIACAAIAeAAQANAAAJAIQAJAJAAANIAABxgAgfgPIAfAAQAOAAAIgJQAKgJAAgNIAAggQAAgOgKgIQgIgKgOAAIgfAAg");
	this.shape_4.setTransform(-182.95,201.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhOCPIAAkdICdAAIAAAgIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAgg");
	this.shape_5.setTransform(-216.175,201.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAgCPIAAh/Ig/AAIAAB/Ig/AAIAAkdIA/AAIAAB/IA/AAIAAh/IA/AAIAAEdg");
	this.shape_6.setTransform(-239.9,201.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgfCPIAAj9Ig/AAIAAggIC9AAIAAAgIhAAAIAAD9g");
	this.shape_7.setTransform(-262.05,201.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("ABgCPIiuieIAACeIggAAIAAkdIAPAAICuCeIAAieIAgAAIAAEdg");
	this.shape_8.setTransform(-295.3,201.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgfCPQgaAAgSgTQgTgTAAgaIAAidQAAgaATgTQASgTAaAAIA/AAQAZAAATATQATATAAAaIAACdQAAAagTATQgTATgZAAgAgVhkQgKAIAAAOIAACdQAAANAKAJQAJAKAMAAQANAAAJgKQAKgJAAgNIAAidQAAgOgKgIQgJgKgNAAQgMAAgJAKg");
	this.shape_9.setTransform(-322.2,201.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AheCPIAAkdIB+AAQAaAAASATQATATAAAaIAACdQAAAagTATQgSATgaAAgAgfBvIAfAAQAOAAAIgKQAKgJAAgNIAAidQAAgOgKgIQgIgKgOAAIgfAAg");
	this.shape_10.setTransform(-357,201.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("ABhCPIivieIAACeIggAAIAAkdIAPAAICuCeIAAieIAgAAIAAEdg");
	this.shape_11.setTransform(-383.9,201.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAgCPIAAh/Ig+AAIAAB/IhAAAIAAjdQAAgaATgTQATgTAaAAIA+AAQAZAAAUATQASATAAAaIAADdgAgVhkQgKAIABAOIAAA/IA+AAIAAg/QAAgOgJgIQgJgKgOAAQgMAAgJAKg");
	this.shape_12.setTransform(-410.8,201.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#ED9B38").s().p("ABhCOIividIAACdIggAAIAAkbIAPAAICuCdIAAidIAgAAIAAEbg");
	this.shape_13.setTransform(328.1,146.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#ED9B38").s().p("AgeCOQgaAAgTgSQgTgTAAgaIAAidQAAgaATgTQATgSAaAAIA+AAQAZAAAUASQASATAAAaIAACdQAAAagSATQgUASgZAAgAgVhlQgJAJAAAOIAACdQAAANAJAKQAJAJAMAAQAOAAAJgJQAJgKAAgNIAAidQAAgOgJgJQgJgJgOAAQgMAAgJAJg");
	this.shape_14.setTransform(301.2,146.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#ED9B38").s().p("AgeCOIAAkbIA+AAIAAEbg");
	this.shape_15.setTransform(279.05,146.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#ED9B38").s().p("AhOCOIAAkbIA/AAIAAD8IBeAAIAAAfg");
	this.shape_16.setTransform(258.475,146.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#ED9B38").s().p("AhOCOIAAkbIA/AAIAAD8IBeAAIAAAfg");
	this.shape_17.setTransform(236.325,146.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#ED9B38").s().p("AgfCOIAAkbIA+AAIAAEbg");
	this.shape_18.setTransform(215.75,146.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#ED9B38").s().p("AheCOIAAkbIB+AAQAaAAASASQATATAAAaIAAAQQAAAcgQAPQgQARgfACQAfAAAQATQAQAUAAAZIAAAPQAAAagTATQgSASgaAAgAgfBvIAfAAQANAAAJgJQAKgKAAgNIAAgfQAAggggAAIgfAAgAgfgPIAfAAQANAAAJgJQAKgJAAgOIAAgfQAAgOgKgJQgJgJgNAAIgfAAg");
	this.shape_19.setTransform(193.6,146.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#ED9B38").s().p("AgfCOQgZAAgTgSQgTgTAAgaIAAhuQAAgtAhghQAhghAsABIAvAAIAAAfIgfAAQgaAAgSATQgSASgBAaIAAAgQADgPAIgJQAHgHANgBIAgAAQAaABASASQATATAAAZIAAA/QAAAagTATQgSASgaAAgAgVgFQgKAIAAANIAAA/QAAANAKAKQAJAJAMAAQAOAAAIgJQAKgKAAgNIAAg/QAAgNgKgIQgIgKgOAAQgMAAgJAKg");
	this.shape_20.setTransform(158.8,146.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#ED9B38").s().p("AgfAgIAAg/IA/AAIAAA/g");
	this.shape_21.setTransform(139.825,157.875);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#ED9B38").s().p("AgPCOIAAjcIgfAAIAAggIA+gfIAfAAIAAEbg");
	this.shape_22.setTransform(119.3,146.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#ED9B38").s().p("AgPCuIAAggQg/gFAAg6IAgAAIAAAGQAAAWAfAEIAAhYIgtgoQgSgSAAgbIAAgQQAAg5A/gGIAAggIAfAAIAAAgQA8AAADA/IgfAAQgFgggbAAIAABXIAtAqQASARAAAcIAAAPQAAA5g/AGIAAAggAAQBvQATgIAAgVQAAgPgTgTgAgihQQAAAIAFAIIAOARIAAg/QgTAIAAAWg");
	this.shape_23.setTransform(97.125,146.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgPCOQgfAAgQgPQgQgQAAggIAgAAIAAAFQAAANAKAHQAJAHAMAAQAQAAAHgIQAIgJAAgPQAAgMgJgKIhDhKQgSgVAAgYIAAgQQAAgaASgTQATgSAaAAIAfAAQA8AAADA/IgfAAQgFgggZAAQgRAAgHAIQgJAIAAAQQAAAMAJAKIBDBLQASAUAAAZIAAAPQAAAagSATQgTASgaAAg");
	this.shape_24.setTransform(65.475,146.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgeCOIAAkbIA+AAIAAEbg");
	this.shape_25.setTransform(44.9,146.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAgCOIAAh+Ig/AAIAAB+Ig/AAIAAkbIA/AAIAAB+IA/AAIAAh+IA/AAIAAEbg");
	this.shape_26.setTransform(13.25,146.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgfCOIAAj8Ig/AAIAAgfIC9AAIAAAfIhAAAIAAD8g");
	this.shape_27.setTransform(-8.9,146.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AAgCOIAAheQAAgNgKgKQgJgJgNAAIgfAAIAAB+Ig/AAIAAkbIB+AAQAZAAATASQATATAAAaIAAARQAAAVgPAUQgOATggAAIgCAAIACAAIAeAAQANAAAJAJQAJAJAAANIAABwgAgfgPIAfAAQANAAAJgJQAKgJAAgOIAAgfQAAgOgKgJQgJgJgNAAIgfAAg");
	this.shape_28.setTransform(-31.05,146.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgeCOQgaAAgTgSQgTgTAAgaIAAidQAAgaATgTQATgSAaAAIA+AAQAZAAAUASQASATAAAaIAACdQAAAagSATQgUASgZAAgAgVhlQgJAJAAAOIAACdQAAANAJAKQAJAJAMAAQANAAAKgJQAJgKAAgNIAAidQAAgOgJgJQgKgJgNAAQgMAAgJAJg");
	this.shape_29.setTransform(-56.35,146.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgfCOIAAgKQgRAKgcAAIhSAAIAAkbIBAAAIAAD8IAgAAQANAAAJgJQAJgKAAgNIAAjcIA+AAIAAD8IAhAAQANAAAIgJQAKgKAAgNIAAjcIA/AAIAACvQAAAtgfAgQggAfgtAAg");
	this.shape_30.setTransform(-88,146.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgfCOIAAj8Ig/AAIAAgfIC9AAIAAAfIhAAAIAAD8g");
	this.shape_31.setTransform(-126,146.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AhOCOIAAkbICdAAIAAAfIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAfg");
	this.shape_32.setTransform(-146.575,146.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("ABgCOIiuidIAACdIggAAIAAkbIAPAAICuCdIAAidIAgAAIAAEbg");
	this.shape_33.setTransform(-171.9,146.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgPAvIAAhdIAfAAIAABdg");
	this.shape_34.setTransform(-200.4,137.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgPCOQgfAAgQgPQgQgQAAggIAgAAIAAAFQAAANAKAHQAJAHAMAAQAQAAAHgIQAIgJAAgPQAAgMgJgKIhDhKQgSgVAAgYIAAgQQAAgaASgTQATgSAaAAIAfAAQA8AAADA/IgfAAQgFgggZAAQgRAAgHAIQgJAIAAAQQAAAMAJAKIBDBLQASAUAAAZIAAAPQAAAagSATQgTASgaAAg");
	this.shape_35.setTransform(-216.225,146.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgeCOQgaAAgTgSQgTgTAAgaIAAidQAAgaATgTQATgSAaAAIA+AAQAZAAAUASQASATAAAaIAACdQAAAagSATQgUASgZAAgAgVhlQgJAJAAAOIAACdQAAANAJAKQAJAJAMAAQANAAAKgJQAJgKAAgNIAAidQAAgOgJgJQgKgJgNAAQgMAAgJAJg");
	this.shape_36.setTransform(-239.95,146.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AheCOIAAgfIB+jdIh+AAIAAgfIC9AAIAAAfIh9DdIB9AAIAAAfg");
	this.shape_37.setTransform(-265.25,146.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AhOCOIAAkbICdAAIAAAfIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAfg");
	this.shape_38.setTransform(-288.975,146.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AheCOIAAkbIB+AAQAZAAAUASQASATAAAaIAAAQQAAAcgPAPQgRARgfACQAfAAARATQAPAUAAAZIAAAPQAAAagSATQgUASgZAAgAgeBvIAeAAQAOAAAJgJQAJgKAAgNIAAgfQAAggggAAIgeAAgAgegPIAeAAQAOAAAJgJQAJgJAAgOIAAgfQAAgOgJgJQgJgJgOAAIgeAAg");
	this.shape_39.setTransform(-312.7,146.8);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AhOCOIAAkbICdAAIAAAfIheAAIAABfIA/AAIAAAfIg/AAIAAB+g");
	this.shape_40.setTransform(-345.925,146.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AhOCOIAAkbICdAAIAAAfIheAAIAABfIA/AAIAAAfIg/AAIAAB+g");
	this.shape_41.setTransform(-368.075,146.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AhOCOIAAkbICdAAIAAAfIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAfg");
	this.shape_42.setTransform(-390.225,146.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgeCOQghAAgPgPQgQgQAAggIAAg/IBAAAIAAA/QAAANAJAKQAJAJAMAAQANAAAKgJQAIgKABgNIAAjcIA/AAIAADcQAAAggQAQQgQAPgfAAg");
	this.shape_43.setTransform(-413.95,146.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("ABgCOIiuidIAACdIggAAIAAkbIAPAAICuCdIAAidIAgAAIAAEbg");
	this.shape_44.setTransform(-165.6,45.9);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgfCOQgaAAgSgSQgTgTAAgaIAAidQAAgaATgTQASgSAaAAIA/AAQAaAAASASQATATAAAaIAACdQAAAagTATQgSASgaAAgAgVhlQgKAKAAANIAACdQAAANAKAKQAJAJAMAAQANAAAJgJQAKgKAAgNIAAidQAAgNgKgKQgJgJgNAAQgMAAgJAJg");
	this.shape_45.setTransform(-192.5,45.9);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AheCOIAAgfIB+jdIh+AAIAAgfIC9AAIAAAfIh+DdIB+AAIAAAfg");
	this.shape_46.setTransform(-217.8,45.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AAgCOIAAh+Ig+AAIAAB+IhAAAIAAjcQAAgaATgTQATgSAaAAIA+AAQAZAAAUASQASATAAAaIAADcgAgVhlQgJAKAAANIAAA/IA+AAIAAg/QAAgNgJgKQgKgJgNAAQgMAAgJAJg");
	this.shape_47.setTransform(-243.1,45.9);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("ABfCOIAAisIhuBtIhuhtIAACsIghAAIAAkbIAQAAICHCHICGiHIAfAAIAAEbg");
	this.shape_48.setTransform(-274.75,45.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AAgCOIAAh+Ig+AAIAAB+IhAAAIAAjcQAAgaATgTQASgSAbAAIA+AAQAZAAAUASQASATAAAaIAADcgAgVhlQgKAKABANIAAA/IA+AAIAAg/QAAgNgJgKQgJgJgOAAQgMAAgJAJg");
	this.shape_49.setTransform(-306.4,45.9);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AheCOIAAkbIB+AAQAaAAATASQASATAAAaIAACdQAAAagSATQgUASgZAAgAgeBvIAeAAQANAAAKgJQAJgKAAgNIAAidQAAgNgJgKQgKgJgNAAIgeAAg");
	this.shape_50.setTransform(-341.2,45.9);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgeCOIAAkbIA+AAIAAEbg");
	this.shape_51.setTransform(-363.35,45.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AAgCOIAAh+Ig+AAIAAB+IhAAAIAAjcQAAgaATgTQATgSAaAAIA+AAQAZAAAUASQASATAAAaIAADcgAgVhlQgJAKAAANIAAA/IA+AAIAAg/QAAgNgJgKQgJgJgOAAQgMAAgJAJg");
	this.shape_52.setTransform(-385.5,45.9);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AheCOIAAkbIB+AAQAZAAAUASQASATAAAaIAAAfQAAAagSATQgUASgZAAIg+AAIAAB+gAgegPIAeAAQAOAAAJgJQAJgJAAgOIAAgfQAAgNgJgKQgJgJgOAAIgeAAg");
	this.shape_53.setTransform(-410.8,45.9);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AhOCPIAAkdICdAAIAAAgIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAgg");
	this.shape_54.setTransform(403.825,-4.55);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AheCPIAAkdIA/AAIAAD9IAfAAQAOAAAIgKQAKgJAAgNIAAjdIA/AAIAACwQAAAtgfAfQggAhgsAAg");
	this.shape_55.setTransform(380.1,-4.55);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AAgCPIAAh/Ig/AAIAAB/Ig/AAIAAjdQAAgaATgTQASgTAaAAIA/AAQAaAAASATQATATAAAaIAADdgAgVhkQgKAIAAAOIAAA/IA/AAIAAg/QAAgOgKgIQgIgKgOAAQgMAAgJAKg");
	this.shape_56.setTransform(354.8,-4.55);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AAgCPIAAh/Ig/AAIAAB/Ig/AAIAAkdIA/AAIAAB/IA/AAIAAh/IA/AAIAAEdg");
	this.shape_57.setTransform(329.5,-4.55);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AheCPIAAkdIB+AAQAaAAASATQATATAAAaIAACdQAAAagTATQgSATgaAAgAgfBvIAfAAQAOAAAIgKQAKgJAAgNIAAidQAAgOgKgIQgIgKgOAAIgfAAg");
	this.shape_58.setTransform(294.7,-4.55);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("ABhCPIivieIAACeIggAAIAAkdIAPAAICuCeIAAieIAgAAIAAEdg");
	this.shape_59.setTransform(267.8,-4.55);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AAgCPIAAh/Ig+AAIAAB/IhAAAIAAjdQAAgaATgTQATgTAaAAIA+AAQAZAAAUATQASATAAAaIAADdgAgVhkQgJAIAAAOIAAA/IA+AAIAAg/QAAgOgJgIQgJgKgOAAQgMAAgJAKg");
	this.shape_60.setTransform(240.9,-4.55);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AgfCPQgaAAgTgWQgSgUAAgWIAAgQQAAgWAQgVQAQgUAfAAQgfgDgQgPQgQgQAAgcIAAgQQAAgaATgTQASgTAaAAIA/AAQAZAAAUATQASATAAAaIAAAQQAAAcgQAQQgQAPgfADQAfAAAQAUQAQAVAAAWIAAAQQAAAWgSAUQgTAWgaAAgAgfAvIAAAgQABAOAJAIQAJAKAMAAQANAAAJgKQAKgIAAgOIAAggQAAgfggAAQgeAAgBAfgAgVhkQgJAIgBAOIAAAgQABANAJAJQAJAJAMAAQANAAAJgJQAKgJAAgNIAAggQAAgOgKgIQgJgKgNAAQgMAAgJAKg");
	this.shape_61.setTransform(206.1,-4.55);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("Ag+CPIAAggIAgAAQAZAAATgTQASgTAAgaIAAgfQgEAggcgBIgeAAQgaAAgTgSQgTgTAAgZIAAg/QAAgaATgTQATgTAaAAIA+AAQAZAAAUATQASATAAAaIAABtQAAAughAhQggAggsABgAgVhkQgJAJAAANIAAA/QAAANAJAJQAJAJAMAAQANAAAKgJQAJgJAAgNIAAg/QAAgOgJgIQgKgKgNAAQgMAAgJAKg");
	this.shape_62.setTransform(180.8,-4.55);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("Ag+CPIAAggIAgAAQAZAAATgTQASgTAAgaIAAgfQgEAggcgBIgeAAQgaAAgTgSQgTgTAAgZIAAg/QAAgaATgTQATgTAaAAIA+AAQAZAAAUATQASATAAAaIAABtQAAAughAhQggAggsABgAgVhkQgJAJAAANIAAA/QAAANAJAJQAJAJAMAAQANAAAKgJQAJgJAAgNIAAg/QAAgOgJgIQgKgKgNAAQgMAAgJAKg");
	this.shape_63.setTransform(155.5,-4.55);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgPCPIAAjdIgfAAIAAggIA+ggIAfAAIAAEdg");
	this.shape_64.setTransform(128.65,-4.55);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AAgCPIAAh/Ig/AAIAAB/Ig/AAIAAkdIA/AAIAAB/IA/AAIAAh/IA/AAIAAEdg");
	this.shape_65.setTransform(95.4,-4.55);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AgeCPQgaAAgTgTQgTgTAAgaIAAidQAAgaATgTQASgTAbAAIA+AAQA8AAADBAIggAAQgEgggbAAIggAAQgMAAgJAKQgJAIAAAOIAACdQAAAOAJAIQAJAKAMAAQAegCACgeIAAg/IggAAIAAgfIBfAAIAABeQAAAggUAPQgUAQgXABg");
	this.shape_66.setTransform(70.1,-4.55);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgeCPQgaAAgTgTQgTgTAAgaIAAjdIBAAAIAADdQAAANAJAJQAJAKAMAAQANAAAKgKQAJgJAAgNIAAjdIA/AAIAADdQAAAagSATQgUATgZAAg");
	this.shape_67.setTransform(44.8,-4.55);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgeCPQgaAAgTgTQgTgTAAgaIAAidQAAgaATgTQATgTAaAAIA+AAQAZAAAUATQASATAAAaIAACdQAAAagSATQgUATgZAAgAgVhkQgJAIAAAOIAACdQAAANAJAJQAJAKAMAAQAOAAAJgKQAJgJAAgNIAAidQAAgOgJgIQgJgKgOAAQgMAAgJAKg");
	this.shape_68.setTransform(19.5,-4.55);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AAgCPIAAhgQAAgNgJgJQgJgJgOAAIgeAAIAAB/IhAAAIAAkdIB+AAQAZAAAUATQASATAAAaIAAARQAAAWgOATQgPATggABIgCAAIACAAIAdAAQANAAAKAIQAJAJAAANIAABxgAgegPIAeAAQAOAAAJgJQAJgJAAgNIAAggQAAgOgJgIQgJgKgOAAIgeAAg");
	this.shape_69.setTransform(-5.8,-4.55);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AAgCPIAAh/Ig/AAIAAB/Ig/AAIAAkdIA/AAIAAB/IA/AAIAAh/IA/AAIAAEdg");
	this.shape_70.setTransform(-31.1,-4.55);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgfCPIAAj9Ig/AAIAAggIC9AAIAAAgIhAAAIAAD9g");
	this.shape_71.setTransform(-53.25,-4.55);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgeCPIAAj9IhAAAIAAggIC9AAIAAAgIg/AAIAAD9g");
	this.shape_72.setTransform(-81.75,-4.55);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AgeCPIAAkdIA+AAIAAEdg");
	this.shape_73.setTransform(-100.75,-4.55);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AhOCPIAAkdICdAAIAAAgIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAgg");
	this.shape_74.setTransform(-130.825,-4.55);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AheCPIAAkdIB+AAQAZAAAUATQASATAAAaIAACdQAAAagSATQgUATgZAAgAgeBvIAeAAQANAAAKgKQAJgJAAgNIAAidQAAgOgJgIQgKgKgNAAIgeAAg");
	this.shape_75.setTransform(-154.55,-4.55);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AAgCPIAAh/Ig+AAIAAB/IhAAAIAAjdQAAgaATgTQATgTAaAAIA+AAQAZAAAUATQASATAAAaIAADdgAgVhkQgJAIAAAOIAAA/IA+AAIAAg/QAAgOgJgIQgJgKgOAAQgMAAgJAKg");
	this.shape_76.setTransform(-179.85,-4.55);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("ABfCPIAAiuIhuBvIhvhvIAACuIgfAAIAAkdIAPAAICHCHICGiHIAfAAIAAEdg");
	this.shape_77.setTransform(-211.5,-4.55);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AhOCPIAAkdICdAAIAAAgIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAgg");
	this.shape_78.setTransform(-251.075,-4.55);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AheCPIAAkdIBAAAIAAD9IAeAAQAOAAAJgKQAJgJAAgNIAAjdIA/AAIAACwQAAAtggAfQgfAhgsAAg");
	this.shape_79.setTransform(-274.8,-4.55);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AAgCPIAAh/Ig+AAIAAB/IhAAAIAAjdQAAgaATgTQASgTAbAAIA+AAQAZAAAUATQASATAAAaIAADdgAgVhkQgKAIABAOIAAA/IA+AAIAAg/QAAgOgJgIQgJgKgOAAQgMAAgJAKg");
	this.shape_80.setTransform(-300.1,-4.55);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AAgCPIAAh/Ig/AAIAAB/Ig/AAIAAkdIA/AAIAAB/IA/AAIAAh/IA/AAIAAEdg");
	this.shape_81.setTransform(-325.4,-4.55);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AgeCPQgaAAgTgTQgTgTAAgaIAAjdIBAAAIAADdQAAANAJAJQAJAKAMAAQANAAAKgKQAJgJAAgNIAAjdIA/AAIAADdQAAAagSATQgUATgZAAg");
	this.shape_82.setTransform(-360.2,-4.55);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgeCPQgaAAgTgTQgTgTAAgaIAAidQAAgaATgTQATgTAaAAIA+AAQAZAAAUATQASATAAAaIAACdQAAAagSATQgUATgZAAgAgVhkQgJAIAAAOIAACdQAAANAJAJQAJAKAMAAQAOAAAJgKQAJgJAAgNIAAidQAAgOgJgIQgJgKgOAAQgMAAgJAKg");
	this.shape_83.setTransform(-385.5,-4.55);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AgeCPIAAh/QhAgHAAg3IAAhgIBAAAIAABgQgBANAKAJQAJAJAMAAQAOAAAJgJQAJgJAAgNIAAhgIA/AAIAABgQAAA3g/AHIAAB/g");
	this.shape_84.setTransform(-410.8,-4.55);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgfCOIAAg/IA+AAIAAA/gAgfAwIAAi9IA+AAIAAC9g");
	this.shape_85.setTransform(-53.25,-55);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgPCOQgfABgQgRQgQgPAAggIAgAAIAAAGQAAAMAKAHQAJAHAMAAQAQAAAHgIQAIgIAAgQQAAgMgJgKIhDhLQgSgUAAgZIAAgPQAAgaASgTQATgSAaAAIAfAAQA8gBADBAIgfAAQgFgggZAAQgRAAgHAIQgJAIAAAQQAAAMAJAKIBDBKQASAWAAAXIAAAQQAAAagSATQgTASgaAAg");
	this.shape_86.setTransform(-73.825,-55);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("ABhCOIividIAACdIggAAIAAkbIAPAAICuCdIAAidIAgAAIAAEbg");
	this.shape_87.setTransform(-99.15,-55);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AgfCOQgZAAgTgSQgTgTAAgaIAAidQAAgaATgTQATgSAZAAIA/AAQAaAAASASQATATAAAaIAACdQAAAagTATQgSASgaAAgAgVhlQgKAKAAANIAACdQAAANAKAKQAJAJAMAAQAOAAAIgJQAKgKAAgNIAAidQAAgNgKgKQgIgJgOAAQgMAAgJAJg");
	this.shape_88.setTransform(-126.05,-55);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgfCOIAAkbIA+AAIAAEbg");
	this.shape_89.setTransform(-148.2,-55);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgfCOIAAj8Ig/AAIAAgfIC9AAIAAAfIhAAAIAAD8g");
	this.shape_90.setTransform(-167.2,-55);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AAgCOIAAh+Ig/AAIAAB+Ig/AAIAAjcQAAgaATgTQASgSAaAAIA/AAQAaAAASASQATATAAAaIAADcgAgVhlQgKAKAAANIAAA/IA/AAIAAg/QAAgNgKgKQgJgJgNAAQgMAAgJAJg");
	this.shape_91.setTransform(-189.35,-55);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AhOCOIAAkbIA/AAIAAD8IBeAAIAAAfg");
	this.shape_92.setTransform(-213.075,-55);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AgeCOQgaAAgTgSQgTgTAAgaIAAjcIBAAAIAADcQAAANAJAKQAJAJAMAAQANAAAKgJQAJgKAAgNIAAjcIA/AAIAADcQAAAagSATQgUASgZAAg");
	this.shape_93.setTransform(-236.8,-55);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgeCOIAAj8IhAAAIAAgfIC9AAIAAAfIg/AAIAAD8g");
	this.shape_94.setTransform(-258.95,-55);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AAgCOIAAh+Ig+AAIAAB+IhAAAIAAjcQAAgaATgTQATgSAaAAIA+AAQAZAAAUASQASATAAAaIAADcgAgVhlQgJAKAAANIAAA/IA+AAIAAg/QAAgNgJgKQgJgJgOAAQgMAAgJAJg");
	this.shape_95.setTransform(-281.1,-55);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AAgCOIAAheQAAgOgJgJQgJgJgOAAIgeAAIAAB+IhAAAIAAkbIB+AAQAZAAAUASQASATAAAaIAAARQAAAWgPATQgOATggAAIgCAAIACAAIAdAAQANAAAKAJQAJAJAAAOIAABvgAgegPIAeAAQAOAAAJgJQAJgKAAgNIAAgfQAAgNgJgKQgJgJgOAAIgeAAg");
	this.shape_96.setTransform(-306.4,-55);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AgfCOQgZAAgTgSQgTgTAAgaIAAidQAAgaASgTQATgSAaAAIA/AAQA7gBAEBAIggAAQgDgggcAAIggAAQgMAAgJAJQgKAKAAANIAACdQAAAOAKAJQAJAJAMAAQAfgCABgeIAAg/IggAAIAAgfIBfAAIAABeQAAAggUAPQgUARgXgBg");
	this.shape_97.setTransform(-331.7,-55);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("ABhCOIividIAACdIggAAIAAkbIAPAAICuCdIAAidIAgAAIAAEbg");
	this.shape_98.setTransform(-358.6,-55);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AgeCOQgaAAgTgSQgTgTAAgaIAAidQAAgaATgTQATgSAaAAIA+AAQAZAAAUASQASATAAAaIAACdQAAAagSATQgUASgZAAgAgVhlQgJAKAAANIAACdQAAANAJAKQAJAJAMAAQAOAAAJgJQAJgKAAgNIAAidQAAgNgJgKQgJgJgOAAQgMAAgJAJg");
	this.shape_99.setTransform(-385.5,-55);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgeCOQgaAAgTgSQgTgTAAgaIAAidQAAgaATgTQASgSAbAAIA+AAQA8gBADBAIggAAQgDgggcAAIggAAQgMAAgJAJQgKAKABANIAACdQgBANAKAKQAJAJAMAAIAgAAQAcAAADggIAgAAQgEA/g7AAg");
	this.shape_100.setTransform(-410.8,-55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.scoreupdate}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CongratsText, new cjs.Rectangle(-425.4,-79.2,850.9,309.8), null);


(lib.Congrats3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.scoreupdate3 = new cjs.Text("0", "38px 'Silom'", "#ED9B38");
	this.scoreupdate3.name = "scoreupdate3";
	this.scoreupdate3.lineHeight = 50;
	this.scoreupdate3.parent = this;
	this.scoreupdate3.setTransform(-15.05,24.95);

	this.congratstext3 = new cjs.Text("CONGRATULATIONS! \nYOU HAVE MADE IT THROUGH 2018 AND HAVE \nPAID AMAZON\n\nJEFF BEZOS' NET WORTH IS ...", "38px 'Silom'");
	this.congratstext3.name = "congratstext3";
	this.congratstext3.lineHeight = 50;
	this.congratstext3.parent = this;
	this.congratstext3.setTransform(-300.7,-74.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.congratstext3},{t:this.scoreupdate3}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Congrats3, new cjs.Rectangle(-302.7,-76.6,852.0999999999999,254.2), null);


(lib.congrats2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.scoreupdate2 = new cjs.Text("0", "38px 'Silom'", "#ED9B38");
	this.scoreupdate2.name = "scoreupdate2";
	this.scoreupdate2.lineHeight = 50;
	this.scoreupdate2.parent = this;
	this.scoreupdate2.setTransform(-118,33.55);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgfAgIAAg/IA/AAIAAA/g");
	this.shape.setTransform(-88.725,210.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhOCOIAAkbICdAAIAAAfIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAfg");
	this.shape_1.setTransform(-106.125,199.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgPCOQgfAAgQgPQgQgQAAggIAgAAIAAAGQAAAMAKAHQAJAHAMAAQAQAAAHgIQAIgIAAgQQAAgMgJgKIhDhLQgSgUAAgZIAAgPQAAgaASgTQATgSAaAAIAfAAQA8AAADA/IgfAAQgFgggZAAQgRAAgHAIQgJAIAAAQQAAAMAJAKIBDBLQASAUAAAZIAAAPQAAAagSATQgTASgaAAg");
	this.shape_2.setTransform(-128.275,199.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgfCOIAAkbIA+AAIAAEbg");
	this.shape_3.setTransform(-148.85,199.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAgCOIAAheQAAgOgKgJQgJgJgNAAIgfAAIAAB+Ig/AAIAAkbIB+AAQAZAAATASQATATAAAaIAAARQAAAVgPAUQgOATggAAIgCAAIACAAIAeAAQANAAAJAJQAJAJAAAOIAABvgAgfgPIAfAAQANAAAJgJQAKgJAAgOIAAgfQAAgNgKgKQgJgJgNAAIgfAAg");
	this.shape_4.setTransform(-171,199.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhOCOIAAkbICdAAIAAAfIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAfg");
	this.shape_5.setTransform(-204.225,199.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAgCOIAAh+Ig/AAIAAB+Ig/AAIAAkbIA/AAIAAB+IA/AAIAAh+IA/AAIAAEbg");
	this.shape_6.setTransform(-227.95,199.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgfCOIAAj8Ig/AAIAAgfIC9AAIAAAfIhAAAIAAD8g");
	this.shape_7.setTransform(-250.1,199.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("ABhCOIividIAACdIggAAIAAkbIAPAAICuCdIAAidIAgAAIAAEbg");
	this.shape_8.setTransform(-283.35,199.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgeCOQgaAAgTgSQgTgTAAgaIAAidQAAgaATgTQATgSAaAAIA+AAQAZAAAUASQASATAAAaIAACdQAAAagSATQgUASgZAAgAgVhlQgJAKAAANIAACdQAAANAJAKQAJAJAMAAQANAAAKgJQAJgKAAgNIAAidQAAgNgJgKQgKgJgNAAQgMAAgJAJg");
	this.shape_9.setTransform(-310.25,199.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AheCOIAAkbIB+AAQAaAAASASQATATAAAaIAACdQAAAagTATQgSASgaAAgAgfBvIAfAAQANAAAJgJQAKgKAAgNIAAidQAAgNgKgKQgJgJgNAAIgfAAg");
	this.shape_10.setTransform(-345.05,199.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("ABgCOIiuidIAACdIggAAIAAkbIAPAAICuCdIAAidIAgAAIAAEbg");
	this.shape_11.setTransform(-371.95,199.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAgCOIAAh+Ig/AAIAAB+Ig/AAIAAjcQAAgaATgTQASgSAaAAIA/AAQAaAAASASQATATAAAaIAADcgAgVhlQgKAKAAANIAAA/IA/AAIAAg/QAAgNgKgKQgIgJgOAAQgMAAgJAJg");
	this.shape_12.setTransform(-398.85,199.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#ED9B38").s().p("ABhCPIivieIAACeIggAAIAAkdIAPAAICuCeIAAieIAgAAIAAEdg");
	this.shape_13.setTransform(365.35,149.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#ED9B38").s().p("AgeCPQgbAAgSgTQgTgTAAgaIAAidQAAgaATgTQASgTAbAAIA+AAQAZAAAUATQASATAAAaIAACdQAAAagSATQgUATgZAAgAgVhkQgKAIABAOIAACdQgBANAKAJQAJAKAMAAQAOAAAJgKQAJgJAAgNIAAidQAAgOgJgIQgJgKgOAAQgMAAgJAKg");
	this.shape_14.setTransform(338.45,149.35);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#ED9B38").s().p("AgfCPIAAkdIA+AAIAAEdg");
	this.shape_15.setTransform(316.3,149.35);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#ED9B38").s().p("AhOCPIAAkdIA/AAIAAD9IBeAAIAAAgg");
	this.shape_16.setTransform(295.725,149.35);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#ED9B38").s().p("AhOCPIAAkdIA/AAIAAD9IBeAAIAAAgg");
	this.shape_17.setTransform(273.575,149.35);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#ED9B38").s().p("AgfCPIAAkdIA+AAIAAEdg");
	this.shape_18.setTransform(253,149.35);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#ED9B38").s().p("AheCPIAAkdIB+AAQAZAAAUATQASATAAAaIAAAQQAAAcgQAQQgQAPgfADQAfAAAQATQAQATAAAZIAAAQQAAAagSATQgUATgZAAgAgfBvIAfAAQANAAAJgKQAKgJAAgNIAAggQAAgfggAAIgfAAgAgfgPIAfAAQANAAAJgJQAKgJAAgNIAAggQAAgOgKgIQgJgKgNAAIgfAAg");
	this.shape_19.setTransform(230.85,149.35);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#ED9B38").s().p("AgfCPQgaAAgSgTQgTgTAAgaIAAhuQAAgtAhghQAhggAsgBIAwAAIAAAgIggAAQgaAAgSATQgSATgBAaIAAAfQACgPAIgIQAIgIANAAIAgAAQAaAAASASQATATAAAZIAAA/QAAAagTATQgSATgaAAgAgVgGQgKAJAAANIAAA/QAAANAKAJQAJAKAMAAQAOAAAIgKQAKgJAAgNIAAg/QAAgNgKgJQgIgJgOAAQgMAAgJAJg");
	this.shape_20.setTransform(196.05,149.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#ED9B38").s().p("AgfAgIAAg/IA/AAIAAA/g");
	this.shape_21.setTransform(177.075,160.425);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#ED9B38").s().p("AheCPIAAggQAAghA9g0IAFgEQA8g0AAggIAAgQQAAgOgJgIQgKgKgNAAIgeAAQgeAAgCAgIggAAQAIhAA4AAIA+AAQAZAAAUATQASATAAAaIAAAQQAAAgg9A0IgFAEQg7A0AAAeIAAADIB9AAIAAAgg");
	this.shape_22.setTransform(158.1,149.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#ED9B38").s().p("AgPCPIAAjdIgfAAIAAggIA+ggIAfAAIAAEdg");
	this.shape_23.setTransform(131.25,149.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#ED9B38").s().p("AgPCuIAAgfQg/gGAAg6IAgAAIAAAGQAAAXAfADIAAhXIgtgpQgSgSAAgbIAAgQQAAg5A/gHIAAgfIAfAAIAAAfQA8AAADBAIgfAAQgFgggbAAIAABXIAtApQASASAAAbIAAAQQAAA4g/AIIAAAfgAAQBvQATgIAAgVQAAgPgTgUgAgihQQAAAJAFAHIAOASIAAhAQgTAIAAAWg");
	this.shape_24.setTransform(109.075,149.35);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgPCPQgfgBgQgPQgQgQAAggIAgAAIAAAFQAAANAKAHQAJAHAMAAQAQAAAHgIQAIgJAAgPQAAgMgJgLIhDhJQgSgVAAgYIAAgQQAAgaASgTQATgTAaAAIAfAAQA8AAADBAIgfAAQgFgggZAAQgRAAgHAIQgJAIAAAQQAAAMAJALIBDBJQASAWAAAXIAAAQQAAAagSATQgTATgaAAg");
	this.shape_25.setTransform(77.425,149.35);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgeCPIAAkdIA+AAIAAEdg");
	this.shape_26.setTransform(56.85,149.35);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAgCPIAAh/Ig/AAIAAB/Ig/AAIAAkdIA/AAIAAB/IA/AAIAAh/IA/AAIAAEdg");
	this.shape_27.setTransform(25.2,149.35);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgeCPIAAj9IhAAAIAAggIC9AAIAAAgIg/AAIAAD9g");
	this.shape_28.setTransform(3.05,149.35);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AAgCPIAAhgQAAgNgJgJQgKgJgNAAIgeAAIAAB/IhAAAIAAkdIB+AAQAZAAAUATQASATAAAaIAAARQAAAWgPATQgOATggABIgCAAIACAAIAdAAQAOAAAJAIQAJAJAAANIAABxgAgegPIAeAAQANAAAKgJQAJgJAAgNIAAggQAAgOgJgIQgKgKgNAAIgeAAg");
	this.shape_29.setTransform(-19.1,149.35);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgeCPQgaAAgTgTQgTgTAAgaIAAidQAAgaATgTQATgTAaAAIA+AAQAZAAAUATQASATAAAaIAACdQAAAagSATQgUATgZAAgAgVhkQgJAIAAAOIAACdQAAANAJAJQAJAKAMAAQAOAAAJgKQAJgJAAgNIAAidQAAgOgJgIQgJgKgOAAQgMAAgJAKg");
	this.shape_30.setTransform(-44.4,149.35);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgfCPIAAgKQgRAJgcABIhRAAIAAkdIA/AAIAAD9IAfAAQAOAAAJgKQAJgJAAgNIAAjdIA+AAIAAD9IAhAAQAMAAAJgKQAKgJAAgNIAAjdIA/AAIAACwQAAAtgfAfQggAhgtAAg");
	this.shape_31.setTransform(-76.05,149.35);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgeCPIAAj9IhAAAIAAggIC9AAIAAAgIg/AAIAAD9g");
	this.shape_32.setTransform(-114.05,149.35);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AhOCPIAAkdICdAAIAAAgIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAgg");
	this.shape_33.setTransform(-134.625,149.35);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("ABgCPIiuieIAACeIggAAIAAkdIAPAAICuCeIAAieIAgAAIAAEdg");
	this.shape_34.setTransform(-159.95,149.35);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgPAwIAAhfIAfAAIAABfg");
	this.shape_35.setTransform(-188.45,139.85);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgPCPQgfgBgQgPQgQgQAAggIAgAAIAAAFQAAANAKAHQAJAHAMAAQAQAAAHgIQAIgJAAgPQAAgMgJgLIhDhJQgSgVAAgYIAAgQQAAgaASgTQATgTAaAAIAfAAQA8AAADBAIgfAAQgFgggZAAQgRAAgHAIQgJAIAAAQQAAAMAJALIBDBJQASAWAAAXIAAAQQAAAagSATQgTATgaAAg");
	this.shape_36.setTransform(-204.275,149.35);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgeCPQgaAAgTgTQgTgTAAgaIAAidQAAgaATgTQATgTAaAAIA+AAQAZAAAUATQASATAAAaIAACdQAAAagSATQgUATgZAAgAgVhkQgJAIAAAOIAACdQAAANAJAJQAJAKAMAAQAOAAAJgKQAJgJAAgNIAAidQAAgOgJgIQgJgKgOAAQgMAAgJAKg");
	this.shape_37.setTransform(-228,149.35);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AheCPIAAggIB+jdIh+AAIAAggIC9AAIAAAgIh9DdIB9AAIAAAgg");
	this.shape_38.setTransform(-253.3,149.35);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AhOCPIAAkdICdAAIAAAgIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAgg");
	this.shape_39.setTransform(-277.025,149.35);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AheCPIAAkdIB+AAQAaAAASATQATATAAAaIAAAQQAAAcgPAQQgRAPgfADQAfAAARATQAPATAAAZIAAAQQAAAagTATQgSATgaAAgAgfBvIAfAAQAOAAAIgKQAKgJAAgNIAAggQAAgfggAAIgfAAgAgfgPIAfAAQAOAAAIgJQAKgJAAgNIAAggQAAgOgKgIQgIgKgOAAIgfAAg");
	this.shape_40.setTransform(-300.75,149.35);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AhOCPIAAkdICdAAIAAAgIheAAIAABfIA/AAIAAAfIg/AAIAAB/g");
	this.shape_41.setTransform(-333.975,149.35);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AhOCPIAAkdICdAAIAAAgIheAAIAABfIA/AAIAAAfIg/AAIAAB/g");
	this.shape_42.setTransform(-356.125,149.35);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AhOCPIAAkdICdAAIAAAgIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAgg");
	this.shape_43.setTransform(-378.275,149.35);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgfCPQgfgBgQgPQgQgQAAggIAAg/IA/AAIAAA/QABAOAIAIQAKAKAMAAQANAAAJgKQAJgIAAgOIAAjdIBAAAIAADdQAAAggQAQQgPAPghABg");
	this.shape_44.setTransform(-402,149.35);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("ABgCPIiuieIAACeIggAAIAAkcIAPAAICuCdIAAidIAgAAIAAEcg");
	this.shape_45.setTransform(-153.65,48.45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgeCPQgagBgTgSQgTgTAAgaIAAidQAAgaATgTQATgTAaABIA+AAQAZgBAUATQASATAAAaIAACdQAAAagSATQgUASgZABgAgVhkQgJAIAAAOIAACdQAAANAJAJQAJAKAMAAQANAAAKgKQAJgJAAgNIAAidQAAgOgJgIQgKgKgNAAQgMAAgJAKg");
	this.shape_46.setTransform(-180.55,48.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AheCPIAAggIB+jdIh+AAIAAgfIC9AAIAAAfIh9DdIB9AAIAAAgg");
	this.shape_47.setTransform(-205.85,48.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AAgCPIAAh/Ig+AAIAAB/IhAAAIAAjdQAAgaATgTQATgTAaABIA+AAQAZgBAUATQASATAAAaIAADdgAgVhkQgJAIAAAOIAAA/IA+AAIAAg/QAAgOgJgIQgJgKgOAAQgMAAgJAKg");
	this.shape_48.setTransform(-231.15,48.45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("ABfCPIAAiuIhuBvIhvhvIAACuIgfAAIAAkcIAPAAICHCHICGiHIAfAAIAAEcg");
	this.shape_49.setTransform(-262.8,48.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AAgCPIAAh/Ig/AAIAAB/Ig/AAIAAjdQAAgaATgTQASgTAaABIA/AAQAagBASATQATATAAAaIAADdgAgVhkQgKAIAAAOIAAA/IA/AAIAAg/QAAgOgKgIQgIgKgOAAQgMAAgJAKg");
	this.shape_50.setTransform(-294.45,48.45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AheCPIAAkcIB+AAQAZgBAUATQASATAAAaIAACdQAAAagSATQgUASgZABgAgeBvIAeAAQAOAAAJgKQAJgJAAgNIAAidQAAgOgJgIQgJgKgOAAIgeAAg");
	this.shape_51.setTransform(-329.25,48.45);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgeCPIAAkcIA+AAIAAEcg");
	this.shape_52.setTransform(-351.4,48.45);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AAgCPIAAh/Ig/AAIAAB/Ig/AAIAAjdQAAgaATgTQATgTAZABIA/AAQAagBASATQATATAAAaIAADdgAgVhkQgKAIAAAOIAAA/IA/AAIAAg/QAAgOgKgIQgIgKgOAAQgMAAgJAKg");
	this.shape_53.setTransform(-373.55,48.45);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AheCPIAAkcIB+AAQAagBASATQATATAAAaIAAAgQAAAZgTATQgSASgaAAIg/AAIAAB/gAgfgPIAfAAQAOAAAIgJQAKgJAAgNIAAggQAAgOgKgIQgIgKgOAAIgfAAg");
	this.shape_54.setTransform(-398.85,48.45);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AhOCOIAAkcICdAAIAAAgIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAfg");
	this.shape_55.setTransform(415.775,-2);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AheCOIAAkcIA/AAIAAD9IAfAAQANAAAJgJQAKgKAAgNIAAjdIA/AAIAACwQAAAsgfAhQghAfgrAAg");
	this.shape_56.setTransform(392.05,-2);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AAgCOIAAh+Ig+AAIAAB+IhAAAIAAjcQAAgaATgTQASgSAbgBIA+AAQAZABATASQATATAAAaIAADcgAgVhlQgKAKABANIAAA/IA+AAIAAg/QAAgNgJgKQgKgJgNAAQgMAAgJAJg");
	this.shape_57.setTransform(366.75,-2);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AAgCOIAAh+Ig+AAIAAB+IhAAAIAAkcIBAAAIAAB/IA+AAIAAh/IA/AAIAAEcg");
	this.shape_58.setTransform(341.45,-2);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AheCOIAAkcIB+AAQAaABASASQATATAAAaIAACdQAAAagTATQgSASgaAAgAgfBvIAfAAQAOAAAIgJQAKgKAAgNIAAidQAAgNgKgKQgIgJgOAAIgfAAg");
	this.shape_59.setTransform(306.65,-2);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("ABhCOIividIAACdIggAAIAAkcIAPAAICuCeIAAieIAgAAIAAEcg");
	this.shape_60.setTransform(279.75,-2);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AAgCOIAAh+Ig/AAIAAB+Ig/AAIAAjcQAAgaATgTQATgSAZgBIA/AAQAaABASASQATATAAAaIAADcgAgVhlQgKAKAAANIAAA/IA/AAIAAg/QAAgNgKgKQgIgJgOAAQgMAAgJAJg");
	this.shape_61.setTransform(252.85,-2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgeCOQgaAAgTgSQgTgTAAgaIAAidQAAgaATgTQATgSAagBIA+AAQAZABAUASQASATAAAaIAACdQAAAagSATQgUASgZAAgAgeBVQADAMAHAHQAIAHAMAAQANAAAKgJQAJgKAAgNIAAhrgAgVhlQgJAKAAANIAABqIA+hwQgIgagYAAQgMAAgJAJg");
	this.shape_62.setTransform(218.05,-2);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AgPCOIAAjcIgfAAIAAggIA+ggIAfAAIAAEcg");
	this.shape_63.setTransform(191.2,-2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgeCOQgbAAgSgSQgTgTAAgaIAAidQAAgaATgTQASgSAbgBIA+AAQAZABAUASQASATAAAaIAACdQAAAagSATQgUASgZAAgAgeBVQACAMAJAHQAHAHAMAAQAOAAAJgJQAJgKAAgNIAAhrgAgVhlQgKAKABANIAABqIA+hwQgIgagYAAQgMAAgJAJg");
	this.shape_64.setTransform(167.45,-2);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AheCOIAAgfQAAghA9g1IAFgDQA8gzAAgiIAAgPQAAgNgKgKQgJgJgNAAIgfAAQgdAAgCAgIggAAQAHhAA4AAIA/AAQAaABASASQATATAAAaIAAAPQAAAig9AzIgFADQg7A1gBAeIAAADIB+AAIAAAfg");
	this.shape_65.setTransform(142.15,-2);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AAgCOIAAh+Ig+AAIAAB+IhAAAIAAkcIBAAAIAAB/IA+AAIAAh/IA/AAIAAEcg");
	this.shape_66.setTransform(107.35,-2);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgeCOQgaAAgTgSQgTgTAAgaIAAidQAAgaATgTQASgSAbgBIA+AAQA8AAADBAIggAAQgEgggbAAIggAAQgMAAgJAJQgJAKAAANIAACdQAAAOAJAJQAJAJAMAAQAegBACgfIAAg/IggAAIAAgfIBfAAIAABeQAAAggUAPQgUARgXgBg");
	this.shape_67.setTransform(82.05,-2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgeCOQgbAAgSgSQgTgTAAgaIAAjdIBAAAIAADdQgBANAKAKQAJAJAMAAQAOAAAJgJQAJgKAAgNIAAjdIA/AAIAADdQAAAagSATQgUASgZAAg");
	this.shape_68.setTransform(56.75,-2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AgfCOQgZAAgTgSQgTgTAAgaIAAidQAAgaATgTQATgSAZgBIA/AAQAaABASASQATATAAAaIAACdQAAAagTATQgSASgaAAgAgVhlQgKAKAAANIAACdQAAANAKAKQAJAJAMAAQAOAAAIgJQAKgKAAgNIAAidQAAgNgKgKQgIgJgOAAQgMAAgJAJg");
	this.shape_69.setTransform(31.45,-2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AAgCOIAAheQAAgOgKgJQgIgJgOAAIgfAAIAAB+Ig/AAIAAkcIB+AAQAaABASASQATATAAAaIAAARQAAAVgOAUQgPATggAAIgCAAIACAAIAeAAQAMAAAKAJQAJAJAAAOIAABvgAgfgPIAfAAQAOAAAIgJQAKgKAAgNIAAgfQAAgNgKgKQgIgJgOAAIgfAAg");
	this.shape_70.setTransform(6.15,-2);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AAgCOIAAh+Ig/AAIAAB+Ig/AAIAAkcIA/AAIAAB/IA/AAIAAh/IA/AAIAAEcg");
	this.shape_71.setTransform(-19.15,-2);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgfCOIAAj8Ig/AAIAAggIC9AAIAAAgIhAAAIAAD8g");
	this.shape_72.setTransform(-41.3,-2);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AgfCOIAAj8Ig/AAIAAggIC9AAIAAAgIhAAAIAAD8g");
	this.shape_73.setTransform(-69.8,-2);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AgfCOIAAkcIA+AAIAAEcg");
	this.shape_74.setTransform(-88.8,-2);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AhOCOIAAkcICdAAIAAAgIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAfg");
	this.shape_75.setTransform(-118.875,-2);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AheCOIAAkcIB+AAQAZABAUASQASATAAAaIAACdQAAAagSATQgUASgZAAgAgeBvIAeAAQAOAAAJgJQAJgKAAgNIAAidQAAgNgJgKQgJgJgOAAIgeAAg");
	this.shape_76.setTransform(-142.6,-2);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AAgCOIAAh+Ig/AAIAAB+Ig/AAIAAjcQAAgaATgTQATgSAZgBIA/AAQAaABASASQATATAAAaIAADcgAgVhlQgKAKAAANIAAA/IA/AAIAAg/QAAgNgKgKQgIgJgOAAQgMAAgJAJg");
	this.shape_77.setTransform(-167.9,-2);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("ABfCOIAAisIhuBtIhvhtIAACsIgfAAIAAkcIAOAAICHCHICGiHIAhAAIAAEcg");
	this.shape_78.setTransform(-199.55,-2);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AhOCOIAAkcICdAAIAAAgIheAAIAABfIA/AAIAAAfIg/AAIAABfIBeAAIAAAfg");
	this.shape_79.setTransform(-239.125,-2);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AheCOIAAkcIA/AAIAAD9IAfAAQAOAAAIgJQAKgKAAgNIAAjdIA/AAIAACwQAAAsggAhQgfAfgsAAg");
	this.shape_80.setTransform(-262.85,-2);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AAgCOIAAh+Ig/AAIAAB+Ig/AAIAAjcQAAgaATgTQASgSAagBIA/AAQAaABASASQATATAAAaIAADcgAgVhlQgKAKAAANIAAA/IA/AAIAAg/QAAgNgKgKQgIgJgOAAQgMAAgJAJg");
	this.shape_81.setTransform(-288.15,-2);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AAgCOIAAh+Ig/AAIAAB+Ig/AAIAAkcIA/AAIAAB/IA/AAIAAh/IA/AAIAAEcg");
	this.shape_82.setTransform(-313.45,-2);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgeCOQgbAAgSgSQgTgTAAgaIAAjdIBAAAIAADdQgBANAKAKQAJAJAMAAQAOAAAJgJQAJgKAAgNIAAjdIA/AAIAADdQAAAagSATQgUASgZAAg");
	this.shape_83.setTransform(-348.25,-2);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AgfCOQgZAAgTgSQgTgTAAgaIAAidQAAgaATgTQATgSAZgBIA/AAQAaABASASQATATAAAaIAACdQAAAagTATQgSASgaAAgAgVhlQgKAKAAANIAACdQAAANAKAKQAJAJAMAAQAOAAAIgJQAKgKAAgNIAAidQAAgNgKgKQgIgJgOAAQgMAAgJAJg");
	this.shape_84.setTransform(-373.55,-2);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgfCOIAAh+Qg/gIAAg3IAAhfIA/AAIAABfQAAANAKAKQAJAJAMAAQAOAAAIgJQAKgKAAgNIAAhfIA/AAIAABfQAAA3g/AIIAAB+g");
	this.shape_85.setTransform(-398.85,-2);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgfCPIAAhAIA+AAIAABAgAgfAvIAAi8IA+AAIAAC8g");
	this.shape_86.setTransform(-41.3,-52.45);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgPCPQgfAAgQgQQgQgQAAggIAgAAIAAAFQAAANAKAHQAJAHAMAAQAQAAAHgIQAIgJAAgPQAAgMgJgLIhDhJQgSgVAAgYIAAgQQAAgaASgTQATgSAaAAIAfAAQA8AAADA/IgfAAQgFgggZAAQgRAAgHAIQgJAIAAAQQAAAMAJAKIBDBLQASAUAAAZIAAAPQAAAagSATQgTASgaABg");
	this.shape_87.setTransform(-61.875,-52.45);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("ABgCPIiuieIAACeIggAAIAAkcIAPAAICuCdIAAidIAgAAIAAEcg");
	this.shape_88.setTransform(-87.2,-52.45);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgfCPQgagBgSgSQgTgTAAgaIAAidQAAgaATgTQASgSAaAAIA/AAQAaAAASASQATATAAAaIAACdQAAAagTATQgSASgaABgAgVhlQgKAJAAAOIAACdQAAANAKAJQAJAKAMAAQAOAAAIgKQAKgJAAgNIAAidQAAgOgKgJQgIgJgOAAQgMAAgJAJg");
	this.shape_89.setTransform(-114.1,-52.45);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgfCPIAAkcIA+AAIAAEcg");
	this.shape_90.setTransform(-136.25,-52.45);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgfCPIAAj9Ig/AAIAAgfIC9AAIAAAfIhAAAIAAD9g");
	this.shape_91.setTransform(-155.25,-52.45);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AAgCPIAAh/Ig+AAIAAB/IhAAAIAAjdQAAgaATgTQATgSAaAAIA+AAQAZAAAUASQASATAAAaIAADdgAgVhlQgJAJAAAOIAAA/IA+AAIAAg/QAAgOgJgJQgKgJgNAAQgMAAgJAJg");
	this.shape_92.setTransform(-177.4,-52.45);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AhOCPIAAkcIA/AAIAAD8IBeAAIAAAgg");
	this.shape_93.setTransform(-201.125,-52.45);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgeCPQgagBgTgSQgTgTAAgaIAAjcIBAAAIAADcQAAANAJAJQAJAKAMAAQAOAAAJgKQAJgJAAgNIAAjcIA/AAIAADcQAAAagSATQgUASgZABg");
	this.shape_94.setTransform(-224.85,-52.45);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgeCPIAAj9IhAAAIAAgfIC9AAIAAAfIg/AAIAAD9g");
	this.shape_95.setTransform(-247,-52.45);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AAgCPIAAh/Ig/AAIAAB/Ig/AAIAAjdQAAgaATgTQATgSAZAAIA/AAQAaAAASASQATATAAAaIAADdgAgVhlQgKAJAAAOIAAA/IA/AAIAAg/QAAgOgKgJQgIgJgOAAQgMAAgJAJg");
	this.shape_96.setTransform(-269.15,-52.45);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AAgCPIAAhgQAAgMgKgKQgIgJgOAAIgfAAIAAB/Ig/AAIAAkcIB+AAQAaAAASASQATATAAAaIAAARQAAAVgOAUQgPATggABIgCAAIACAAIAeAAQAMgBAKAJQAJAJAAANIAABxgAgfgPIAfAAQAOAAAIgJQAKgJAAgOIAAgfQAAgOgKgJQgIgJgOAAIgfAAg");
	this.shape_97.setTransform(-294.45,-52.45);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AgfCPQgagBgSgSQgTgTAAgaIAAidQAAgaASgTQATgSAaAAIA/AAQA8AAADA/IgfAAQgEgggcAAIggAAQgMAAgJAJQgKAJAAAOIAACdQAAANAKAJQAJAKAMAAQAegCACgeIAAg/IggAAIAAgfIBfAAIAABeQAAAggUAQQgUAQgXAAg");
	this.shape_98.setTransform(-319.75,-52.45);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("ABhCPIivieIAACeIggAAIAAkcIAPAAICuCdIAAidIAgAAIAAEcg");
	this.shape_99.setTransform(-346.65,-52.45);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgfCPQgZgBgTgSQgTgTAAgaIAAidQAAgaATgTQATgSAZAAIA/AAQAaAAASASQATATAAAaIAACdQAAAagTATQgSASgaABgAgVhlQgKAJAAAOIAACdQAAANAKAJQAJAKAMAAQAOAAAIgKQAKgJAAgNIAAidQAAgOgKgJQgIgJgOAAQgMAAgJAJg");
	this.shape_100.setTransform(-373.55,-52.45);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AgfCPQgagBgSgSQgTgTAAgaIAAidQAAgaASgTQATgSAaAAIA/AAQA7AAAEA/IgfAAQgEgggcAAIggAAQgMAAgJAJQgKAJAAAOIAACdQAAANAKAJQAJAKAMAAIAgAAQAcAAAEggIAfAAQgEBAg7AAg");
	this.shape_101.setTransform(-398.85,-52.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.scoreupdate2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.congrats2, new cjs.Rectangle(-413.5,-76.6,852.1,304.7), null);


(lib.ComputerArticle3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6D76").s().p("EhK/ArwMAAAhXfMCV/AAAMAAABXfgEg2rAfQMBtXAAAMAAAg+fMhtXAAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ComputerArticle3, new cjs.Rectangle(-480,-280,960,560), null);


(lib.ComputerArticle2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2C3544").s().p("EhK/ArwMAAAhXfMCV/AAAMAAABXfgEg2rAfQMBtXAAAMAAAg+fMhtXAAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ComputerArticle2, new cjs.Rectangle(-480,-280,960,560), null);


(lib.Computer3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2A2574").s().p("A/PR+MAAAgj7MA+fAAAMAAAAj7g");
	this.shape.setTransform(0,-55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#141415").s().p("AsfJYIAAksIBkAAIAAhkIV3AAIAABkIBkAAIAAEsgA/PmPIAAjIMA+fAAAIAADIg");
	this.shape_1.setTransform(0,120);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6D6D76").s().p("EgnDAeeIAAhkIhkAAIAAjIIBkAAIAAjIIBkAAIAAjIIBkAAIAAjIIBkAAIAAjIIBkAAMAAAgqLIBkAAIAAhkMA+fAAAIAABkIBkAAMAAAAqLIBkAAIAADIIBkAAIAADIIBkAAIAADIIBkAAIAADIIBkAAIAADIIhkAAIAABkgAsfbWIY/AAIAAksIhkAAIAAhkI13AAIAABkIhkAAgA/PImIAADIMA+fAAAIAAjIMAAAgj7Mg+fAAAg");
	this.shape_2.setTransform(0,5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Computer3, new cjs.Rectangle(-260,-190,520,390), null);


(lib.Computer2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2C547E").s().p("AyvNSIAA6jMAlfAAAIAAajg");
	this.shape.setTransform(-70,-35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EAEDED").s().p("AldGQIAAhkIBkAAIAABkgAolGQIAAhkIBkAAIAABkgArtGQIAAhkIBkAAIAABkgAx9GQIAAjIIDIAAIAADIgAO2BkIAAjHIDIAAIAADHgAO2krIAAhkIDIAAIAABkg");
	this.shape_1.setTransform(35,40);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7B8284").s().p("AkrQaIAAhkIhkAAIAAhkIjIAAIAA9rISvAAIAAdrIjIAAIAABkIhkAAIAABkgAhjLuIDHAAIAAjIIjHAAgAhjFeIDHAAIAAhkIjHAAgAnzqJIPnAAIAAksIvnAAg");
	this.shape_2.setTransform(140,-25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#374142").s().p("AZAZAIAAhkIhkAAIAAjIIksAAIAAEsMg4PAAAIAAksIBkAAIAAjIIBkAAIAAhkMA2rAAAIAADIIEsAAIAAhkIH0AAIAABkIDIAAIAABkIBkAAIAADIIhkAAIAABkgAOEOEIAAn0IDIAAIAABkIBkAAIAABkIJYAAIAAhkIBkAAIAAhkIDIAAIAAH0gA13OEIAAhkIBkAAIAAhkIq8AAMAAAgj7MArvAAAMAAAAj7IpYAAIAABkIBkAAIAABkgABkJYIBkAAIAAhkIhkAAgAhjJYIBjAAIAAhkIhjAAgAkrJYIBkAAIAAhkIhkAAgAq7JYIDIAAIAAjIIjIAAgA8HEsMAlfAAAIAA6jMglfAAAgAPoxLIAAksIPoAAIAAEsg");
	this.shape_3.setTransform(-10,20);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Computer2, new cjs.Rectangle(-250,-140,480,320), null);


(lib.Computer1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2C291F").s().p("AAyD6IAAhkIDIAAIAABkgAiVAyIAAhjIksAAIAAhkIEsAAIAAhkIErAAIAABkIEsAAIAABkIksAAIAABjg");
	this.shape.setTransform(85,85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4E4643").s().p("AzhOEIAA8HMAnDAAAIAAcHg");
	this.shape_1.setTransform(15,-70);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C3AD9F").s().p("AZyHCIAAhkIhkAAIAAhkIhkAAIAAhkIhkAAIAAhkIhkAAIAAjHIhkAAIAAjIIhkAAIAAhkIDIAAIAADIIBkAAIAADIIBkAAIAABjIBkAAIAABkIBkAAIAABkIBkAAIAABkIBkAAIAABkgA85AyIAAhjIBkAAIAAhkMAnDAAAIAABkIBkAAIAABjgAAyldIAAhkIBkAAIAABkgAj5ldIAAhkIDIAAIAABkg");
	this.shape_2.setTransform(65,145);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#876B57").s().p("Egn1ALuIAAhkMBOHAAAIBkAAIAABkgATildIAAhkIBkAAIAABkgAtRqJIAAhkISvAAIAABkg");
	this.shape_3.setTransform(-5,145);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D7C2BB").s().p("EAj8Ag0IAAhkIhkAAIAAhkIAAhkIBkAAIAAhkIGQAAIAABkIDIAAIAAEsgEgtTAg0IAAjIIDIAAIAAhkIBkAAIAAhkIBkAAIAAjIIPoAAMAqLAAAIGQAAIBkAAIAABkIBkAAIAABkIBkAAIAABkIBkAAIAABkIAABkIBkAAIAABkgA13UUIAAhkIksAAMAAAgx/IDIAAIAAhkMAqLAAAIAABkIDIAAMAAAAu3IAABkIAABkIksAAIAABkgAOERMIBkAAIAAhkIhkAAgAJYRMIDIAAIAAhkIjIAAgAGQRMIBkAAIAAhkIhkAAgABkRMIDIAAIAAhkIjIAAgABkMgIEsAAIAABkIEsAAIAAhkIEsAAIAAhkIksAAIAAhkIksAAIAABkIksAAgAyvMgISvAAIAAhkIyvAAgA13DIMAnDAAAIAA8HMgnDAAAg");
	this.shape_4.setTransform(30,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Computer1, new cjs.Rectangle(-260,-210,580,430), null);


(lib.Cloud22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_0_1();
	this.instance.parent = this;
	this.instance.setTransform(200,200,0.0945,0.0945,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Cloud22, new cjs.Rectangle(0,0,200,200), null);


(lib.Cloud11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_1_2();
	this.instance.parent = this;
	this.instance.setTransform(200.05,0,0.0945,0.0945,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Cloud11, new cjs.Rectangle(0.1,0,200,200), null);


(lib.Cloud3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image();
	this.instance.parent = this;
	this.instance.setTransform(-100,0,0.0945,0.0945);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Cloud3, new cjs.Rectangle(-100,0,200,200), null);


(lib.Cloud2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_0();
	this.instance.parent = this;
	this.instance.setTransform(-100,0,0.0945,0.0945);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Cloud2, new cjs.Rectangle(-100,0,200,200), null);


(lib.Cloud1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_1_1();
	this.instance.parent = this;
	this.instance.setTransform(-836,-13,0.0945,0.0945);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Cloud1, new cjs.Rectangle(-836,-13,200,200), null);


(lib.PlayButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F19D38").s().p("ABkFeIAAhkIBkAAIAABkgADID6IAAhkIBkAAIAABkgADID6gAmPD6IAAhkIBkAAIAABkgAhjCWIAAhkIBjAAIAABkgAuDCWIAAhkIDIAAIAABkgAAAAyIAAhjIEsAAIAABjgAAAAygAMggxIAAhkIhkAAIAAhkIhkAAIAAhkIBkAAIAABkIBkAAIAABkIBkAAIAAhkIBkAAIAAhkIBkAAIAABkIhkAAIAABkIhkAAIAABkgAGQiVIAAhkIksAAIAAhkIEsAAIAABkIBkAAIAABkgAAAiVIAAhkIBkAAIAABkgAq7iVIAAhkIjIAAIAAhkIDIAAIAABkIDIAAIAABkgAvniVIAAhkIhkAAIAAhkIBkAAIAABkIBkAAIAABkgABkj5gAmPj5IAAhkIDIAAIAABkgAuDj5g");
	this.shape.setTransform(450.25,245.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AMgFeIAAksIhkAAIAAhjIhkAAIAAksIBkAAIAABkIBkAAIAABkIBkAAIAAhkIBkAAIAAhkIBkAAIAAEsIhkAAIAABjIhkAAIAAEsgAGQFeIAAhkIhkAAIAABkIksAAIAAhkIhjAAIAAjIIBjAAIAAhjIEsAAIAAhkIksAAIAAhkIBkAAIAAhkIEsAAIAABkIBkAAIAAJXgABkCWIAABkIBkAAIAAhkIBkAAIAAhkIhkAAIhkAAgAmPFeIAAjIIBkAAIAAhkIAAkrIhkAAIAAhkIDIAAIAAK7gAxLFeIAAq7IBkAAIAABkIBkAAIAAhkIDIAAIAABkIDIAAIAAGPImQAAIAABkIhkAAIAABkgAuDgxIAABjIDIAAIAAhjIAAhkIjIAAg");
	this.shape_1.setTransform(450.25,255.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ABkFeIAAhkIBkAAIAABkgADID6IAAhkIBkAAIAABkgADID6gAmPD6IAAhkIBkAAIAABkgAhjCWIAAhkIBjAAIAABkgAuDCWIAAhkIDIAAIAABkgAAAAyIAAhjIEsAAIAABjgAAAAygAMggxIAAhkIhkAAIAAhkIhkAAIAAhkIBkAAIAABkIBkAAIAABkIBkAAIAAhkIBkAAIAAhkIBkAAIAABkIhkAAIAABkIhkAAIAABkgAGQiVIAAhkIksAAIAAhkIEsAAIAABkIBkAAIAABkgAAAiVIAAhkIBkAAIAABkgAq7iVIAAhkIjIAAIAAhkIDIAAIAABkIDIAAIAABkgAvniVIAAhkIhkAAIAAhkIBkAAIAABkIBkAAIAABkgABkj5gAmPj5IAAhkIDIAAIAABkgAuDj5g");
	this.shape_2.setTransform(450.25,245.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F19D38").s().p("AMgFeIAAksIhkAAIAAhjIhkAAIAAksIBkAAIAABkIBkAAIAABkIBkAAIAAhkIBkAAIAAhkIBkAAIAAEsIhkAAIAABjIhkAAIAAEsgAGQFeIAAhkIhkAAIAABkIksAAIAAhkIhjAAIAAjIIBjAAIAAhjIEsAAIAAhkIksAAIAAhkIBkAAIAAhkIEsAAIAABkIBkAAIAAJXgABkCWIAABkIBkAAIAAhkIBkAAIAAhkIhkAAIhkAAgAmPFeIAAjIIBkAAIAAhkIAAkrIhkAAIAAhkIDIAAIAAK7gAxLFeIAAq7IBkAAIAABkIBkAAIAAhkIDIAAIAABkIDIAAIAAGPImQAAIAABkIhkAAIAABkgAuDgxIAABjIDIAAIAAhjIAAhkIjIAAg");
	this.shape_3.setTransform(450.25,255.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F19D38").s().p("ABkFeIAAhkIBkAAIAABkgADID6IAAhkIBkAAIAABkgADID6gAmPD6IAAhkIBkAAIAABkgAhjCWIAAhkIBjAAIAAhjIEsAAIAABjIksAAIAABkgAuDCWIAAhkIDIAAIAABkgAMggxIAAhkIhkAAIAAhkIhkAAIAAhkIBkAAIAABkIBkAAIAABkIBkAAIAABkgAOEiVIAAhkIBkAAIAABkgAGQiVIAAhkIksAAIAAhkIEsAAIAABkIBkAAIAABkgAAAiVIAAhkIBkAAIAABkgAq7iVIAAhkIDIAAIAABkgAvniVIAAhkIhkAAIAAhkIBkAAIAABkIBkAAIAABkgAPoj5IAAhkIBkAAIAABkgAPoj5gABkj5gAmPj5IAAhkIDIAAIAABkgAuDj5IAAhkIDIAAIAABkgAuDj5g");
	this.shape_4.setTransform(450.25,245.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_1},{t:this.shape_4}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(340.3,210.3,219.99999999999994,80);


(lib.nexttwo_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// NextTwoButton
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED9B38").s().p("ADHDHIAAhkIBkAAIAABkgAAADHIAAhkIBkAAIAABkgAjGDHIAAhkIBkAAIAABkgABkBjIAAhjIhkAAIAAhjIBkAAIAABjIBjAAIAABjgAJVAAIAAhjIBkAAIAABjgAGOAAIAAhjIBkAAIAABjgADHAAIAAhjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjgAHyhjIAAhjIBjAAIAABjg");
	this.shape.setTransform(94.025,119.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkIAAhkIhkAAIAAhiIBkAAIAABiIBjAAIAABkgABkBkgADHAAIAAhiIBkAAIAABigADHAAg");
	this.shape_1.setTransform(94.025,129.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ADHDHIAAhkIBkAAIAABkgAAADHIAAhkIBkAAIAABkgAjGDHIAAhkIBkAAIAABkgABkBjIAAhjIhkAAIAAhjIBkAAIAABjIBjAAIAABjgAJVAAIAAhjIBkAAIAABjgAGOAAIAAhjIBkAAIAABjgADHAAIAAhjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjgAHyhjIAAhjIBjAAIAABjg");
	this.shape_2.setTransform(94.025,119.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#ED9B38").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkIAAhkIhkAAIAAhiIBkAAIAABiIBjAAIAABkgABkBkgADHAAIAAhiIBkAAIAABigADHAAg");
	this.shape_3.setTransform(94.025,129.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#ED9B38").s().p("ADHDHIAAhkIBkAAIAABkgAAADHIAAhkIBkAAIAABkgAjGDHIAAhkIBkAAIAABkgABkBjIAAhjIhkAAIAAhjIBkAAIAABjIBjAAIAAhjIBkAAIAABjIhkAAIAABjgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape_4.setTransform(94.025,119.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_1},{t:this.shape_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(24.4,99.2,139.29999999999998,49.7);


(lib.nextbutton1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// NextBtn#1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#876B57").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkIAAhkIBjAAIAABkgABkBkgADHAAIAAhiIBkAAIAABigAAAAAIAAhiIBkAAIAABig");
	this.shape.setTransform(79.825,86.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C3AD9F").s().p("ADHDHIAAhkIhjAAIAAhjIhkAAIAAhjIBkAAIAABjIBjAAIAABjIBkAAIAABkgAAADHIAAhkIBkAAIAABkgAjGDHIAAhkIBkAAIAABkgAJVAAIAAhjIhjAAIAAhjIBjAAIAABjIBkAAIAABjgAGOAAIAAhjIBkAAIAABjgADHAAIAAhjIBkAAIAABjgADHAAgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjgAHyhjg");
	this.shape_1.setTransform(79.825,76.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#876B57").s().p("ADHDHIAAhkIBkAAIAABkgAAADHIAAhkIBkAAIAABkgAjGDHIAAhkIBkAAIAABkgABkBjIAAhjIhkAAIAAhjIBkAAIAABjIBjAAIAAhjIBkAAIAABjIhkAAIAABjgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape_2.setTransform(79.825,76.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C3AD9F").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkIAAhkIhkAAIAAhiIBkAAIAABiIBjAAIAABkgABkBkgADHAAIAAhiIBkAAIAABigADHAAg");
	this.shape_3.setTransform(79.825,86.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C3AD9F").s().p("ADHDHIAAhkIBkAAIAABkgAAADHIAAhkIBkAAIAABkgAjGDHIAAhkIBkAAIAABkgABkBjIAAhjIhkAAIAAhjIBkAAIAABjIBjAAIAAhjIBkAAIAABjIhkAAIAABjgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape_4.setTransform(79.825,76.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#876B57").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkIAAhkIhkAAIAAhiIBkAAIAABiIBjAAIAABkgABkBkgADHAAIAAhiIBkAAIAABigADHAAg");
	this.shape_5.setTransform(79.825,86.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(10.2,56.9,139.3,49.699999999999996);


(lib.leveltwonext_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EBEDED").s().p("ADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAjGDHIAAhjIBkAAIAABjgABkBkIAAhkIhkAAIAAhjIBkAAIAABjIBjAAIAABkgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgADHAAIAAhjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape.setTransform(0.025,-4.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2C547E").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkIAAhkIBjAAIAABkgABkBkgADHAAIAAhiIBkAAIAABigADHAAgAAAAAIAAhiIBkAAIAABig");
	this.shape_1.setTransform(0.025,4.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2C547E").s().p("ADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAAhkIhkAAIAAhjIBkAAIAABjIBjAAIAABkIhjAAIAABjgAjGDHIAAhjIBkAAIAABjgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgADHAAIAAhjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape_2.setTransform(0.025,-4.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EBEDED").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIhjAAIAAhkIBjAAIAABkIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkgADHAAIAAhiIBkAAIAABigADHAAgAAAAAIAAhiIBkAAIAABig");
	this.shape_3.setTransform(0.025,4.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EBEDED").s().p("ADHDHIAAhjIhjAAIAAhkIhkAAIAAhjIBkAAIAABjIBjAAIAABkIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAjGDHIAAhjIBkAAIAABjgABkBkgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgADHAAIAAhjIBkAAIAABjgADHAAgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape_4.setTransform(0.025,-4.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2C547E").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkIAAhkIhkAAIAAhiIBkAAIAABiIBjAAIAABkgADHAAIAAhiIBkAAIAABig");
	this.shape_5.setTransform(0.025,4.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69.6,-24.8,139.3,49.7);


(lib.leveltwo_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7B8284").s().p("Au1ImIAAksIDIAAIAAhkIjIAAIAAhkIEsAAIAAEsIjIAAIAABkIDIAAIAABkgAKKgxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAFegxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAgxgxIAAhkIhkAAIAAjIIhkAAIAAjIIBkAAIAABkIAABkIBkAAIAABkIAABkIBjAAIAABkgAolgxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAu1gxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAAyiVIAAhkIAAhkIBkAAIAAhkIAAhkIBkAAIAADIIhkAAIAADIg");
	this.shape.setTransform(0,5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EAEDED").s().p("AtRImIAAhkIDIAAIAABkgAu1FeIAAhkIDIAAIAABkgAu1CWIAAhkIEsAAIAABkgALugxIAAhkIDIAAIAABkgAHCgxIAAhkIBkAAIAABkgAgxgxIAAhkIBjAAIAABkgAnBgxIAAhkIBkAAIAABkgAtRgxIAAhkIDIAAIAABkgAHCj5IAAhkIBkAAIAABkgAAyj5IAAhkIBkAAIAABkgAiVj5IAAhkIBkAAIAABkgAnBj5IAAhkIBkAAIAABkgAKKnBIAAhkIBkAAIAABkgAFenBIAAhkIDIAAIAABkgACWnBIAAhkIBkAAIAABkgAj5nBIAAhkIBkAAIAABkgAolnBIAAhkIDIAAIAABkgAu1nBIAAhkIBkAAIAABkg");
	this.shape_1.setTransform(0,-5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EAEDED").s().p("Au1ImIAAksIDIAAIAAhkIjIAAIAAhkIEsAAIAAEsIjIAAIAABkIDIAAIAABkgAKKgxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAFegxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAgxgxIAAhkIhkAAIAAjIIhkAAIAAjIIBkAAIAABkIAABkIBkAAIAABkIAABkIBjAAIAABkgAolgxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAu1gxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAAyiVIAAhkIAAhkIBkAAIAAhkIAAhkIBkAAIAADIIhkAAIAADIg");
	this.shape_2.setTransform(0,5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#7B8284").s().p("AtRImIAAhkIDIAAIAABkgAu1FeIAAhkIDIAAIAABkgAu1CWIAAhkIEsAAIAABkgALugxIAAhkIDIAAIAABkgAHCgxIAAhkIBkAAIAABkgAgxgxIAAhkIBjAAIAABkgAnBgxIAAhkIBkAAIAABkgAtRgxIAAhkIDIAAIAABkgAHCj5IAAhkIBkAAIAABkgAAyj5IAAhkIBkAAIAABkgAiVj5IAAhkIBkAAIAABkgAnBj5IAAhkIBkAAIAABkgAKKnBIAAhkIBkAAIAABkgAFenBIAAhkIDIAAIAABkgACWnBIAAhkIBkAAIAABkgAj5nBIAAhkIBkAAIAABkgAolnBIAAhkIDIAAIAABkgAu1nBIAAhkIBkAAIAABkg");
	this.shape_3.setTransform(0,-5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#7B8284").s().p("Au1ImIAAksIDIAAIAAhkIjIAAIAAhkIEsAAIAAEsIjIAAIAABkIDIAAIAABkgAKKgxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAFegxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAgxgxIAAhkIhkAAIAAjIIhkAAIAAjIIBkAAIAABkIAABkIBkAAIAABkIAABkIBjAAIAABkgAolgxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAu1gxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAAyiVIAAhkIAAhkIBkAAIAADIgACWldIAAhkIAAhkIBkAAIAADIgACWldg");
	this.shape_4.setTransform(0,5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_5.setTransform(-90,-55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_6.setTransform(-90,-45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_7.setTransform(-90,-35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_8.setTransform(-90,-25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_9.setTransform(-90,-15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_10.setTransform(-90,-5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_11.setTransform(-80,-15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_12.setTransform(-80,-5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_13.setTransform(-70,-15);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_14.setTransform(-70,-5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_15.setTransform(-50,-55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_16.setTransform(-50,-45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_17.setTransform(-50,-35);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_18.setTransform(-50,-25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_19.setTransform(-50,-15);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_20.setTransform(-50,-5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_21.setTransform(-40,-55);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_22.setTransform(-40,-45);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_23.setTransform(-40,-35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_24.setTransform(-40,-25);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_25.setTransform(-40,-15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_26.setTransform(-40,-5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_27.setTransform(-20,-55);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_28.setTransform(-20,-45);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_29.setTransform(-20,-35);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_30.setTransform(-10,-35);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_31.setTransform(-10,-25);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_32.setTransform(-10,-15);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_33.setTransform(0,-15);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_34.setTransform(0,-5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_35.setTransform(10,-35);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_36.setTransform(10,-25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_37.setTransform(10,-15);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_38.setTransform(20,-55);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_39.setTransform(20,-45);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_40.setTransform(20,-35);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_41.setTransform(40,-55);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_42.setTransform(40,-45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_43.setTransform(40,-35);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_44.setTransform(40,-25);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_45.setTransform(40,-15);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_46.setTransform(40,-5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_47.setTransform(50,-55);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_48.setTransform(50,-45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_49.setTransform(50,-35);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_50.setTransform(50,-25);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_51.setTransform(50,-15);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_52.setTransform(50,-5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_53.setTransform(70,-55);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_54.setTransform(70,-45);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_55.setTransform(70,-35);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_56.setTransform(70,-25);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_57.setTransform(70,-15);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_58.setTransform(70,-5);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_59.setTransform(80,-15);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_60.setTransform(80,-5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_61.setTransform(90,-15);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_62.setTransform(90,-5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_63.setTransform(-90,15);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_64.setTransform(-80,15);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_65.setTransform(-70,15);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_66.setTransform(-90,35);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_67.setTransform(-90,45);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_68.setTransform(-90,55);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_69.setTransform(-80,35);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_70.setTransform(-80,55);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_71.setTransform(-70,25);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_72.setTransform(-70,35);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#EAEDED").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_73.setTransform(-70,55);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_74.setTransform(-90,5);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_75.setTransform(-80,5);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_76.setTransform(-70,5);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_77.setTransform(-90,25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_78.setTransform(-80,25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_79.setTransform(-80,45);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#7B8284").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape_80.setTransform(-70,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_1},{t:this.shape_4}]},1).to({state:[{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-95,-60,190,120);


(lib.levelthreenext_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2A2574").s().p("ADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAAhkIhkAAIAAhjIBkAAIAABjIBjAAIAABkIhjAAIAABjgAjGDHIAAhjIBkAAIAABjgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgADHAAIAAhjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape.setTransform(0.025,-4.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#141415").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIhjAAIAAhkIBjAAIAABkIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkgADHAAIAAhiIBkAAIAABigADHAAgAAAAAIAAhiIBkAAIAABig");
	this.shape_1.setTransform(0.025,4.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#141415").s().p("ADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAjGDHIAAhjIBkAAIAABjgABkBkIAAhkIhkAAIAAhjIBkAAIAABjIBjAAIAABkgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgADHAAIAAhjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape_2.setTransform(0.025,-4.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2A2574").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkIAAhkIBjAAIAABkgABkBkgADHAAIAAhiIBkAAIAABigADHAAgAAAAAIAAhiIBkAAIAABig");
	this.shape_3.setTransform(0.025,4.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2A2574").s().p("ADHDHIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhkIhkAAIAAhjIBkAAIAABjIBjAAIAABkIBkAAIAABjgAjGDHIAAhjIBkAAIAABjgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgADHAAIAAhjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape_4.setTransform(0.025,-4.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#141415").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkIAAhkIhkAAIAAhiIBkAAIAABiIBjAAIAABkgABkBkgADHAAIAAhiIBkAAIAABigADHAAg");
	this.shape_5.setTransform(0.025,4.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69.6,-24.8,139.3,49.7);


(lib.levelthree_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6D76").s().p("Au1ImIAAhkIDIAAIAAhkIhkAAIAAhkIBkAAIAAhkIhkAAIhkAAIAAhkIEsAAIAAH0gAKKgxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAFegxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAgxgxIAAhkIhkAAIAAjIIhkAAIAAjIIBkAAIAABkIAABkIBkAAIAABkIAABkIBjAAIAABkgAolgxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAu1gxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAAyiVIAAhkIAAhkIBkAAIAAhkIAAhkIBkAAIAADIIhkAAIAADIg");
	this.shape.setTransform(0,5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#141415").s().p("Au1ImIAAhkIBkAAIBkAAIAABkgAtRFeIAAhkIBkAAIAABkgAu1CWIAAhkIEsAAIAABkgALugxIAAhkIDIAAIAABkgAHCgxIAAhkIBkAAIAABkgAgxgxIAAhkIBjAAIAABkgAnBgxIAAhkIBkAAIAABkgAtRgxIAAhkIDIAAIAABkgAHCj5IAAhkIBkAAIAABkgAAyj5IAAhkIBkAAIAABkgAiVj5IAAhkIBkAAIAABkgAnBj5IAAhkIBkAAIAABkgAKKnBIAAhkIBkAAIAABkgAFenBIAAhkIDIAAIAABkgACWnBIAAhkIBkAAIAABkgAj5nBIAAhkIBkAAIAABkgAolnBIAAhkIDIAAIAABkgAu1nBIAAhkIBkAAIAABkg");
	this.shape_1.setTransform(0,-5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#141415").s().p("Au1ImIAAhkIDIAAIAAhkIhkAAIAAhkIBkAAIAAhkIhkAAIhkAAIAAhkIEsAAIAAH0gAKKgxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAFegxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAgxgxIAAhkIhkAAIAAjIIhkAAIAAjIIBkAAIAABkIAABkIBkAAIAABkIAABkIBjAAIAABkgAolgxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAu1gxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAAyiVIAAhkIAAhkIBkAAIAAhkIAAhkIBkAAIAADIIhkAAIAADIg");
	this.shape_2.setTransform(0,5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6D6D76").s().p("Au1ImIAAhkIBkAAIBkAAIAABkgAtRFeIAAhkIBkAAIAABkgAu1CWIAAhkIEsAAIAABkgALugxIAAhkIDIAAIAABkgAHCgxIAAhkIBkAAIAABkgAgxgxIAAhkIBjAAIAABkgAnBgxIAAhkIBkAAIAABkgAtRgxIAAhkIDIAAIAABkgAHCj5IAAhkIBkAAIAABkgAAyj5IAAhkIBkAAIAABkgAiVj5IAAhkIBkAAIAABkgAnBj5IAAhkIBkAAIAABkgAKKnBIAAhkIBkAAIAABkgAFenBIAAhkIDIAAIAABkgACWnBIAAhkIBkAAIAABkgAj5nBIAAhkIBkAAIAABkgAolnBIAAhkIDIAAIAABkgAu1nBIAAhkIBkAAIAABkg");
	this.shape_3.setTransform(0,-5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6D6D76").s().p("Au1ImIAAhkIDIAAIAAhkIhkAAIAAhkIBkAAIAAhkIhkAAIhkAAIAAhkIEsAAIAAH0gAKKgxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAFegxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAgxgxIAAhkIhkAAIAAjIIhkAAIAAjIIBkAAIAABkIAABkIBkAAIAABkIAABkIBjAAIAABkgAolgxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAu1gxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAAyiVIAAhkIAAhkIBkAAIAADIgACWldIAAhkIAAhkIBkAAIAADIgACWldg");
	this.shape_4.setTransform(0,5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_1},{t:this.shape_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-95,-60,190,120);


(lib.levelonebutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Level1Button
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2C291F").s().p("ArtImIAAhkIBkAAIAABkgAu1ImIAAhkIBkAAIAABkgAu1CWIAAhkIDIAAIAABkgALugxIAAhkIDIAAIAABkgAHCgxIAAhkIBkAAIAABkgAgxgxIAAhkIBjAAIAABkgAnBgxIAAhkIBkAAIAABkgAtRgxIAAhkIDIAAIAABkgAHCj5IAAhkIBkAAIAABkgAAyj5IAAhkIBkAAIAABkgAiVj5IAAhkIBkAAIAABkgAnBj5IAAhkIBkAAIAABkgAKKnBIAAhkIBkAAIAABkgAFenBIAAhkIDIAAIAABkgACWnBIAAhkIBkAAIAABkgAj5nBIAAhkIBkAAIAABkgAolnBIAAhkIDIAAIAABkgAu1nBIAAhkIBkAAIAABkg");
	this.shape.setTransform(95,55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D7C2BB").s().p("Au1ImIAAhkIBkAAIAAhkIAAjIIhkAAIAAhkIDIAAIAAEsIAABkIBkAAIAABkgAKKgxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAFegxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAgxgxIAAhkIBjAAIAABkgAolgxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgArtgxIjIAAIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAAyiVIAAhkIAAhkIBkAAIAAhkIAAhkIBkAAIAADIIhkAAIAADIgAAyiVgAiViVIAAjIIhkAAIAAjIIBkAAIAABkIAABkIBkAAIAABkIAABkg");
	this.shape_1.setTransform(95,65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D7C2BB").s().p("ArtImIAAhkIBkAAIAABkgAu1ImIAAhkIBkAAIAABkgAu1CWIAAhkIDIAAIAABkgALugxIAAhkIDIAAIAABkgAHCgxIAAhkIBkAAIAABkgAgxgxIAAhkIBjAAIAABkgAnBgxIAAhkIBkAAIAABkgAtRgxIAAhkIDIAAIAABkgAHCj5IAAhkIBkAAIAABkgAAyj5IAAhkIBkAAIAABkgAiVj5IAAhkIBkAAIAABkgAnBj5IAAhkIBkAAIAABkgAKKnBIAAhkIBkAAIAABkgAFenBIAAhkIDIAAIAABkgACWnBIAAhkIBkAAIAABkgAj5nBIAAhkIBkAAIAABkgAolnBIAAhkIDIAAIAABkgAu1nBIAAhkIBkAAIAABkg");
	this.shape_2.setTransform(95,55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2C291F").s().p("Au1ImIAAhkIBkAAIAAhkIAAjIIhkAAIAAhkIDIAAIAAEsIAABkIBkAAIAABkgAKKgxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAFegxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAgxgxIAAhkIBjAAIAABkgAolgxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgArtgxIjIAAIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAAyiVIAAhkIAAhkIBkAAIAAhkIAAhkIBkAAIAADIIhkAAIAADIgAAyiVgAiViVIAAjIIhkAAIAAjIIBkAAIAABkIAABkIBkAAIAABkIAABkg");
	this.shape_3.setTransform(95,65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D7C2BB").s().p("Au1ImIAAhkIBkAAIAAhkIAAjIIhkAAIAAhkIDIAAIAAEsIAABkIBkAAIAABkgAKKgxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAFegxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAgxgxIAAhkIhkAAIAAjIIhkAAIAAjIIBkAAIAABkIAABkIBkAAIAABkIAABkIBjAAIAABkgAolgxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgArtgxIjIAAIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAAyiVIAAhkIAAhkIBkAAIAAhkIAAhkIBkAAIAADIIhkAAIAADIg");
	this.shape_4.setTransform(95,65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2C291F").s().p("Au1ImIAAhkIBkAAIAAhkIAAjIIhkAAIAAhkIDIAAIAAEsIAABkIBkAAIAABkgAKKgxIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAFegxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgAgxgxIAAhkIhkAAIAAjIIhkAAIAAjIIBkAAIAABkIAABkIBkAAIAABkIAABkIBjAAIAABkgAolgxIAAn0IDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkIBkAAIAABkgArtgxIjIAAIAAn0IBkAAIAAEsIAABkIDIAAIAABkgAAyiVIAAhkIAAhkIBkAAIAAhkIAAhkIBkAAIAADIIhkAAIAADIg");
	this.shape_5.setTransform(95,65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_5},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,190,120);


(lib.congrats_btn2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EE9B38").s().p("ADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAAhkIhkAAIAAhjIBkAAIAABjIBjAAIAABkIhjAAIAABjgAjGDHIAAhjIBkAAIAABjgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgADHAAIAAhjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape.setTransform(0.025,-4.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIhjAAIAAhkIBjAAIAABkIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkgADHAAIAAhiIBkAAIAABigADHAAgAAAAAIAAhiIBkAAIAABig");
	this.shape_1.setTransform(0.025,4.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAjGDHIAAhjIBkAAIAABjgABkBkIAAhkIhkAAIAAhjIBkAAIAABjIBjAAIAABkgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgADHAAIAAhjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape_2.setTransform(0.025,-4.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EE9B38").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkIAAhkIBjAAIAABkgABkBkgADHAAIAAhiIBkAAIAABigADHAAgAAAAAIAAhiIBkAAIAABig");
	this.shape_3.setTransform(0.025,4.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EE9B38").s().p("ADHDHIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhkIhkAAIAAhjIBkAAIAABjIBjAAIAABkIBkAAIAABjgAjGDHIAAhjIBkAAIAABjgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgADHAAIAAhjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape_4.setTransform(0.025,-4.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkIAAhkIhkAAIAAhiIBkAAIAABiIBjAAIAABkgABkBkgADHAAIAAhiIBkAAIAABigADHAAg");
	this.shape_5.setTransform(0.025,4.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69.6,-24.8,139.3,49.7);


(lib.congrats_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED9B38").s().p("ADHDHIAAhkIBkAAIAABkgAAADHIAAhkIBkAAIAABkgAjGDHIAAhkIBkAAIAABkgABkBjIAAhjIhkAAIAAhjIBkAAIAABjIBjAAIAAhjIBkAAIAABjIhkAAIAABjgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape.setTransform(13.675,-7.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkIAAhkIhkAAIAAhiIBkAAIAABiIBjAAIAABkgABkBkgADHAAIAAhiIBkAAIAABigADHAAg");
	this.shape_1.setTransform(13.675,2.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ADHDHIAAhkIBkAAIAABkgAAADHIAAhkIBkAAIAABkgAjGDHIAAhkIBkAAIAABkgABkBjIAAhjIhkAAIAAhjIBkAAIAABjIBjAAIAAhjIBkAAIAABjIhkAAIAABjgAJVAAIAAhjIhjAAIAABjIhkAAIAAhjIBkAAIAAhjIBjAAIAABjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjg");
	this.shape_2.setTransform(13.675,-7.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#ED9B38").s().p("AHyDHIAAjHIhkAAIAAhiIBkAAIAAhkIBjAAIAABkIBkAAIAABiIhkAAIAADHgADHDHIAAhjIBkAAIAABjgAAADHIAAhjIBkAAIAABjgAkpDHIAAkpIDHAAIAABiIhkAAIAABkIBkAAIAABjgAnwDHIAAjHIhkAAIAADHIhkAAIAAkpIErAAIAAEpgABkBkIAAhkIhkAAIAAhiIBkAAIAABiIBjAAIAABkgABkBkgADHAAIAAhiIBkAAIAABigADHAAg");
	this.shape_3.setTransform(13.675,2.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#ED9B38").s().p("ADHDHIAAhkIBkAAIAABkgAAADHIAAhkIBkAAIAABkgAjGDHIAAhkIBkAAIAABkgABkBjIAAhjIhkAAIAAhjIBkAAIAABjIBjAAIAABjgAJVAAIAAhjIBkAAIAABjgAGOAAIAAhjIBkAAIAABjgADHAAIAAhjIBkAAIAABjgAkpAAIAAhjIDHAAIAABjgAq4AAIAAhjIErAAIAABjgAHyhjIAAhjIBjAAIAABjg");
	this.shape_4.setTransform(13.675,-7.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_1},{t:this.shape_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-27,139.4,49.7);


(lib.Instructions_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F19D38").s().p("AAyH0IAAksIhjAAIAAhkIErAAIAABkIhkAAIAAEsgAldH0IAAmQIDIAAIAABkIhkAAIAABkIBkAAIAABkIhkAAIAABkgAqJH0IAAmQIDIAAIAABkIhkAAIAADIIBkAAIAABkgAu1H0IAAmQIBkAAIAAEsIBkAAIAABkgALuhjIAAksIhkAAIAAhkIEsAAIAABkIhkAAIAAEsgAHChjIAAjIIhkAAIAADIIhkAAIAAmQIBkAAIAABkIBkAAIAAhkIBkAAIAAGQgAiVhjIAAmQIErAAIAABkIjHAAIAADIIBjAAIAAhkIBkAAIAADIgAolhjIAAhkIBkAAIAAjIIhkAAIAAhkIEsAAIAABkIhkAAIAADIIBkAAIAABkgArthjIAAhkIhkAAIAABkIhkAAIAAmQIEsAAIAADIIhkAAIAAhkIhkAAIAABkIBkAAIAABkIBkAAIAABkg");
	this.shape.setTransform(515,80);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("EAiYARMIAAhkIBkAAIAABkgAfQRMIAAjIIhkAAIAAhkIBkAAIAAhkIBkAAIAAGQgAZARMIAAmQIBkAAIAABkIBkAAIAABkIBkAAIAABkIhkAAIAAhkIhkAAIAADIgAUURMIAAmQIDIAAIAABkIhkAAIAADIIBkAAIAABkgARMRMIAAjIIhkAAIAADIIhkAAIAAmQIBkAAIAABkIBkAAIAAhkIBkAAIAAGQgAJYRMIAAksIhkAAIAAhkIEsAAIAABkIhkAAIAAEsgABkRMIAAmQIDIAAIAABkIhkAAIAADIIBkAAIAABkgAjHRMIAAhkIhkAAIAAksIBkAAIAAEsIBkAAIAABkgAq7RMIAAmQIEsAAIAAGQgApXPoIBkAAIAAjIIhkAAgAuDRMIAAjIIhkAAIAAhkIBkAAIAAhkIBkAAIAAGQgA0TRMIAAmQIBkAAIAABkIBkAAIAABkIhkAAIAADIgA8HRMIAAmQIEsAAIAAGQgA6jPoIBkAAIAAjIIhkAAgEggzARMIAAksIhkAAIAAhkIEsAAIAABkIhkAAIAAEsgAhjPoIAAksIBjAAIAAEsgAhjPogAxLPoIAAhkIBkAAIAABkgAdsOEgEAu4AH0IAAhkIhkAAIAABkIhkAAIAAmQIEsAAIAADIIhkAAIAAhkIhkAAIAABkIBkAAIAABkIBkAAIAABkgEAnEAH0IAAmQIDIAAIAABkIhkAAIAADIIBkAAIAABkgEAiYAH0IAAksIhkAAIAAhkIEsAAIAABkIhkAAIAAEsgAcIH0IAAmQIDIAAIAABkIhkAAIAADIIBkAAIAABkgAZAH0IAAhkIhkAAIAABkIhkAAIAAmQIEsAAIAAGQgAXcEsIBkAAIAAhkIhkAAgASwH0IAAhkIhkAAIAABkIhkAAIAAmQIEsAAIAADIIhkAAIAAhkIhkAAIAABkIBkAAIAABkIBkAAIAABkgAMgH0IAAhkIhkAAIAABkIhkAAIAAmQIEsAAIAAGQgAK8EsIBkAAIAAhkIhkAAgAGQH0IAAjIIhkAAIAADIIhkAAIAAmQIBkAAIAABkIBkAAIAAhkIBkAAIAAGQgAhjH0IAAmQIDHAAIAABkIhkAAIAADIIBkAAIAABkgAnzH0IAAmQIDIAAIAABkIhkAAIAADIIBkAAIAABkgAq7H0IAAjIIhkAAIAADIIhkAAIAAmQIBkAAIAABkIBkAAIAAhkIBkAAIAAGQgAyvH0IAAksIhkAAIAAhkIEsAAIAABkIhkAAIAAEsgA8HH0IAAmQIEsAAIAABkIjIAAIAABkIBkAAIAABkIhkAAIAABkgEgiXAH0IAAmQIEsAAIAAGQgEggzAGQIBkAAIAAjIIhkAAgAGQhjIAAmQIDIAAIAABkIhkAAIAADIIBkAAIAABkgADIhjIAAjIIhkAAIAADIIhkAAIAAmQIBkAAIAABkIBkAAIAAhkIBkAAIAAGQgAkrhjIAAksIhkAAIAAhkIEsAAIAABkIhkAAIAAEsgAuDhjIAAmQIEsAAIAAGQgAsfjHIBkAAIAAjIIhkAAgAyvhjIAAksIhkAAIAAhkIEsAAIAABkIhkAAIAAEsgA4/hjIAAhkIhkAAIAABkIhkAAIAAmQIEsAAIAADIIhkAAIAABkIBkAAIAABkgA6jkrIBkAAIAAhkIhkAAgEgiXgBjIAAmQIEsAAIAAGQgEggzgDHIBkAAIAAjIIhkAAgAGQq7IAAmQIDIAAIAABkIhkAAIAADIIBkAAIAABkgADIq7IAAjIIhkAAIAADIIhkAAIAAmQIBkAAIAABkIBkAAIAAhkIBkAAIAAGQgAkrq7IAAksIhkAAIAAhkIEsAAIAABkIhkAAIAAEsgAuDq7IAAmQIEsAAIAAGQgAsfsfIBkAAIAAjIIhkAAgAyvq7IAAksIhkAAIAAhkIEsAAIAABkIhkAAIAAEsgA4/q7IAAhkIBkAAIAABkgA8Hq7IAAmQIBkAAIAABkIBkAAIAADIIhkAAIAABkgEggzgK7IAAmQIDIAAIAABkIhkAAIAADIIBkAAIAABkgEgnDgK7IAAhkIBkAAIAAjIIhkAAIAAhkIEsAAIAABkIhkAAIAADIIBkAAIAABkgEgrvgK7IAAmQIBkAAIAAEsIBkAAIAABkgEgwbgK7IAAmQIDIAAIAABkIhkAAIAADIIBkAAIAABkgA4/vnIAAhkIBkAAIAABkgA4/vng");
	this.shape_1.setTransform(340,140);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Instructions_1, new cjs.Rectangle(30,30,620,220), null);


(lib.Ground = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#949337").s().p("EAooAEsIAAhkIjIAAIAAhkImQAAIAABkIpYAAIAAhkIksAAIAABkIuEAAIAAhkIkrAAIAABkIhkAAIAAjIIjIAAIAADIIpYAAIAAhkIksAAIAABkIksAAIAAhkIhkAAIAAhkIksAAIAABkIhkAAIAADIIksAAIAAhkIpYAAIAAhkIhkAAIAAhkIksAAIAADIIpYAAIAAhkIn0AAIAABkIksAAIAAmPIEsAAIAAhkIDIAAIAABkIDIAAIAABkIDIAAIAAhkIDIAAIAAhkIBkAAIAABkIOEAAIAABkIEsAAIAAhkIGQAAIAAhkIGQAAIAADIIDIAAIAAhkIH0AAIAAhkIK8AAIAABkIJXAAIAAhkIDIAAIAABkIRMAAIAABkIDIAAIAAhkIBkAAIAAhkIEsAAIAABkIBkAAIAABkIDIAAIAAhkIBkAAIAABkIDIAAIAAhkIH0AAIAAhkIEsAAIAABkIhkAAIAABkIDIAAIAAhkIPoAAIAAErIjIAAIAAhkIhkAAIAAhjIhkAAIAADHIksAAIAABkIn0AAIAAhkImQAAIAADIg");
	this.shape.setTransform(0,-50.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#623D23").s().p("EhK/AEsIAAksIEsAAIAAhjIH0AAIAABjIJYAAIAAjHIEsAAIAABkIBkAAIAABjIJYAAIAABkIEsAAIAAjHIBkAAIAAhkIEsAAIAABkIBkAAIAABjIEsAAIAAhjIEsAAIAABjIJYAAIAAjHIDIAAIAADHIBkAAIAAhjIErAAIAABjIOEAAIAAhjIEsAAIAABjIJYAAIAAhjIGQAAIAABjIDIAAIAABkIJYAAIAAjHIGQAAIAABjIH0AAIAAhjIEsAAIAAjIIBkAAIAABkIBkAAIAABkIDIAAIAAGPg");
	this.shape_1.setTransform(0,-30.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#8CC658").s().p("EA4QAD6IAAhkIBkAAIAAhkIksAAIAABkIn0AAIAABkIjIAAIAAhkIhkAAIAABkIjIAAIAAhkIhkAAIAAhkIksAAIAABkIhkAAIAABkIjIAAIAAhkIxMAAIAAhkIjIAAIAABkIpXAAIAAhkIq8AAIAABkIn0AAIAABkIjIAAIAAjIImQAAIAABkImQAAIAABkIksAAIAAhkIuEAAIAAhkIhkAAIAABkIjIAAIAABkIjIAAIAAhkIjIAAIAAhkIjIAAIAABkIksAAIAAmPMCV/AAAIAAGPIvoAAIAABkg");
	this.shape_2.setTransform(0,-85.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Ground, new cjs.Rectangle(-480,-110.2,960,110), null);


(lib.City = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2C3544").s().p("EA50AjKMAAAglfIEsAAIAAmQIBkAAIAAEsIDIAAIAAGPIBkAAIBkAAIAABkIBkAAIAAfQgEAyAAjKIAA5AIGQAAIAAZAgEAakAjKIAA14IBkAAIAAhkIGQAAIAAhkIBkAAIAAhkIDIAAIDIAAIBkAAIAABkIBkAAIAABkIBkAAIAABkIBkAAIAAV4gEAH0AjKIAAywIBkAAIAA0TIBkAAIAAxMIhkAAIAApYIhkAAIAAksIOEAAIAAEsIhkAAIAAJYIhkAAIAAOEIAADIIBkAAIAAUTIBkAAIAASwgEgHzAjKIAA3cIBkAAIAAjIIBkAAIAAhkIBkAAIAAhkIBkAAIAAhkIDHAAIAABkIBkAAIAABkIBkAAIAADIIBkAAIAAZAgEgRLAjKMAAAgonIBkAAIAAhkIEsAAIAABkIBkAAIAADIMAAAAlfgEhGTAjKIAA5AIBkAAIAAksIBkAAIAAyvIhkAAIAAmQIhkAAIAAhkIhkAAIAAjIIDIAAIAAhkIBkAAIAAhkIBkAAIAAjIIBkAAIAADIIBkAAIAABkIDIAAIAABkIBkAAIAABkIBkAAIAABkIhkAAIAABkIjIAAIAABkIAADIIhkAAIAAXbIBkAAIAApXIDIAAIDIAAIAAhkIDIAAIAABkIBkAAIAAGPIBkAAIAApXIBkAAIAAhkIDIAAIAAhkIDIAAIAAhkIEsAAIAABkIBkAAIAABkIDIAAIAABkIDIAAIAABkIDIAAIAABkIBkAAIAAErIBkAAIAAH0IBkAAIAAK8IBkAAIAAMggEgqLAWqIBkAAIEsAAIGQAAIAAmQIhkAAIAApYIhkAAIAAhkIhkAAIAAhkIhkAAIjIAAIAADIIhkAAIAAJYIhkAAgEhDLgQZIAABkIBkAAIAAhkIAAjIIhkAAgEhADgR9IAABkIBkAAIAAhkIAAhkIhkAAg");
	this.shape.setTransform(480,245);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1D232C").s().p("EBH4AeeIAA/PIhkAAIAAhkIhkAAIAAjIIBkAAIAAjIIDIAAIAADIIBkAAMAAAAj7gEA4QAeeIAA5AImQAAIAAZAIhkAAIAA14IhkAAIAAhkIhkAAIAAhkIhkAAIAAhkIhkAAIAAuDIBkAAIAAhkIEsAAIAARLIBkAAIAAnzIBkAAIAApYIBkAAIAAksIBkAAIAAhkIBkAAIAAhkIBkAAIAABkIDIAAIAAEsIBkAAIAAGQIksAAMAAAAlfgEA2sgLtIEsAAIAAjIIhkAAIAAhkIhkAAIAABkIhkAAgAV4eeIAAywIhkAAIAA0TIhkAAIAAjIIH0AAIAAEsIDIAAIAAksIBkAAIAAhkIH0AAIAARLIjIAAIAABkIhkAAIAABkImQAAIAABkIhkAAIAAV4gAGQeeIAA5AIhkAAIAAjIIhkAAIAAhkIhkAAIAAhjIjHAAIAABjIhkAAIAABkIhkAAIAABkIhkAAIAADIIhkAAIAAXcIhkAAMAAAglfIBkAAIAApYIBkAAIAAjIIBkAAIAAhkIDIAAIAABkIBjAAIAADIIBkAAIAAEsIBkAAIAAGQIBkAAIAAhkIBkAAIAAhkIDIAAIAAUTIhkAAIAASwgAyveeIAAsgIhkAAIAAq8IhkAAIAAnzIhkAAIAAksIhkAAIAAhkIjIAAIAAhkIjIAAIAAhkIjIAAIAAhkIBkAAIAAhkIJYAAIAABkIBkAAIAAJYIBkAAIAAhkIBkAAIAAn0IBkAAIAABkMAAAAongEhK/AeeMAAAglfIEsAAIAAMfIAAZAgEgj7AR+IAAyvIBkAAIAABjIBkAAIAABkIBkAAIAAJYIBkAAIAAGQgEgqLAR+IAAmQIBkAAIAAGQgEg+fAD6IAA3bIBkAAIAAjIIBkAAIAABkIBkAAIAAPoIjIAAIAAJXgEhEvAAyIAAyvIBkAAIAASvgEgwbgIlIAA0UIBkAAIAAhkIEsAAIAABkIBkAAIAAPoIAABkIjIAAIAABkIjIAAIAABkgEhDLgThIAAhkIBkAAIAABkgEhADgVFIAAhkIBkAAIAABkg");
	this.shape_1.setTransform(480,275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.City, new cjs.Rectangle(0,20,960,450), null);


(lib.AmazonInvazionLogo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AeeLuIAAn0IksAAIAAH0IhkAAIAAq8IBkAAIAABkIBkAAIAAhkIEsAAIAABkIBkAAIAAJYgAR+LuIAAhkIhkAAIAAhkIhkAAIAAksIBkAAIAAhkIBkAAIAAhkIDIAAIAABkIBkAAIAAH0IhkAAIAABkgAR+HCIAABkIDIAAIAAhkIAAhkIhkAAIAAhkIhkAAgAKKLuIAAjIIBkAAIAAhkIAAhkIhkAAIAAhkIDIAAIAAH0gAHCLuIAAhkIjIAAIAABkIhkAAIAAksIBkAAIAAhkIBkAAIAAhkIhkAAIhkAAIAAjIIGQAAIAAEsIhkAAIAABkIhkAAIAABkIDIAAIAADIgAgxLuIAAhkIhkAAIAABkIksAAIAAhkIhkAAIAAjIIBkAAIAAhkIEsAAIAAhkIksAAIAAhkIBkAAIAAhkIEsAAIAABkIBjAAIAAJYgAldImIAABkIBkAAIAAhkIBkAAIAAhkIhkAAIhkAAgAwZLuIAAksIhkAAIAAmQIBkAAIAADIIAABkIBkAAIAABkIAABkIBkAAIAAhkIAAhkIBkAAIAAhkIAAjIIBkAAIAAGQIhkAAIAADIIhkAAIAABkgA2pLuIAAn0IksAAIAAH0IhkAAIAAq8IBkAAIAABkIBkAAIAAhkIEsAAIAABkIBkAAIAAJYgEghlALuIAAjIIBkAAIAAhkIAAhkIhkAAIAAhkIDIAAIAAH0gAKKCWIAAhkIDIAAIAABkgEghlACWIAAhkIDIAAIAABkgEAgCgAxIhkAAIAAn0IksAAIAAH0IhkAAIAAq8IBkAAIAABkIBkAAIAAhkIEsAAIAABkIBkAAIAAJYgAR+gxIAAhkIhkAAIAAhkIhkAAIAAksIBkAAIAAhkIBkAAIAAhkIDIAAIAABkIBkAAIAAH0IhkAAIAABkgAR+ldIAABkIDIAAIAAhkIAAhkIhkAAIAAhkIhkAAgALugxIAAhkIjIAAIAABkIhkAAIAAksIBkAAIAAhkIBkAAIAAhkIhkAAIhkAAIAAjIIGQAAIAAEsIhkAAIAABkIhkAAIAABkIDIAAIAADIgAD6gxIAAhkIhkAAIAABkIjHAAIhkAAIAAhkIhkAAIAAjIIBkAAIAAhkIErAAIAAhkIkrAAIAAhkIBkAAIAAhkIErAAIAABkIBkAAIAAJYgAgxj5IAABkIBjAAIAAhkIBkAAIAAhkIhkAAIhjAAgAnBgxIAAn0IjIAAIAAH0IhkAAIhkAAIAAn0IhkAAIAAH0IhkAAIhkAAIAAq8IEsAAIAABkIDIAAIAAhkIDIAAIAABkIBkAAIAAJYgA1FgxIAAhkIhkAAIAABkIjIAAIhkAAIAAhkIhkAAIAAjIIBkAAIAAhkIEsAAIAAhkIksAAIAAhkIBkAAIAAhkIEsAAIAABkIBkAAIAAJYgA5xj5IAABkIBkAAIAAhkIBkAAIAAhkIhkAAIhkAAg");
	this.shape.setTransform(465.25,295.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F19D38").s().p("AldLuIAAhkIBkAAIAABkgAR+KKIAAhkIDIAAIAABkgAKKKKIAAhkIBkAAIAABkgAFeKKIAAhkIBkAAIBkAAIAABkgAj5KKIAAhkIBkAAIAABkgAu1KKIAAhkIBkAAIAABkgEghlAKKIAAhkIBkAAIAABkgACWImIAAhkIBkAAIAABkgAolImIAAhkIBkAAIAABkgAD6HCIAAhkIBkAAIAABkgAnBHCIAAhkIEsAAIAABkgAnBHCgAtRHCIAAhkIBkAAIAABkgAwZHCIAAhkIBkAAIAABkgAO2FeIAAhkIBkAAIAABkgAKKFeIAAhkIDIAAIAABkgEghlAFeIAAhkIDIAAIAABkgEAgCAD6IAAhkIksAAIAAhkIDIAAIBkAAIAABkIBkAAIAABkgAZyD6IAAhkIhkAAIAAhkIBkAAIAABkIBkAAIAABkgAVGD6IAAhkIBkAAIAABkgAQaD6IAAhkIBkAAIAABkgAQaD6gAgxD6IAAhkIksAAIAAhkIDIAAIBkAAIAABkIBjAAIAABkgAnBD6IAAhkIBkAAIAABkgA1FD6IAAhkIBkAAIAABkgA7VD6IAAhkIhkAAIAAhkIBkAAIAABkIBkAAIAABkgAbWCWgAR+CWIAAhkIDIAAIAABkgAKKCWIAAhkIBkAAIBkAAIAABkgACWCWIAAhkIBkAAIBkAAIBkAAIBkAAIAABkgArtCWIAAhkIBkAAIAABkgAx9CWIAAhkIBkAAIAABkgA5xCWIAAhkIDIAAIBkAAIAABkgEghlACWIAAhkIDIAAIAABkgAgxgxIAAhkIBjAAIAABkgA5xgxIAAhkIBkAAIAAhkIBkAAIAABkIhkAAIAABkgAR+iVIAAhkIDIAAIAABkgAKKiVIAAhkIBkAAIBkAAIAABkgAAyiVIAAhkIBkAAIAABkgAAyiVgAHCj5IAAhkIBkAAIAABkgAj5j5IAAhkIBkAAIAABkgA85j5IAAhkIBkAAIAABkgAImldIAAhkIBkAAIAABkgAiVldIAAhkIErAAIAABkgAiVldgA7VldIAAhkIEsAAIAABkgA7VldgAO2nBIAAhkIBkAAIAABkgEAgCgIlIAAhkIksAAIAABkIhkAAIAAhkIhkAAIAAhkIBkAAIAABkIBkAAIAAhkIEsAAIAABkIBkAAIAABkgAVGolIAAhkIjIAAIAAhkIDIAAIAABkIBkAAIAABkgAQaolIAAhkIBkAAIAABkgAQaolgAD6olIAAhkIkrAAIAAhkIErAAIAABkIBkAAIAABkgAiVolIAAhkIBkAAIAABkgAnBolIAAhkIjIAAIAAhkIDIAAIAABkIBkAAIAABkgAtRolIAAhkIDIAAIAABkgA1FolIAAhkIksAAIAABkIhkAAIAAhkIBkAAIAAhkIEsAAIAABkIBkAAIAABkgAHCqJIAAhkIGQAAIAABkgAx9qJIAAhkIEsAAIAABkg");
	this.shape_1.setTransform(465.25,285.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.AmazonInvazionLogo, new cjs.Rectangle(250.3,210.3,429.99999999999994,160), null);


(lib.shoe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol2();
	this.instance.parent = this;
	this.instance.setTransform(79.6,39.8,1,1,0,0,0,79.6,39.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:42.5,regY:21.2,x:42.5,y:29.5},0).wait(1).to({y:37.85},0).wait(1).to({y:46.2},0).wait(1).to({y:54.5},0).wait(1).to({y:62.85},0).wait(1).to({y:71.2},0).wait(1).to({y:79.5},0).wait(1).to({y:87.85},0).wait(1).to({y:96.2},0).wait(1).to({y:104.5},0).wait(1).to({y:112.85},0).wait(1).to({y:121.2},0).wait(1).to({y:129.5},0).wait(1).to({y:137.85},0).wait(1).to({y:146.2},0).wait(1).to({y:154.5},0).wait(1).to({y:162.85},0).wait(1).to({y:171.2},0).wait(1).to({y:179.5},0).wait(1).to({y:187.85},0).wait(1).to({y:196.2},0).wait(1).to({y:204.5},0).wait(1).to({y:212.85},0).wait(1).to({y:221.2},0).wait(1).to({y:229.5},0).wait(1).to({y:237.85},0).wait(1).to({y:246.2},0).wait(1).to({y:254.5},0).wait(1).to({y:262.85},0).wait(1).to({y:271.2},0).wait(1).to({y:279.5},0).wait(1).to({y:287.85},0).wait(1).to({y:296.2},0).wait(1).to({y:304.5},0).wait(1).to({y:312.85},0).wait(1).to({y:321.2},0).wait(1).to({y:329.5},0).wait(1).to({y:337.85},0).wait(1).to({y:346.2},0).wait(1).to({y:354.55},0).wait(1).to({y:362.85},0).wait(1).to({y:371.2},0).wait(1).to({y:379.55},0).wait(1).to({y:387.85},0).wait(1).to({y:396.2},0).wait(1).to({y:404.55},0).wait(1).to({y:412.85},0).wait(1).to({y:421.2},0).wait(1).to({y:429.55},0).wait(1).to({y:437.85},0).wait(1).to({y:446.2},0).wait(1).to({y:454.55},0).wait(1).to({y:462.85},0).wait(1).to({y:471.2},0).wait(1).to({y:479.55},0).wait(1).to({y:487.85},0).wait(1).to({y:496.2},0).wait(1).to({y:504.55},0).wait(1).to({y:512.85},0).wait(1).to({y:521.2},0).wait(1).to({y:529.55},0).wait(1).to({y:537.85},0).wait(1).to({y:546.2},0).wait(1).to({y:554.55},0).wait(1).to({y:562.85},0).wait(1).to({y:571.2},0).wait(1).to({y:579.55},0).wait(1).to({y:587.85},0).wait(1).to({y:596.2},0).wait(1).to({y:604.55},0).wait(1).to({y:612.85},0).wait(1).to({y:621.2},0).wait(1).to({y:629.55},0).wait(1).to({y:637.85},0).wait(1).to({y:646.2},0).wait(1).to({y:654.55},0).wait(1).to({y:662.85},0).wait(1).to({y:671.2},0).wait(1).to({y:679.55},0).wait(1).to({y:687.9},0).wait(1).to({y:696.2},0).wait(1).to({y:704.55},0).wait(1).to({y:712.9},0).wait(1).to({y:721.2},0).wait(1).to({y:729.55},0).wait(1).to({y:737.9},0).wait(1).to({y:746.2},0).wait(1).to({y:754.55},0).wait(1).to({y:762.9},0).wait(1).to({y:771.2},0).wait(1).to({y:779.55},0).wait(1).to({y:787.9},0).wait(1).to({y:796.2},0).wait(1).to({y:804.55},0).wait(1).to({y:812.9},0).wait(1).to({y:821.2},0).wait(1).to({y:829.55},0).wait(1).to({y:837.9},0).wait(1).to({y:846.2},0).wait(1).to({y:854.55},0).wait(1).to({y:862.9},0).wait(1).to({y:871.2},0).wait(1).to({y:879.55},0).wait(1).to({y:887.9},0).wait(1).to({y:896.2},0).wait(1).to({y:904.55},0).wait(1).to({y:912.9},0).wait(1).to({y:921.2},0).wait(1).to({y:929.55},0).wait(1).to({y:937.9},0).wait(1).to({y:946.2},0).wait(1).to({y:954.55},0).wait(1).to({y:962.9},0).wait(1).to({y:971.2},0).wait(1).to({y:979.55},0).wait(1).to({y:987.9},0).wait(1).to({y:996.2},0).wait(1).to({y:1004.55},0).wait(1).to({y:1012.9},0).wait(1).to({y:1021.25},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,85,1042.6);


(lib.bag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.bag = new lib.Symbol2_1();
	this.bag.name = "bag";
	this.bag.parent = this;
	this.bag.setTransform(45,62.3,0.8654,0.8653,0,0,0,52,72);

	this.timeline.addTween(cjs.Tween.get(this.bag).wait(1).to({y:68.7},0).wait(1).to({x:45.05,y:75.1},0).wait(1).to({x:45.1,y:81.5},0).wait(1).to({x:45.15,y:87.9},0).wait(1).to({x:45.2,y:94.3},0).wait(1).to({x:45.25,y:100.7},0).wait(1).to({y:107.1},0).wait(1).to({x:45.3,y:113.5},0).wait(1).to({x:45.35,y:119.9},0).wait(1).to({x:45.4,y:126.35},0).wait(1).to({x:45.45,y:132.75},0).wait(1).to({x:45.5,y:139.15},0).wait(1).to({y:145.55},0).wait(1).to({x:45.55,y:151.95},0).wait(1).to({x:45.6,y:158.35},0).wait(1).to({x:45.65,y:164.75},0).wait(1).to({x:45.7,y:171.15},0).wait(1).to({x:45.75,y:177.55},0).wait(1).to({y:184},0).wait(1).to({x:45.8,y:190.4},0).wait(1).to({x:45.85,y:196.8},0).wait(1).to({x:45.9,y:203.2},0).wait(1).to({x:45.95,y:209.6},0).wait(1).to({x:46,y:216},0).wait(1).to({y:222.4},0).wait(1).to({x:46.05,y:228.8},0).wait(1).to({x:46.1,y:235.2},0).wait(1).to({x:46.15,y:241.6},0).wait(1).to({x:46.2,y:248.05},0).wait(1).to({x:46.25,y:254.45},0).wait(1).to({y:260.85},0).wait(1).to({x:46.3,y:267.25},0).wait(1).to({x:46.35,y:273.65},0).wait(1).to({x:46.4,y:280.05},0).wait(1).to({x:46.45,y:286.45},0).wait(1).to({x:46.5,y:292.85},0).wait(1).to({x:46.55,y:299.25},0).wait(1).to({y:305.7},0).wait(1).to({x:46.6,y:312.1},0).wait(1).to({x:46.65,y:318.5},0).wait(1).to({x:46.7,y:324.9},0).wait(1).to({x:46.75,y:331.3},0).wait(1).to({x:46.8,y:337.7},0).wait(1).to({y:344.1},0).wait(1).to({x:46.85,y:350.5},0).wait(1).to({x:46.9,y:356.9},0).wait(1).to({x:46.95,y:363.35},0).wait(1).to({x:47,y:369.75},0).wait(1).to({x:47.05,y:376.15},0).wait(1).to({y:382.55},0).wait(1).to({x:47.1,y:388.95},0).wait(1).to({x:47.15,y:395.35},0).wait(1).to({x:47.2,y:401.75},0).wait(1).to({x:47.25,y:408.15},0).wait(1).to({x:47.3,y:414.55},0).wait(1).to({y:420.95},0).wait(1).to({x:47.35,y:427.4},0).wait(1).to({x:47.4,y:433.8},0).wait(1).to({x:47.45,y:440.2},0).wait(1).to({x:47.5,y:446.6},0).wait(1).to({x:47.55,y:453},0).wait(1).to({y:459.4},0).wait(1).to({x:47.6,y:465.8},0).wait(1).to({x:47.65,y:472.2},0).wait(1).to({x:47.7,y:478.65},0).wait(1).to({x:47.75,y:485.05},0).wait(1).to({x:47.8,y:491.45},0).wait(1).to({x:47.85,y:497.85},0).wait(1).to({y:504.25},0).wait(1).to({x:47.9,y:510.65},0).wait(1).to({x:47.95,y:517.05},0).wait(1).to({x:48,y:523.45},0).wait(1).to({x:48.05,y:529.85},0).wait(1).to({x:48.1,y:536.25},0).wait(1).to({y:542.7},0).wait(1).to({x:48.15,y:549.1},0).wait(1).to({x:48.2,y:555.5},0).wait(1).to({x:48.25,y:561.9},0).wait(1).to({x:48.3,y:568.3},0).wait(1).to({x:48.35,y:574.7},0).wait(1).to({y:581.1},0).wait(1).to({x:48.4,y:587.5},0).wait(1).to({x:48.45,y:593.9},0).wait(1).to({x:48.5,y:600.3},0).wait(1).to({x:48.55,y:606.75},0).wait(1).to({x:48.6,y:613.15},0).wait(1).to({y:619.55},0).wait(1).to({x:48.65,y:625.95},0).wait(1).to({x:48.7,y:632.35},0).wait(1).to({x:48.75,y:638.75},0).wait(1).to({x:48.8,y:645.15},0).wait(1).to({x:48.85,y:651.55},0).wait(1).to({y:657.95},0).wait(1).to({x:48.9,y:664.4},0).wait(1).to({x:48.95,y:670.8},0).wait(1).to({x:49,y:677.2},0).wait(1).to({x:49.05,y:683.6},0).wait(1).to({x:49.1,y:690},0).wait(1).to({y:696.4},0).wait(1).to({x:49.15,y:702.8},0).wait(1).to({x:49.2,y:709.2},0).wait(1).to({x:49.25,y:715.6},0).wait(1).to({x:49.3,y:722},0).wait(1).to({x:49.35,y:728.45},0).wait(1).to({x:49.4,y:734.85},0).wait(1).to({y:741.25},0).wait(1).to({x:49.45,y:747.65},0).wait(1).to({x:49.5,y:754.05},0).wait(1).to({x:49.55,y:760.45},0).wait(1).to({x:49.6,y:766.85},0).wait(1).to({x:49.65,y:773.25},0).wait(1).to({y:779.65},0).wait(1).to({x:49.7,y:786.1},0).wait(1).to({x:49.75,y:792.5},0).wait(1).to({x:49.8,y:798.9},0).wait(1).to({x:49.85,y:805.3},0).wait(1).to({x:49.9,y:811.7},0).wait(1).to({y:818.1},0).wait(1).to({x:49.95,y:824.5},0).wait(1).to({x:50,y:830.9},0).wait(1).to({x:50.05,y:837.35},0).wait(1).to({x:50.1,y:843.75},0).wait(1).to({x:50.15,y:850.15},0).wait(1).to({y:856.55},0).wait(1).to({x:50.2,y:862.95},0).wait(1).to({x:50.25,y:869.35},0).wait(1).to({x:50.3,y:875.75},0).wait(1).to({x:50.35,y:882.15},0).wait(1).to({x:50.4,y:888.55},0).wait(1).to({y:895},0).wait(1).to({x:50.45,y:901.4},0).wait(1).to({x:50.5,y:907.8},0).wait(1).to({x:50.55,y:914.2},0).wait(1).to({x:50.6,y:920.6},0).wait(1).to({x:50.65,y:927},0).wait(1).to({x:50.7,y:933.4},0).wait(1).to({y:939.8},0).wait(1).to({x:50.75,y:946.2},0).wait(1).to({x:50.8,y:952.6},0).wait(1).to({x:50.85,y:959.05},0).wait(1).to({x:50.9,y:965.45},0).wait(1).to({x:50.95,y:971.85},0).wait(1).to({y:978.25},0).wait(1).to({x:51,y:984.65},0).wait(1).to({x:51.05,y:991.05},0).wait(1).to({x:51.1,y:997.45},0).wait(1).to({x:51.15,y:1003.85},0).wait(1).to({x:51.2,y:1010.25},0).wait(1).to({y:1016.7},0).wait(1).to({x:51.25,y:1023.1},0).wait(1).to({x:51.3,y:1029.5},0).wait(1).to({x:51.35,y:1035.9},0).wait(1).to({x:51.4,y:1042.3},0).wait(1).to({x:51.45,y:1048.7},0).wait(1).to({y:1055.1},0).wait(1).to({x:51.5,y:1061.5},0).wait(1).to({x:51.55,y:1067.9},0).wait(1).to({x:51.6,y:1074.35},0).wait(1).to({x:51.65,y:1080.75},0).wait(1).to({x:51.7,y:1087.15},0).wait(1).to({y:1093.55},0).wait(1).to({x:51.75,y:1099.95},0).wait(1).to({x:51.8,y:1106.35},0).wait(1).to({x:51.85,y:1112.75},0).wait(1).to({x:51.9,y:1119.15},0).wait(1).to({x:51.95,y:1125.55},0).wait(1).to({y:1132},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.1,97,1194.3000000000002);


(lib.book = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.book = new lib.Symbol4();
	this.book.name = "book";
	this.book.parent = this;
	this.book.setTransform(42.5,33.5,1,1,0,0,0,42.5,33.5);

	this.timeline.addTween(cjs.Tween.get(this.book).wait(1).to({y:37.95},0).wait(1).to({y:42.45},0).wait(1).to({y:46.9},0).wait(1).to({y:51.4},0).wait(1).to({y:55.9},0).wait(1).to({y:60.35},0).wait(1).to({y:64.85},0).wait(1).to({y:69.3},0).wait(1).to({y:73.8},0).wait(1).to({y:78.3},0).wait(1).to({y:82.75},0).wait(1).to({y:87.25},0).wait(1).to({y:91.75},0).wait(1).to({y:96.2},0).wait(1).to({y:100.7},0).wait(1).to({y:105.15},0).wait(1).to({y:109.65},0).wait(1).to({y:114.15},0).wait(1).to({y:118.6},0).wait(1).to({y:123.1},0).wait(1).to({y:127.6},0).wait(1).to({y:132.05},0).wait(1).to({y:136.55},0).wait(1).to({y:141},0).wait(1).to({y:145.5},0).wait(1).to({y:150},0).wait(1).to({y:154.45},0).wait(1).to({y:158.95},0).wait(1).to({y:163.45},0).wait(1).to({y:167.9},0).wait(1).to({y:172.4},0).wait(1).to({y:176.85},0).wait(1).to({y:181.35},0).wait(1).to({y:185.85},0).wait(1).to({y:190.3},0).wait(1).to({y:194.8},0).wait(1).to({y:199.3},0).wait(1).to({y:203.75},0).wait(1).to({y:208.25},0).wait(1).to({y:212.7},0).wait(1).to({y:217.2},0).wait(1).to({y:221.7},0).wait(1).to({y:226.15},0).wait(1).to({y:230.65},0).wait(1).to({y:235.1},0).wait(1).to({y:239.6},0).wait(1).to({y:244.1},0).wait(1).to({y:248.55},0).wait(1).to({y:253.05},0).wait(1).to({y:257.55},0).wait(1).to({y:262},0).wait(1).to({y:266.5},0).wait(1).to({y:270.95},0).wait(1).to({y:275.45},0).wait(1).to({y:279.95},0).wait(1).to({y:284.4},0).wait(1).to({y:288.9},0).wait(1).to({y:293.4},0).wait(1).to({y:297.85},0).wait(1).to({y:302.35},0).wait(1).to({y:306.8},0).wait(1).to({y:311.3},0).wait(1).to({y:315.8},0).wait(1).to({y:320.25},0).wait(1).to({y:324.75},0).wait(1).to({y:329.25},0).wait(1).to({y:333.7},0).wait(1).to({y:338.2},0).wait(1).to({y:342.65},0).wait(1).to({y:347.15},0).wait(1).to({y:351.65},0).wait(1).to({y:356.1},0).wait(1).to({y:360.6},0).wait(1).to({y:365.1},0).wait(1).to({y:369.55},0).wait(1).to({y:374.05},0).wait(1).to({y:378.5},0).wait(1).to({y:383},0).wait(1).to({y:387.5},0).wait(1).to({y:391.95},0).wait(1).to({y:396.45},0).wait(1).to({y:400.95},0).wait(1).to({y:405.4},0).wait(1).to({y:409.9},0).wait(1).to({y:414.35},0).wait(1).to({y:418.85},0).wait(1).to({y:423.35},0).wait(1).to({y:427.8},0).wait(1).to({y:432.3},0).wait(1).to({y:436.75},0).wait(1).to({y:441.25},0).wait(1).to({y:445.75},0).wait(1).to({y:450.2},0).wait(1).to({y:454.7},0).wait(1).to({y:459.2},0).wait(1).to({y:463.65},0).wait(1).to({y:468.15},0).wait(1).to({y:472.6},0).wait(1).to({y:477.1},0).wait(1).to({y:481.6},0).wait(1).to({y:486.05},0).wait(1).to({y:490.55},0).wait(1).to({y:495},0).wait(1).to({y:499.5},0).wait(1).to({y:504},0).wait(1).to({y:508.45},0).wait(1).to({y:512.95},0).wait(1).to({y:517.45},0).wait(1).to({y:521.9},0).wait(1).to({y:526.4},0).wait(1).to({y:530.9},0).wait(1).to({y:535.35},0).wait(1).to({y:539.85},0).wait(1).to({y:544.3},0).wait(1).to({y:548.8},0).wait(1).to({y:553.3},0).wait(1).to({y:557.75},0).wait(1).to({y:562.25},0).wait(1).to({y:566.75},0).wait(1).to({y:571.2},0).wait(1).to({y:575.7},0).wait(1).to({y:580.15},0).wait(1).to({y:584.65},0).wait(1).to({y:589.15},0).wait(1).to({y:593.6},0).wait(1).to({y:598.1},0).wait(1).to({y:602.55},0).wait(1).to({y:607.05},0).wait(1).to({y:611.55},0).wait(1).to({y:616},0).wait(1).to({y:620.5},0).wait(1).to({y:625},0).wait(1).to({y:629.45},0).wait(1).to({y:633.95},0).wait(1).to({y:638.4},0).wait(1).to({y:642.9},0).wait(1).to({y:647.4},0).wait(1).to({y:651.85},0).wait(1).to({y:656.35},0).wait(1).to({y:660.85},0).wait(1).to({y:665.3},0).wait(1).to({y:669.8},0).wait(1).to({y:674.25},0).wait(1).to({y:678.75},0).wait(1).to({y:683.25},0).wait(1).to({y:687.7},0).wait(1).to({y:692.2},0).wait(1).to({y:696.7},0).wait(1).to({y:701.15},0).wait(1).to({y:705.65},0).wait(1).to({y:710.1},0).wait(1).to({y:714.6},0).wait(1).to({y:719.1},0).wait(1).to({y:723.55},0).wait(1).to({y:728.05},0).wait(1).to({y:732.5},0).wait(1).to({y:737},0).wait(1).to({y:741.5},0).wait(1).to({y:745.95},0).wait(1).to({y:750.45},0).wait(1).to({y:754.95},0).wait(1).to({y:759.4},0).wait(1).to({y:763.9},0).wait(1).to({y:768.4},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,85,802);


(lib.FinalScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{Animate:0});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_190 = function() {
		createjs.Sound.stop("books");
		createjs.Sound.stop("bags");
		createjs.Sound.stop("shoes");
		createjs.Sound.stop("gamemusic");
	}
	this.frame_191 = function() {
		playSound("likeamazon");
	}
	this.frame_546 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(190).call(this.frame_190).wait(1).call(this.frame_191).wait(355).call(this.frame_546).wait(1));

	// Ack
	this.text = new cjs.Text("BY: KATHERINE MAYER\nTHANK YOU TO CARLIN WING, MING-YUEN S. MA, MELANIE NAKAUE, T. KIM-TRANG TRAN, THE LORI BETTISON VARGA FUND, KRISTINE CHO & THE CLAREMONT GAME CENTER, THE MS192 COHORT, AND TO MY FRIENDS & FAMILY FOR MAKING THIS PROJECT POSSIBLE.", "35px 'Silom'");
	this.text.textAlign = "center";
	this.text.lineHeight = 47;
	this.text.lineWidth = 785;
	this.text.parent = this;
	this.text.setTransform(-0.5,289.9);
	this.text._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text).wait(504).to({_off:false},0).wait(1).to({y:277.7631},0).wait(1).to({y:265.6262},0).wait(1).to({y:253.4893},0).wait(1).to({y:241.3524},0).wait(1).to({y:229.2155},0).wait(1).to({y:217.0786},0).wait(1).to({y:204.9538},0).wait(1).to({y:192.8048},0).wait(1).to({y:180.6679},0).wait(1).to({y:168.531},0).wait(1).to({y:156.394},0).wait(1).to({y:144.2571},0).wait(1).to({y:132.1202},0).wait(1).to({y:119.9955},0).wait(1).to({y:107.8464},0).wait(1).to({y:95.7095},0).wait(1).to({y:83.5726},0).wait(1).to({y:71.4357},0).wait(1).to({y:59.2988},0).wait(1).to({y:47.1619},0).wait(1).to({y:35.025},0).wait(1).to({y:22.8881},0).wait(1).to({y:10.7512},0).wait(1).to({y:-1.3857},0).wait(1).to({y:-13.5226},0).wait(1).to({y:-25.6595},0).wait(1).to({y:-37.7964},0).wait(1).to({y:-49.9212},0).wait(1).to({y:-62.0702},0).wait(1).to({y:-74.2071},0).wait(1).to({y:-86.344},0).wait(1).to({y:-98.481},0).wait(1).to({y:-110.6179},0).wait(1).to({y:-122.7548},0).wait(1).to({y:-134.8917},0).wait(1).to({y:-147.0286},0).wait(1).to({y:-159.1655},0).wait(1).to({y:-171.3024},0).wait(1).to({y:-183.4393},0).wait(1).to({y:-195.5762},0).wait(1).to({y:-207.7131},0).wait(1).to({y:-219.85},0).wait(1));

	// NetWorth
	this.text_1 = new cjs.Text("$123,000,000,000", "38px 'Silom'", "#F19D39");
	this.text_1.lineHeight = 50;
	this.text_1.lineWidth = 367;
	this.text_1.parent = this;
	this.text_1.setTransform(-183.5,-31.2);
	this.text_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_1).wait(191).to({_off:false},0).wait(222).to({_off:true},1).wait(133));

	// RefreshToPlay
	this.text_2 = new cjs.Text("REFRESH TO PLAY AGAIN", "50px 'Silom'", "#F19D39");
	this.text_2.lineHeight = 66;
	this.text_2.lineWidth = 606;
	this.text_2.parent = this;
	this.text_2.setTransform(-303,289.9);
	this.text_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_2).wait(504).to({_off:false},0).wait(32).to({x:-303.0045,y:280.0591},0).wait(1).to({x:-303.0091,y:270.2182},0).wait(1).to({x:-303.0136,y:260.3871},0).wait(1).to({x:-303.0182,y:250.5364},0).wait(1).to({x:-303.0227,y:240.6955},0).wait(1).to({x:-303.0273,y:230.8644},0).wait(1).to({x:-303.0318,y:221.0235},0).wait(1).to({x:-303.0364,y:211.1727},0).wait(1).to({x:-303.0409,y:201.3318},0).wait(1).to({x:-303.0455,y:191.4909},0).wait(1).to({x:-303.05,y:181.65},0).wait(1));

	// GameOver
	this.text_3 = new cjs.Text("GAME OVER\n", "150px 'Silom'", "#F19D39");
	this.text_3.lineHeight = 193;
	this.text_3.lineWidth = 867;
	this.text_3.parent = this;
	this.text_3.setTransform(-433.45,-211.35);
	this.text_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_3).wait(414).to({_off:false},0).wait(91).to({y:-217.5893},0).wait(1).to({y:-223.8286},0).wait(1).to({y:-230.0679},0).wait(1).to({y:-236.3071},0).wait(1).to({y:-242.5464},0).wait(1).to({y:-248.7857},0).wait(1).to({y:-255.0188},0).wait(1).to({y:-261.2643},0).wait(1).to({y:-267.5036},0).wait(1).to({y:-273.7429},0).wait(1).to({y:-279.9821},0).wait(1).to({y:-286.2214},0).wait(1).to({y:-292.4607},0).wait(1).to({y:-298.6938},0).wait(1).to({y:-304.9393},0).wait(1).to({y:-311.1786},0).wait(1).to({y:-317.4179},0).wait(1).to({y:-323.6571},0).wait(1).to({y:-329.8964},0).wait(1).to({y:-336.1357},0).wait(1).to({y:-342.375},0).wait(1).to({y:-348.6143},0).wait(1).to({y:-354.8536},0).wait(1).to({y:-361.0929},0).wait(1).to({y:-367.3321},0).wait(1).to({y:-373.5714},0).wait(1).to({y:-379.8107},0).wait(1).to({y:-386.0438},0).wait(1).to({y:-392.2893},0).wait(1).to({y:-398.5286},0).wait(1).to({y:-404.7679},0).wait(1).to({y:-411.0071},0).wait(1).to({y:-417.2464},0).wait(1).to({y:-423.4857},0).wait(1).to({y:-429.725},0).wait(1).to({y:-435.9643},0).wait(1).to({y:-442.2036},0).wait(1).to({y:-448.4429},0).wait(1).to({y:-454.6821},0).wait(1).to({y:-460.9214},0).wait(1).to({y:-467.1607},0).wait(1).to({y:-473.4},0).wait(1));

	// Jeff
	this.instance = new lib.JeffBezos();
	this.instance.parent = this;
	this.instance.setTransform(41,20.2,1,1,0,0,0,274.7,199.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(414).to({_off:false},0).wait(91).to({regX:233.7,regY:179.6,x:0,y:-11.6},0).wait(1).to({y:-23.2},0).wait(1).to({y:-34.85},0).wait(1).to({y:-46.45},0).wait(1).to({y:-58.1},0).wait(1).to({y:-69.7},0).wait(1).to({y:-81.3},0).wait(1).to({y:-92.95},0).wait(1).to({y:-104.6},0).wait(1).to({y:-116.2},0).wait(1).to({y:-127.8},0).wait(1).to({y:-139.45},0).wait(1).to({y:-151.05},0).wait(1).to({y:-162.7},0).wait(1).to({y:-174.3},0).wait(1).to({y:-185.95},0).wait(1).to({y:-197.55},0).wait(1).to({y:-209.2},0).wait(1).to({y:-220.8},0).wait(1).to({y:-232.45},0).wait(1).to({y:-244.05},0).wait(1).to({y:-255.65},0).wait(1).to({y:-267.3},0).wait(1).to({y:-278.9},0).wait(1).to({y:-290.55},0).wait(1).to({y:-302.15},0).wait(1).to({y:-313.8},0).wait(1).to({y:-325.4},0).wait(1).to({y:-337.05},0).wait(1).to({y:-348.65},0).wait(1).to({y:-360.3},0).wait(1).to({y:-371.9},0).wait(1).to({y:-383.5},0).wait(1).to({y:-395.15},0).wait(1).to({y:-406.75},0).wait(1).to({y:-418.4},0).wait(1).to({y:-430},0).wait(1).to({y:-441.65},0).wait(1).to({y:-453.25},0).wait(1).to({y:-464.9},0).wait(1).to({y:-476.5},0).wait(1).to({y:-488.15},0).wait(1));

	// Layer_11
	this.instance_1 = new lib._2018();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-480,-168,0.4229,0.4229);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(116).to({_off:false},0).wait(74).to({_off:true},1).wait(356));

	// Layer_10
	this.instance_2 = new lib._20188();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-306,-86,0.3297,0.3297);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(103).to({_off:false},0).wait(84).to({_off:true},1).wait(359));

	// Layer_9
	this.instance_3 = new lib._2014();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-480,-14,0.4604,0.4603);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(85).to({_off:false},0).wait(99).to({_off:true},1).wait(362));

	// Layer_8
	this.instance_4 = new lib._2012();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-469.95,-239,0.4762,0.4762,12.4448);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(70).to({_off:false},0).to({_off:true},111).wait(366));

	// Layer_7
	this.instance_5 = new lib._2006();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-212.35,-272.7,0.4635,0.4634,14.999);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(53).to({_off:false},0).to({_off:true},124).wait(370));

	// Layer_6
	this.instance_6 = new lib._2004();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-503,75,0.4281,0.4281);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(35).to({_off:false},0).to({_off:true},139).wait(373));

	// Layer_5
	this.instance_7 = new lib._1999();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-520.45,-60.8,0.7072,0.7072,-8.7268);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(18).to({_off:false},0).to({_off:true},152).wait(377));

	// Layer_4
	this.instance_8 = new lib._1998();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-497,-280,0.5593,0.5592);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(2).to({_off:false},0).to({_off:true},164).wait(381));

	// Background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3EA7F3").s().p("EhK/ArwMAAAhXfMCV/AAAMAAABXfg");
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(72).to({_off:false},0).wait(21).to({_off:true},69).wait(385));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-555.9,-667.7,1116.3,1360.8000000000002);


(lib.ComputerArticle1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_144 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(144).call(this.frame_144).wait(2));

	// Button
	this.nextone_btn = new lib.nextbutton1();
	this.nextone_btn.name = "nextone_btn";
	this.nextone_btn.parent = this;
	this.nextone_btn.setTransform(838.3,535.65,1,1,0,0,0,79.8,94.8);
	this.nextone_btn._off = true;
	new cjs.ButtonHelper(this.nextone_btn, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.nextone_btn).wait(145).to({_off:false},0).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D6C2BB").s().p("Eg3AAGQIAAsfMBuBAAAIAAMfg");
	this.shape.setTransform(478.125,520);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(144).to({_off:false},0).to({_off:true},1).wait(1));

	// Layer_2
	this.text = new cjs.Text("THE YEAR IS 1994 ...", "30px 'Silom'");
	this.text.lineHeight = 40;
	this.text.lineWidth = 632;
	this.text.parent = this;
	this.text.setTransform(134.7,88.4);
	this.text._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text).wait(144).to({_off:false},0).to({_off:true},1).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D7C2BB").s().p("EhK/ArwMAAAhXfMCV/AAAMAAABXfUhKugBahLRABagEg2rAfQMBtXAAAMAAAg+fMhtXAAAg");
	this.shape_1.setTransform(480,267);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D7C2BB").s().p("EhK/ArwMAAAhXfMCV/AAAMAAABXfgEg2rAfQMBtXAAAMAAAg+fMhtXAAAg");
	this.shape_2.setTransform(480,280);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4E4643").s().p("Eg2rAfQMAAAg+fMBtXAAAMAAAA+fg");
	this.shape_3.setTransform(480,280);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},144).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-13,960,573);


(lib.CharacterObject = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// HitBoxCircle
	this.hitboxcircle = new lib.HitBoxCircle();
	this.hitboxcircle.name = "hitboxcircle";
	this.hitboxcircle.parent = this;
	this.hitboxcircle.setTransform(53.85,6.2);
	this.hitboxcircle.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.hitboxcircle).wait(1));

	// HitBoxObject
	this.hitboxcircle2 = new lib.HitCircle2();
	this.hitboxcircle2.name = "hitboxcircle2";
	this.hitboxcircle2.parent = this;
	this.hitboxcircle2.setTransform(17.4,16.9);
	this.hitboxcircle2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.hitboxcircle2).wait(1));

	// Layer_1
	this.instance = new lib.CRight1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.24,0.24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.CharacterObject, new cjs.Rectangle(0,-0.5,143.3,170.9), null);


(lib.CloudsFore = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.cloud1 = new lib.Cloud1();
	this.cloud1.name = "cloud1";
	this.cloud1.parent = this;
	this.cloud1.setTransform(836,150,1,1,0,0,0,0,100);

	this.cloud2 = new lib.Cloud2();
	this.cloud2.name = "cloud2";
	this.cloud2.parent = this;
	this.cloud2.setTransform(628,137,1,1,0,0,0,0,100);

	this.cloud3 = new lib.Cloud3();
	this.cloud3.name = "cloud3";
	this.cloud3.parent = this;
	this.cloud3.setTransform(281,100,1,1,0,0,0,0,100);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.cloud3},{t:this.cloud2},{t:this.cloud1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CloudsFore, new cjs.Rectangle(0,0,728,237), null);


(lib.CloudsBack = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.cloud4 = new lib.Cloud11();
	this.cloud4.name = "cloud4";
	this.cloud4.parent = this;
	this.cloud4.setTransform(611.95,100,1,1,0,0,0,100,100);

	this.cloud5 = new lib.Cloud22();
	this.cloud5.name = "cloud5";
	this.cloud5.parent = this;
	this.cloud5.setTransform(100,135,1,1,0,0,0,100,100);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.cloud5},{t:this.cloud4}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CloudsBack, new cjs.Rectangle(0,0,712,235), null);


(lib.LevelThreeArticle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		playSound("bags");
	}
	this.frame_721 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(720).call(this.frame_721).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6D76").s().p("Eg0CArwIAAsgMBnJAAAIAAMggEgzGgfPIAAsgMBnJAAAIAAMgg");
	this.shape.setTransform(-23.45,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(722));

	// Layer_2
	this.text = new cjs.Text("THE YEAR IS 2017 ...\n\nAMAZON HAS ACQUIRED A TOTAL OF 72 COMPANIES INCLUDING GROCERY STORE, WHOLE FOODS.\n\nTHIS YEAR, THE MEDIAN AMAZON EMPLOYEE EARNS JUST UNDER $28,500 WHILE JEFF BEZOS' NET WORTH INCREASES BY $40 BILLION .  \n\nADDITIONALLY, EMPLOYEES HAVE REPORTED HORRIFIC WORKING CONDITIONS IN FULFILLMENT WAREHOUSES. \n\nWILL YOU CONTINUE SUPPORTING AMAZON?", "30px 'Silom'", "#FF9900");
	this.text.lineHeight = 40;
	this.text.lineWidth = 613;
	this.text.parent = this;
	this.text.setTransform(-332.55,196.8);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({y:195.3741},0).wait(1).to({y:193.9483},0).wait(1).to({y:192.5224},0).wait(1).to({y:191.0965},0).wait(1).to({y:189.6706},0).wait(1).to({y:188.2448},0).wait(1).to({y:186.8189},0).wait(1).to({y:185.393},0).wait(1).to({y:183.9671},0).wait(1).to({y:182.5413},0).wait(1).to({y:181.1154},0).wait(1).to({y:179.6895},0).wait(1).to({y:178.2636},0).wait(1).to({y:176.8378},0).wait(1).to({y:175.4119},0).wait(1).to({y:173.986},0).wait(1).to({y:172.5601},0).wait(1).to({y:171.1343},0).wait(1).to({y:169.7084},0).wait(1).to({y:168.2825},0).wait(1).to({y:166.8566},0).wait(1).to({y:165.4308},0).wait(1).to({y:164.0049},0).wait(1).to({y:162.579},0).wait(1).to({y:161.1531},0).wait(1).to({y:159.7273},0).wait(1).to({y:158.3014},0).wait(1).to({y:156.8755},0).wait(1).to({y:155.4496},0).wait(1).to({y:154.0238},0).wait(1).to({y:152.5979},0).wait(1).to({y:151.172},0).wait(1).to({y:149.7461},0).wait(1).to({y:148.3202},0).wait(1).to({y:146.8944},0).wait(1).to({y:145.4685},0).wait(1).to({y:144.0426},0).wait(1).to({y:142.6168},0).wait(1).to({y:141.1909},0).wait(1).to({y:139.765},0).wait(1).to({y:138.3391},0).wait(1).to({y:136.9133},0).wait(1).to({y:135.4874},0).wait(1).to({y:134.0615},0).wait(1).to({y:132.6356},0).wait(1).to({y:131.2098},0).wait(1).to({y:129.7839},0).wait(1).to({y:128.358},0).wait(1).to({y:126.9321},0).wait(1).to({y:125.5063},0).wait(1).to({y:124.0804},0).wait(1).to({y:122.6545},0).wait(1).to({y:121.2286},0).wait(1).to({y:119.8028},0).wait(1).to({y:118.3769},0).wait(1).to({y:116.951},0).wait(1).to({y:115.5251},0).wait(1).to({y:114.0993},0).wait(1).to({y:112.6734},0).wait(1).to({y:111.2475},0).wait(1).to({y:109.8216},0).wait(1).to({y:108.3958},0).wait(1).to({y:106.9699},0).wait(1).to({y:105.544},0).wait(1).to({y:104.1181},0).wait(1).to({y:102.6923},0).wait(1).to({y:101.2664},0).wait(1).to({y:99.8405},0).wait(1).to({y:98.4146},0).wait(1).to({y:96.9888},0).wait(1).to({y:95.5629},0).wait(1).to({y:94.137},0).wait(1).to({y:92.7111},0).wait(1).to({y:91.2853},0).wait(1).to({y:89.8594},0).wait(1).to({y:88.4335},0).wait(1).to({y:87.0076},0).wait(1).to({y:85.5818},0).wait(1).to({y:84.1559},0).wait(1).to({y:82.73},0).wait(1).to({y:81.3041},0).wait(1).to({y:79.8783},0).wait(1).to({y:78.4524},0).wait(1).to({y:77.0265},0).wait(1).to({y:75.6006},0).wait(1).to({y:74.1748},0).wait(1).to({y:72.7489},0).wait(1).to({y:71.323},0).wait(1).to({y:69.8971},0).wait(1).to({y:68.4713},0).wait(1).to({y:67.0454},0).wait(1).to({y:65.6195},0).wait(1).to({y:64.1936},0).wait(1).to({y:62.7678},0).wait(1).to({y:61.3419},0).wait(1).to({y:59.916},0).wait(1).to({y:58.4916},0).wait(1).to({y:57.0643},0).wait(1).to({y:55.6384},0).wait(1).to({y:54.2125},0).wait(1).to({y:52.7866},0).wait(1).to({y:51.3608},0).wait(1).to({y:49.9363},0).wait(1).to({y:48.509},0).wait(1).to({y:47.0831},0).wait(1).to({y:45.6573},0).wait(1).to({y:44.2314},0).wait(1).to({y:42.8055},0).wait(1).to({y:41.3811},0).wait(1).to({y:39.9538},0).wait(1).to({y:38.5279},0).wait(1).to({y:37.102},0).wait(1).to({y:35.6761},0).wait(1).to({y:34.2503},0).wait(1).to({y:32.8258},0).wait(1).to({y:31.3985},0).wait(1).to({y:29.9726},0).wait(1).to({y:28.5468},0).wait(1).to({y:27.1209},0).wait(1).to({y:25.695},0).wait(1).to({y:24.2691},0).wait(1).to({y:22.8433},0).wait(1).to({y:21.4174},0).wait(1).to({y:19.9915},0).wait(1).to({y:18.5656},0).wait(1).to({y:17.1398},0).wait(1).to({y:15.7139},0).wait(1).to({y:14.288},0).wait(1).to({y:12.8621},0).wait(1).to({y:11.4363},0).wait(1).to({y:10.0104},0).wait(1).to({y:8.5845},0).wait(1).to({y:7.1586},0).wait(1).to({y:5.7328},0).wait(1).to({y:4.3069},0).wait(1).to({y:2.881},0).wait(1).to({y:1.4551},0).wait(1).to({y:0.0293},0).wait(1).to({y:-1.3966},0).wait(1).to({y:-2.8225},0).wait(1).to({y:-4.2484},0).wait(1).to({y:-5.6742},0).wait(1).to({y:-7.1001},0).wait(1).to({y:-8.526},0).wait(1).to({y:-9.9519},0).wait(1).to({y:-11.3777},0).wait(1).to({y:-12.8036},0).wait(1).to({y:-14.2295},0).wait(1).to({y:-15.6554},0).wait(1).to({y:-17.0812},0).wait(1).to({y:-18.5071},0).wait(1).to({y:-19.933},0).wait(1).to({y:-21.3589},0).wait(1).to({y:-22.7847},0).wait(1).to({y:-24.2106},0).wait(1).to({y:-25.6365},0).wait(1).to({y:-27.0624},0).wait(1).to({y:-28.4882},0).wait(1).to({y:-29.9141},0).wait(1).to({y:-31.34},0).wait(1).to({y:-32.7659},0).wait(1).to({y:-34.1917},0).wait(1).to({y:-35.6176},0).wait(1).to({y:-37.0435},0).wait(1).to({y:-38.4694},0).wait(1).to({y:-39.8952},0).wait(1).to({y:-41.3211},0).wait(1).to({y:-42.747},0).wait(1).to({y:-44.1729},0).wait(1).to({y:-45.5987},0).wait(1).to({y:-47.0246},0).wait(1).to({y:-48.4505},0).wait(1).to({y:-49.8764},0).wait(1).to({y:-51.3022},0).wait(1).to({y:-52.7281},0).wait(1).to({y:-54.154},0).wait(1).to({y:-55.5799},0).wait(1).to({y:-57.0057},0).wait(1).to({y:-58.4316},0).wait(1).to({y:-59.8575},0).wait(1).to({y:-61.2834},0).wait(1).to({y:-62.7092},0).wait(1).to({y:-64.1351},0).wait(1).to({y:-65.561},0).wait(1).to({y:-66.9854},0).wait(1).to({y:-68.4127},0).wait(1).to({y:-69.8386},0).wait(1).to({y:-71.2645},0).wait(1).to({y:-72.6904},0).wait(1).to({y:-74.1162},0).wait(1).to({y:-75.5421},0).wait(1).to({y:-76.968},0).wait(1).to({y:-78.3939},0).wait(1).to({y:-79.8183},0).wait(1).to({y:-81.2456},0).wait(1).to({y:-82.6715},0).wait(1).to({y:-84.0974},0).wait(1).to({y:-85.5232},0).wait(1).to({y:-86.9491},0).wait(1).to({y:-88.375},0).wait(1).to({y:-89.8009},0).wait(1).to({y:-91.2267},0).wait(1).to({y:-92.6526},0).wait(1).to({y:-94.0785},0).wait(1).to({y:-95.5044},0).wait(1).to({y:-96.9288},0).wait(1).to({y:-98.3561},0).wait(1).to({y:-99.782},0).wait(1).to({y:-101.2079},0).wait(1).to({y:-102.6338},0).wait(1).to({y:-104.0596},0).wait(1).to({y:-105.4855},0).wait(1).to({y:-106.9114},0).wait(1).to({y:-108.3372},0).wait(1).to({y:-109.7631},0).wait(1).to({y:-111.189},0).wait(1).to({y:-112.6149},0).wait(1).to({y:-114.0393},0).wait(1).to({y:-115.4666},0).wait(1).to({y:-116.8925},0).wait(1).to({y:-118.3184},0).wait(1).to({y:-119.7442},0).wait(1).to({y:-121.1701},0).wait(1).to({y:-122.596},0).wait(1).to({y:-124.0219},0).wait(1).to({y:-125.4477},0).wait(1).to({y:-126.8722},0).wait(1).to({y:-128.2995},0).wait(1).to({y:-129.7254},0).wait(1).to({y:-131.1498},0).wait(1).to({y:-132.5771},0).wait(1).to({y:-134.003},0).wait(1).to({y:-135.4289},0).wait(1).to({y:-136.8547},0).wait(1).to({y:-138.2806},0).wait(1).to({y:-139.7065},0).wait(1).to({y:-141.1324},0).wait(1).to({y:-142.5582},0).wait(1).to({y:-143.9827},0).wait(1).to({y:-145.41},0).wait(1).to({y:-146.8359},0).wait(1).to({y:-148.2617},0).wait(1).to({y:-149.6876},0).wait(1).to({y:-151.1135},0).wait(1).to({y:-152.5394},0).wait(1).to({y:-153.9652},0).wait(1).to({y:-155.3911},0).wait(1).to({y:-156.817},0).wait(1).to({y:-158.2429},0).wait(1).to({y:-159.6687},0).wait(1).to({y:-161.0932},0).wait(1).to({y:-162.5205},0).wait(1).to({y:-163.9464},0).wait(1).to({y:-165.3722},0).wait(1).to({y:-166.7981},0).wait(1).to({y:-168.224},0).wait(1).to({y:-169.6499},0).wait(1).to({y:-171.0757},0).wait(1).to({y:-172.5016},0).wait(1).to({y:-173.9275},0).wait(1).to({y:-175.3534},0).wait(1).to({y:-176.7792},0).wait(1).to({y:-178.2051},0).wait(1).to({y:-179.631},0).wait(1).to({y:-181.0569},0).wait(1).to({y:-182.4827},0).wait(1).to({y:-183.9086},0).wait(1).to({y:-185.3345},0).wait(1).to({y:-186.7604},0).wait(1).to({y:-188.1862},0).wait(1).to({y:-189.6121},0).wait(1).to({y:-191.038},0).wait(1).to({y:-192.4639},0).wait(1).to({y:-193.8897},0).wait(1).to({y:-195.3156},0).wait(1).to({y:-196.7415},0).wait(1).to({y:-198.1674},0).wait(1).to({y:-199.5933},0).wait(1).to({y:-201.0191},0).wait(1).to({y:-202.445},0).wait(1).to({y:-203.8709},0).wait(1).to({y:-205.2967},0).wait(1).to({y:-206.7226},0).wait(1).to({y:-208.1485},0).wait(1).to({y:-209.5744},0).wait(1).to({y:-211.0002},0).wait(1).to({y:-212.4261},0).wait(1).to({y:-213.852},0).wait(1).to({y:-215.2779},0).wait(1).to({y:-216.7037},0).wait(1).to({y:-218.1296},0).wait(1).to({y:-219.5555},0).wait(1).to({y:-220.9814},0).wait(1).to({y:-222.4072},0).wait(1).to({y:-223.8331},0).wait(1).to({y:-225.259},0).wait(1).to({y:-226.6849},0).wait(1).to({y:-228.1107},0).wait(1).to({y:-229.5366},0).wait(1).to({y:-230.9625},0).wait(1).to({y:-232.3884},0).wait(1).to({y:-233.8142},0).wait(1).to({y:-235.2401},0).wait(1).to({y:-236.666},0).wait(1).to({y:-238.0919},0).wait(1).to({y:-239.5177},0).wait(1).to({y:-240.9436},0).wait(1).to({y:-242.3695},0).wait(1).to({y:-243.7954},0).wait(1).to({y:-245.2212},0).wait(1).to({y:-246.6471},0).wait(1).to({y:-248.073},0).wait(1).to({y:-249.4989},0).wait(1).to({y:-250.9247},0).wait(1).to({y:-252.3506},0).wait(1).to({y:-253.7765},0).wait(1).to({y:-255.2024},0).wait(1).to({y:-256.6282},0).wait(1).to({y:-258.0541},0).wait(1).to({y:-259.48},0).wait(1).to({y:-260.9059},0).wait(1).to({y:-262.3317},0).wait(1).to({y:-263.7576},0).wait(1).to({y:-265.1835},0).wait(1).to({y:-266.6094},0).wait(1).to({y:-268.0352},0).wait(1).to({y:-269.4611},0).wait(1).to({y:-270.887},0).wait(1).to({y:-272.3129},0).wait(1).to({y:-273.7387},0).wait(1).to({y:-275.1646},0).wait(1).to({y:-276.5905},0).wait(1).to({y:-278.0164},0).wait(1).to({y:-279.4422},0).wait(1).to({y:-280.8681},0).wait(1).to({y:-282.294},0).wait(1).to({y:-283.7199},0).wait(1).to({y:-285.1457},0).wait(1).to({y:-286.5716},0).wait(1).to({y:-287.9975},0).wait(1).to({y:-289.4234},0).wait(1).to({y:-290.8492},0).wait(1).to({y:-292.2751},0).wait(1).to({y:-293.701},0).wait(1).to({y:-295.1269},0).wait(1).to({y:-296.5527},0).wait(1).to({y:-297.9786},0).wait(1).to({y:-299.4045},0).wait(1).to({y:-300.8304},0).wait(1).to({y:-302.2562},0).wait(1).to({y:-303.6821},0).wait(1).to({y:-305.108},0).wait(1).to({y:-306.5339},0).wait(1).to({y:-307.9597},0).wait(1).to({y:-309.3856},0).wait(1).to({y:-310.8115},0).wait(1).to({y:-312.2374},0).wait(1).to({y:-313.6632},0).wait(1).to({y:-315.0891},0).wait(1).to({y:-316.515},0).wait(1).to({y:-317.9409},0).wait(1).to({y:-319.3668},0).wait(1).to({y:-320.7926},0).wait(1).to({y:-322.2185},0).wait(1).to({y:-323.6444},0).wait(1).to({y:-325.0702},0).wait(1).to({y:-326.4961},0).wait(1).to({y:-327.922},0).wait(1).to({y:-329.3464},0).wait(1).to({y:-330.7723},0).wait(1).to({y:-332.1996},0).wait(1).to({y:-333.6255},0).wait(1).to({y:-335.0514},0).wait(1).to({y:-336.4773},0).wait(1).to({y:-337.9031},0).wait(1).to({y:-339.329},0).wait(1).to({y:-340.7549},0).wait(1).to({y:-342.1807},0).wait(1).to({y:-343.6066},0).wait(1).to({y:-345.0325},0).wait(1).to({y:-346.4584},0).wait(1).to({y:-347.8842},0).wait(1).to({y:-349.3101},0).wait(1).to({y:-350.736},0).wait(1).to({y:-352.1619},0).wait(1).to({y:-353.5878},0).wait(1).to({y:-355.0136},0).wait(1).to({y:-356.4381},0).wait(1).to({y:-357.8654},0).wait(1).to({y:-359.2912},0).wait(1).to({y:-360.7157},0).wait(1).to({y:-362.143},0).wait(1).to({y:-363.5689},0).wait(1).to({y:-364.9947},0).wait(1).to({y:-366.4206},0).wait(1).to({y:-367.8465},0).wait(1).to({y:-369.2724},0).wait(1).to({y:-370.6982},0).wait(1).to({y:-372.1241},0).wait(1).to({y:-373.55},0).wait(1).to({y:-374.9759},0).wait(1).to({y:-376.4017},0).wait(1).to({y:-377.8276},0).wait(1).to({y:-379.2535},0).wait(1).to({y:-380.6794},0).wait(1).to({y:-382.1052},0).wait(1).to({y:-383.5311},0).wait(1).to({y:-384.957},0).wait(1).to({y:-386.3814},0).wait(1).to({y:-387.8087},0).wait(1).to({y:-389.2346},0).wait(1).to({y:-390.6591},0).wait(1).to({y:-392.0864},0).wait(1).to({y:-393.5122},0).wait(1).to({y:-394.9367},0).wait(1).to({y:-396.364},0).wait(1).to({y:-397.7899},0).wait(1).to({y:-399.2157},0).wait(1).to({y:-400.6416},0).wait(1).to({y:-402.0675},0).wait(1).to({y:-403.4934},0).wait(1).to({y:-404.9192},0).wait(1).to({y:-406.3451},0).wait(1).to({y:-407.771},0).wait(1).to({y:-409.1969},0).wait(1).to({y:-410.6227},0).wait(1).to({y:-412.0486},0).wait(1).to({y:-413.4745},0).wait(1).to({y:-414.9004},0).wait(1).to({y:-416.3262},0).wait(1).to({y:-417.7521},0).wait(1).to({y:-419.178},0).wait(1).to({y:-420.6024},0).wait(1).to({y:-422.0297},0).wait(1).to({y:-423.4556},0).wait(1).to({y:-424.8801},0).wait(1).to({y:-426.3074},0).wait(1).to({y:-427.7332},0).wait(1).to({y:-429.1591},0).wait(1).to({y:-430.585},0).wait(1).to({y:-432.0109},0).wait(1).to({y:-433.4367},0).wait(1).to({y:-434.8626},0).wait(1).to({y:-436.2885},0).wait(1).to({y:-437.7144},0).wait(1).to({y:-439.1402},0).wait(1).to({y:-440.5661},0).wait(1).to({y:-441.992},0).wait(1).to({y:-443.4179},0).wait(1).to({y:-444.8437},0).wait(1).to({y:-446.2696},0).wait(1).to({y:-447.6955},0).wait(1).to({y:-449.1214},0).wait(1).to({y:-450.5458},0).wait(1).to({y:-451.9731},0).wait(1).to({y:-453.399},0).wait(1).to({y:-454.8234},0).wait(1).to({y:-456.2507},0).wait(1).to({y:-457.6766},0).wait(1).to({y:-459.1011},0).wait(1).to({y:-460.5284},0).wait(1).to({y:-461.9542},0).wait(1).to({y:-463.3801},0).wait(1).to({y:-464.806},0).wait(1).to({y:-466.2319},0).wait(1).to({y:-467.6577},0).wait(1).to({y:-469.0836},0).wait(1).to({y:-470.5095},0).wait(1).to({y:-471.9354},0).wait(1).to({y:-473.3612},0).wait(1).to({y:-474.7871},0).wait(1).to({y:-476.213},0).wait(1).to({y:-477.6389},0).wait(1).to({y:-479.0647},0).wait(1).to({y:-480.4906},0).wait(1).to({y:-481.9165},0).wait(1).to({y:-483.3424},0).wait(1).to({y:-484.7668},0).wait(1).to({y:-486.1941},0).wait(1).to({y:-487.62},0).wait(1).to({y:-489.0444},0).wait(1).to({y:-490.4717},0).wait(1).to({y:-491.8976},0).wait(1).to({y:-493.3235},0).wait(1).to({y:-494.7494},0).wait(1).to({y:-496.1752},0).wait(1).to({y:-497.6011},0).wait(1).to({y:-499.027},0).wait(1).to({y:-500.4529},0).wait(1).to({y:-501.8787},0).wait(1).to({y:-503.3046},0).wait(1).to({y:-504.7305},0).wait(1).to({y:-506.1564},0).wait(1).to({y:-507.5822},0).wait(1).to({y:-509.0081},0).wait(1).to({y:-510.434},0).wait(1).to({y:-511.8599},0).wait(1).to({y:-513.2857},0).wait(1).to({y:-514.7102},0).wait(1).to({y:-516.1375},0).wait(1).to({y:-517.5634},0).wait(1).to({y:-518.9878},0).wait(1).to({y:-520.4151},0).wait(1).to({y:-521.841},0).wait(1).to({y:-523.2654},0).wait(1).to({y:-524.6927},0).wait(1).to({y:-526.1186},0).wait(1).to({y:-527.5445},0).wait(1).to({y:-528.9704},0).wait(1).to({y:-530.3962},0).wait(1).to({y:-531.8221},0).wait(1).to({y:-533.248},0).wait(1).to({y:-534.6739},0).wait(1).to({y:-536.0997},0).wait(1).to({y:-537.5256},0).wait(1).to({y:-538.9515},0).wait(1).to({y:-540.3774},0).wait(1).to({y:-541.8033},0).wait(1).to({y:-543.2291},0).wait(1).to({y:-544.655},0).wait(1).to({y:-546.0809},0).wait(1).to({y:-547.5067},0).wait(1).to({y:-548.9312},0).wait(1).to({y:-550.3585},0).wait(1).to({y:-551.7844},0).wait(1).to({y:-553.2102},0).wait(1).to({y:-554.6361},0).wait(1).to({y:-556.062},0).wait(1).to({y:-557.4879},0).wait(1).to({y:-558.9138},0).wait(1).to({y:-560.3396},0).wait(1).to({y:-561.7655},0).wait(1).to({y:-563.1914},0).wait(1).to({y:-564.6172},0).wait(1).to({y:-566.0431},0).wait(1).to({y:-567.469},0).wait(1).to({y:-568.8949},0).wait(1).to({y:-570.3207},0).wait(1).to({y:-571.7466},0).wait(1).to({y:-573.1725},0).wait(1).to({y:-574.5984},0).wait(1).to({y:-576.0243},0).wait(1).to({y:-577.4501},0).wait(1).to({y:-578.876},0).wait(1).to({y:-580.3019},0).wait(1).to({y:-581.7277},0).wait(1).to({y:-583.1536},0).wait(1).to({y:-584.5795},0).wait(1).to({y:-586.0054},0).wait(1).to({y:-587.4312},0).wait(1).to({y:-588.8571},0).wait(1).to({y:-590.283},0).wait(1).to({y:-591.7089},0).wait(1).to({y:-593.1348},0).wait(1).to({y:-594.5606},0).wait(1).to({y:-595.9865},0).wait(1).to({y:-597.4124},0).wait(1).to({y:-598.8382},0).wait(1).to({y:-600.2641},0).wait(1).to({y:-601.69},0).wait(1).to({y:-603.1159},0).wait(1).to({y:-604.5417},0).wait(1).to({y:-605.9676},0).wait(1).to({y:-607.3935},0).wait(1).to({y:-608.8194},0).wait(1).to({y:-610.2453},0).wait(1).to({y:-611.6711},0).wait(1).to({y:-613.097},0).wait(1).to({y:-614.5229},0).wait(1).to({y:-615.9487},0).wait(1).to({y:-617.3746},0).wait(1).to({y:-618.8005},0).wait(1).to({y:-620.2264},0).wait(1).to({y:-621.6522},0).wait(1).to({y:-623.0781},0).wait(1).to({y:-624.504},0).wait(1).to({y:-625.9299},0).wait(1).to({y:-627.3557},0).wait(1).to({y:-628.7816},0).wait(1).to({y:-630.2075},0).wait(1).to({y:-631.6334},0).wait(1).to({y:-633.0592},0).wait(1).to({y:-634.4851},0).wait(1).to({y:-635.911},0).wait(1).to({y:-637.3369},0).wait(1).to({y:-638.7627},0).wait(1).to({y:-640.1886},0).wait(1).to({y:-641.6145},0).wait(1).to({y:-643.0404},0).wait(1).to({y:-644.4662},0).wait(1).to({y:-645.8921},0).wait(1).to({y:-647.318},0).wait(1).to({y:-648.7439},0).wait(1).to({y:-650.1697},0).wait(1).to({y:-651.5956},0).wait(1).to({y:-653.0215},0).wait(1).to({y:-654.4474},0).wait(1).to({y:-655.8732},0).wait(1).to({y:-657.2991},0).wait(1).to({y:-658.725},0).wait(1).to({y:-660.1509},0).wait(1).to({y:-661.5767},0).wait(1).to({y:-663.0026},0).wait(1).to({y:-664.4285},0).wait(1).to({y:-665.8544},0).wait(1).to({y:-667.2802},0).wait(1).to({y:-668.7061},0).wait(1).to({y:-670.132},0).wait(1).to({y:-671.5579},0).wait(1).to({y:-672.9837},0).wait(1).to({y:-674.4096},0).wait(1).to({y:-675.8355},0).wait(1).to({y:-677.2614},0).wait(1).to({y:-678.6872},0).wait(1).to({y:-680.1131},0).wait(1).to({y:-681.539},0).wait(1).to({y:-682.9649},0).wait(1).to({y:-684.3907},0).wait(1).to({y:-685.8166},0).wait(1).to({y:-687.2425},0).wait(1).to({y:-688.6684},0).wait(1).to({y:-690.0942},0).wait(1).to({y:-691.5201},0).wait(1).to({y:-692.946},0).wait(1).to({y:-694.3719},0).wait(1).to({y:-695.7977},0).wait(1).to({y:-697.2236},0).wait(1).to({y:-698.6495},0).wait(1).to({y:-700.0754},0).wait(1).to({y:-701.5012},0).wait(1).to({y:-702.9271},0).wait(1).to({y:-704.353},0).wait(1).to({y:-705.7789},0).wait(1).to({y:-707.2047},0).wait(1).to({y:-708.6306},0).wait(1).to({y:-710.0565},0).wait(1).to({y:-711.4824},0).wait(1).to({y:-712.9082},0).wait(1).to({y:-714.3341},0).wait(1).to({y:-715.76},0).wait(1).to({y:-717.1859},0).wait(1).to({y:-718.6117},0).wait(1).to({y:-720.0376},0).wait(1).to({y:-721.4635},0).wait(1).to({y:-722.8894},0).wait(1).to({y:-724.3152},0).wait(1).to({y:-725.7411},0).wait(1).to({y:-727.167},0).wait(1).to({y:-728.5929},0).wait(1).to({y:-730.0187},0).wait(1).to({y:-731.4446},0).wait(1).to({y:-732.8705},0).wait(1).to({y:-734.2964},0).wait(1).to({y:-735.7222},0).wait(1).to({y:-737.1481},0).wait(1).to({y:-738.574},0).wait(1).to({y:-739.9999},0).wait(1).to({y:-741.4257},0).wait(1).to({y:-742.8516},0).wait(1).to({y:-744.2775},0).wait(1).to({y:-745.7034},0).wait(1).to({y:-747.1292},0).wait(1).to({y:-748.5551},0).wait(1).to({y:-749.981},0).wait(1).to({y:-751.4069},0).wait(1).to({y:-752.8327},0).wait(1).to({y:-754.2586},0).wait(1).to({y:-755.6845},0).wait(1).to({y:-757.1104},0).wait(1).to({y:-758.5362},0).wait(1).to({y:-759.9621},0).wait(1).to({y:-761.388},0).wait(1).to({y:-762.8139},0).wait(1).to({y:-764.2397},0).wait(1).to({y:-765.6656},0).wait(1).to({y:-767.0915},0).wait(1).to({y:-768.5174},0).wait(1).to({y:-769.9432},0).wait(1).to({y:-771.3691},0).wait(1).to({y:-772.795},0).wait(1).to({y:-774.2209},0).wait(1).to({y:-775.6467},0).wait(1).to({y:-777.0726},0).wait(1).to({y:-778.4985},0).wait(1).to({y:-779.9244},0).wait(1).to({y:-781.3502},0).wait(1).to({y:-782.7761},0).wait(1).to({y:-784.202},0).wait(1).to({y:-785.6279},0).wait(1).to({y:-787.0537},0).wait(1).to({y:-788.4796},0).wait(1).to({y:-789.9055},0).wait(1).to({y:-791.3314},0).wait(1).to({y:-792.7572},0).wait(1).to({y:-794.1831},0).wait(1).to({y:-795.609},0).wait(1).to({y:-797.0349},0).wait(1).to({y:-798.4607},0).wait(1).to({y:-799.8866},0).wait(1).to({y:-801.3125},0).wait(1).to({y:-802.7384},0).wait(1).to({y:-804.1642},0).wait(1).to({y:-805.5901},0).wait(1).to({y:-807.016},0).wait(1).to({y:-808.4419},0).wait(1).to({y:-809.8677},0).wait(1).to({y:-811.2936},0).wait(1).to({y:-812.7195},0).wait(1).to({y:-814.1454},0).wait(1).to({y:-815.5712},0).wait(1).to({y:-816.9971},0).wait(1).to({y:-818.423},0).wait(1).to({y:-819.8489},0).wait(1).to({y:-821.2747},0).wait(1).to({y:-822.7006},0).wait(1).to({y:-824.1265},0).wait(1).to({y:-825.5524},0).wait(1).to({y:-826.9782},0).wait(1).to({y:-828.4041},0).wait(1).to({y:-829.83},0).wait(1).to({y:-831.25},0).wait(1));

	// Button
	this.levelthreenext_btn = new lib.levelthreenext_btn();
	this.levelthreenext_btn.name = "levelthreenext_btn";
	this.levelthreenext_btn.parent = this;
	this.levelthreenext_btn.setTransform(373.3,239.7);
	this.levelthreenext_btn._off = true;
	new cjs.ButtonHelper(this.levelthreenext_btn, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.levelthreenext_btn).wait(721).to({_off:false},0).wait(1));

	// Layer_1
	this.instance = new lib.ComputerArticle3();
	this.instance.parent = this;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2A2574").s().p("Eg4FAhiMAAAhDDMBwLAAAMAAABDDg");
	this.shape_1.setTransform(0.025,0.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.instance}]},479).to({state:[{t:this.shape_1},{t:this.instance}]},242).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-480,-833.2,960,1788.4);


(lib.articletwo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		playSound("acquisition");
	}
	this.frame_481 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(480).call(this.frame_481).wait(1));

	// Layer_5
	this.leveltwonext_btn = new lib.leveltwonext_btn();
	this.leveltwonext_btn.name = "leveltwonext_btn";
	this.leveltwonext_btn.parent = this;
	this.leveltwonext_btn.setTransform(390.65,236.85);
	this.leveltwonext_btn._off = true;
	new cjs.ButtonHelper(this.leveltwonext_btn, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.leveltwonext_btn).wait(481).to({_off:false},0).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2C3544").s().p("Eg9AAsOIAAsgMB1LAAAIAAMggEg4Kge3IAAtXMB1LAAAIAANXg");
	this.shape.setTransform(-9.45,-1.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(482));

	// Layer_2
	this.text = new cjs.Text("THE YEAR IS 2009 ... \n\nA BUSINESS ACQUISITION IS THE PURCHASE OF ONE CORPORATION BY ANOTHER.\n\nAMAZON HAS ACQUIRED 30 COMPANIES INCLUDING ONLINE SHOE RETAILER, ZAPPOS.\n\nAMONG THE 30 ARE RETAIL, DATABASE,\nINTERNET, AND SOFTWARE COMPANIES.\n\nAMAZON IS EVERYWHERE.", "30px 'Silom'", "#FFFFFF");
	this.text.lineHeight = 40;
	this.text.lineWidth = 677;
	this.text.parent = this;
	this.text.setTransform(-337.95,196.6);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({x:-337.9625,y:194.8896},0).wait(1).to({x:-337.975,y:193.1793},0).wait(1).to({x:-337.9875,y:191.4689},0).wait(1).to({x:-338,y:189.7585},0).wait(1).to({x:-338.0124,y:188.0481},0).wait(1).to({x:-338.0249,y:186.3378},0).wait(1).to({x:-338.0374,y:184.6274},0).wait(1).to({x:-338.0499,y:182.917},0).wait(1).to({x:-338.0624,y:181.2066},0).wait(1).to({x:-338.0749,y:179.4963},0).wait(1).to({x:-338.0874,y:177.7859},0).wait(1).to({x:-338.0999,y:176.0755},0).wait(1).to({x:-338.1124,y:174.3651},0).wait(1).to({x:-338.1248,y:172.6548},0).wait(1).to({x:-338.1373,y:170.9444},0).wait(1).to({x:-338.1498,y:169.234},0).wait(1).to({x:-338.1623,y:167.5236},0).wait(1).to({x:-338.1748,y:165.8133},0).wait(1).to({x:-338.1873,y:164.1029},0).wait(1).to({x:-338.1998,y:162.3925},0).wait(1).to({x:-338.2123,y:160.6821},0).wait(1).to({x:-338.2247,y:158.9717},0).wait(1).to({x:-338.2372,y:157.2614},0).wait(1).to({x:-338.2497,y:155.551},0).wait(1).to({x:-338.2622,y:153.8406},0).wait(1).to({x:-338.2747,y:152.1303},0).wait(1).to({x:-338.2872,y:150.4199},0).wait(1).to({x:-338.2997,y:148.7095},0).wait(1).to({x:-338.3122,y:146.9991},0).wait(1).to({x:-338.3247,y:145.2888},0).wait(1).to({x:-338.3371,y:143.5784},0).wait(1).to({x:-338.3496,y:141.868},0).wait(1).to({x:-338.3621,y:140.1576},0).wait(1).to({x:-338.3746,y:138.4473},0).wait(1).to({x:-338.3871,y:136.7369},0).wait(1).to({x:-338.3996,y:135.0265},0).wait(1).to({x:-338.4121,y:133.3161},0).wait(1).to({x:-338.4246,y:131.6058},0).wait(1).to({x:-338.4371,y:129.8954},0).wait(1).to({x:-338.4495,y:128.185},0).wait(1).to({x:-338.462,y:126.4746},0).wait(1).to({x:-338.4745,y:124.7643},0).wait(1).to({x:-338.487,y:123.0539},0).wait(1).to({x:-338.4995,y:121.3435},0).wait(1).to({x:-338.512,y:119.6331},0).wait(1).to({x:-338.5245,y:117.9228},0).wait(1).to({x:-338.537,y:116.2124},0).wait(1).to({x:-338.5494,y:114.502},0).wait(1).to({x:-338.5619,y:112.7916},0).wait(1).to({x:-338.5744,y:111.0813},0).wait(1).to({x:-338.5869,y:109.3709},0).wait(1).to({x:-338.5994,y:107.6605},0).wait(1).to({x:-338.6119,y:105.9518},0).wait(1).to({x:-338.6244,y:104.2398},0).wait(1).to({x:-338.6369,y:102.5294},0).wait(1).to({x:-338.6494,y:100.819},0).wait(1).to({x:-338.6618,y:99.1086},0).wait(1).to({x:-338.6743,y:97.3983},0).wait(1).to({x:-338.6868,y:95.6896},0).wait(1).to({x:-338.6993,y:93.9775},0).wait(1).to({x:-338.7118,y:92.2671},0).wait(1).to({x:-338.7243,y:90.5567},0).wait(1).to({x:-338.7368,y:88.8464},0).wait(1).to({x:-338.7493,y:87.136},0).wait(1).to({x:-338.7617,y:85.4273},0).wait(1).to({x:-338.7742,y:83.7153},0).wait(1).to({x:-338.7867,y:82.0049},0).wait(1).to({x:-338.7992,y:80.2945},0).wait(1).to({x:-338.8117,y:78.5841},0).wait(1).to({x:-338.8242,y:76.8738},0).wait(1).to({x:-338.8367,y:75.1634},0).wait(1).to({x:-338.8492,y:73.453},0).wait(1).to({x:-338.8617,y:71.7426},0).wait(1).to({x:-338.8741,y:70.0323},0).wait(1).to({x:-338.8866,y:68.3219},0).wait(1).to({x:-338.8991,y:66.6115},0).wait(1).to({x:-338.9116,y:64.9011},0).wait(1).to({x:-338.9241,y:63.1908},0).wait(1).to({x:-338.9366,y:61.4804},0).wait(1).to({x:-338.9491,y:59.77},0).wait(1).to({x:-338.9616,y:58.0596},0).wait(1).to({x:-338.9741,y:56.3493},0).wait(1).to({x:-338.9865,y:54.6389},0).wait(1).to({x:-338.999,y:52.9285},0).wait(1).to({x:-339.0115,y:51.2181},0).wait(1).to({x:-339.024,y:49.5078},0).wait(1).to({x:-339.0365,y:47.7974},0).wait(1).to({x:-339.049,y:46.087},0).wait(1).to({x:-339.0615,y:44.3766},0).wait(1).to({x:-339.074,y:42.6663},0).wait(1).to({x:-339.0865,y:40.9559},0).wait(1).to({x:-339.0989,y:39.2455},0).wait(1).to({x:-339.1114,y:37.5351},0).wait(1).to({x:-339.1239,y:35.8248},0).wait(1).to({x:-339.1364,y:34.1144},0).wait(1).to({x:-339.1489,y:32.404},0).wait(1).to({x:-339.1614,y:30.6936},0).wait(1).to({x:-339.1739,y:28.9833},0).wait(1).to({x:-339.1864,y:27.2729},0).wait(1).to({x:-339.1988,y:25.5625},0).wait(1).to({x:-339.2113,y:23.8521},0).wait(1).to({x:-339.2238,y:22.1417},0).wait(1).to({x:-339.2363,y:20.4331},0).wait(1).to({x:-339.2488,y:18.721},0).wait(1).to({x:-339.2613,y:17.0106},0).wait(1).to({x:-339.2738,y:15.302},0).wait(1).to({x:-339.2863,y:13.5899},0).wait(1).to({x:-339.2988,y:11.8795},0).wait(1).to({x:-339.3112,y:10.1691},0).wait(1).to({x:-339.3237,y:8.4588},0).wait(1).to({x:-339.3362,y:6.7484},0).wait(1).to({x:-339.3487,y:5.038},0).wait(1).to({x:-339.3612,y:3.3276},0).wait(1).to({x:-339.3737,y:1.6173},0).wait(1).to({x:-339.3862,y:-0.0931},0).wait(1).to({x:-339.3987,y:-1.8035},0).wait(1).to({x:-339.4112,y:-3.5139},0).wait(1).to({x:-339.4236,y:-5.2225},0).wait(1).to({x:-339.4361,y:-6.9346},0).wait(1).to({x:-339.4486,y:-8.645},0).wait(1).to({x:-339.4611,y:-10.3537},0).wait(1).to({x:-339.4736,y:-12.0657},0).wait(1).to({x:-339.4861,y:-13.7761},0).wait(1).to({x:-339.4986,y:-15.4865},0).wait(1).to({x:-339.5111,y:-17.1969},0).wait(1).to({x:-339.5236,y:-18.9072},0).wait(1).to({x:-339.536,y:-20.6176},0).wait(1).to({x:-339.5485,y:-22.328},0).wait(1).to({x:-339.561,y:-24.0384},0).wait(1).to({x:-339.5735,y:-25.747},0).wait(1).to({x:-339.586,y:-27.4591},0).wait(1).to({x:-339.5985,y:-29.1695},0).wait(1).to({x:-339.611,y:-30.8799},0).wait(1).to({x:-339.6235,y:-32.5902},0).wait(1).to({x:-339.6359,y:-34.3006},0).wait(1).to({x:-339.6484,y:-36.011},0).wait(1).to({x:-339.6609,y:-37.7214},0).wait(1).to({x:-339.6734,y:-39.4317},0).wait(1).to({x:-339.6859,y:-41.1421},0).wait(1).to({x:-339.6984,y:-42.8525},0).wait(1).to({x:-339.7109,y:-44.5629},0).wait(1).to({x:-339.7234,y:-46.2732},0).wait(1).to({x:-339.7359,y:-47.9836},0).wait(1).to({x:-339.7483,y:-49.694},0).wait(1).to({x:-339.7608,y:-51.4044},0).wait(1).to({x:-339.7733,y:-53.1147},0).wait(1).to({x:-339.7858,y:-54.8251},0).wait(1).to({x:-339.7983,y:-56.5355},0).wait(1).to({x:-339.8108,y:-58.2459},0).wait(1).to({x:-339.8233,y:-59.9562},0).wait(1).to({x:-339.8358,y:-61.6666},0).wait(1).to({x:-339.8483,y:-63.377},0).wait(1).to({x:-339.8607,y:-65.0874},0).wait(1).to({x:-339.8732,y:-66.7977},0).wait(1).to({x:-339.8857,y:-68.5081},0).wait(1).to({x:-339.8982,y:-70.2185},0).wait(1).to({x:-339.9107,y:-71.9289},0).wait(1).to({x:-339.9232,y:-73.6392},0).wait(1).to({x:-339.9357,y:-75.3496},0).wait(1).to({x:-339.9482,y:-77.06},0).wait(1).to({x:-339.9606,y:-78.7704},0).wait(1).to({x:-339.9731,y:-80.4807},0).wait(1).to({x:-339.9856,y:-82.1911},0).wait(1).to({x:-339.9981,y:-83.9015},0).wait(1).to({x:-340.0106,y:-85.6119},0).wait(1).to({x:-340.0231,y:-87.3222},0).wait(1).to({x:-340.0356,y:-89.0326},0).wait(1).to({x:-340.0481,y:-90.743},0).wait(1).to({x:-340.0606,y:-92.4534},0).wait(1).to({x:-340.073,y:-94.1637},0).wait(1).to({x:-340.0855,y:-95.8741},0).wait(1).to({x:-340.098,y:-97.5845},0).wait(1).to({x:-340.1105,y:-99.2949},0).wait(1).to({x:-340.123,y:-101.0052},0).wait(1).to({x:-340.1355,y:-102.7156},0).wait(1).to({x:-340.148,y:-104.426},0).wait(1).to({x:-340.1605,y:-106.1364},0).wait(1).to({x:-340.173,y:-107.8467},0).wait(1).to({x:-340.1854,y:-109.5571},0).wait(1).to({x:-340.1979,y:-111.2675},0).wait(1).to({x:-340.2104,y:-112.9779},0).wait(1).to({x:-340.2229,y:-114.6882},0).wait(1).to({x:-340.2354,y:-116.3986},0).wait(1).to({x:-340.2479,y:-118.109},0).wait(1).to({x:-340.2604,y:-119.8194},0).wait(1).to({x:-340.2729,y:-121.5297},0).wait(1).to({x:-340.2853,y:-123.2401},0).wait(1).to({x:-340.2978,y:-124.9505},0).wait(1).to({x:-340.3103,y:-126.6609},0).wait(1).to({x:-340.3228,y:-128.3712},0).wait(1).to({x:-340.3353,y:-130.0816},0).wait(1).to({x:-340.3478,y:-131.792},0).wait(1).to({x:-340.3603,y:-133.5024},0).wait(1).to({x:-340.3728,y:-135.2127},0).wait(1).to({x:-340.3853,y:-136.9231},0).wait(1).to({x:-340.3977,y:-138.6335},0).wait(1).to({x:-340.4102,y:-140.3422},0).wait(1).to({x:-340.4227,y:-142.0542},0).wait(1).to({x:-340.4352,y:-143.7646},0).wait(1).to({x:-340.4477,y:-145.475},0).wait(1).to({x:-340.4602,y:-147.1854},0).wait(1).to({x:-340.4727,y:-148.8957},0).wait(1).to({x:-340.4852,y:-150.6061},0).wait(1).to({x:-340.4977,y:-152.3165},0).wait(1).to({x:-340.5101,y:-154.0269},0).wait(1).to({x:-340.5226,y:-155.7355},0).wait(1).to({x:-340.5351,y:-157.4476},0).wait(1).to({x:-340.5476,y:-159.158},0).wait(1).to({x:-340.5601,y:-160.8684},0).wait(1).to({x:-340.5726,y:-162.5788},0).wait(1).to({x:-340.5851,y:-164.2891},0).wait(1).to({x:-340.5975,y:-165.9978},0).wait(1).to({x:-340.6101,y:-167.7099},0).wait(1).to({x:-340.6225,y:-169.4202},0).wait(1).to({x:-340.635,y:-171.1306},0).wait(1).to({x:-340.6475,y:-172.841},0).wait(1).to({x:-340.66,y:-174.5514},0).wait(1).to({x:-340.6725,y:-176.2617},0).wait(1).to({x:-340.685,y:-177.9721},0).wait(1).to({x:-340.6975,y:-179.6825},0).wait(1).to({x:-340.7099,y:-181.3912},0).wait(1).to({x:-340.7224,y:-183.1032},0).wait(1).to({x:-340.7349,y:-184.8136},0).wait(1).to({x:-340.7474,y:-186.524},0).wait(1).to({x:-340.7599,y:-188.2344},0).wait(1).to({x:-340.7724,y:-189.9447},0).wait(1).to({x:-340.7849,y:-191.6534},0).wait(1).to({x:-340.7974,y:-193.3655},0).wait(1).to({x:-340.8099,y:-195.0759},0).wait(1).to({x:-340.8224,y:-196.7862},0).wait(1).to({x:-340.8348,y:-198.4966},0).wait(1).to({x:-340.8473,y:-200.207},0).wait(1).to({x:-340.8598,y:-201.9174},0).wait(1).to({x:-340.8723,y:-203.6277},0).wait(1).to({x:-340.8848,y:-205.3381},0).wait(1).to({x:-340.8973,y:-207.0468},0).wait(1).to({x:-340.9098,y:-208.7589},0).wait(1).to({x:-340.9223,y:-210.4692},0).wait(1).to({x:-340.9348,y:-212.1796},0).wait(1).to({x:-340.9472,y:-213.89},0).wait(1).to({x:-340.9597,y:-215.6004},0).wait(1).to({x:-340.9722,y:-217.309},0).wait(1).to({x:-340.9847,y:-219.0211},0).wait(1).to({x:-340.9972,y:-220.7315},0).wait(1).to({x:-341.0097,y:-222.4402},0).wait(1).to({x:-341.0222,y:-224.1522},0).wait(1).to({x:-341.0347,y:-225.8626},0).wait(1).to({x:-341.0471,y:-227.573},0).wait(1).to({x:-341.0596,y:-229.2834},0).wait(1).to({x:-341.0721,y:-230.9937},0).wait(1).to({x:-341.0846,y:-232.7041},0).wait(1).to({x:-341.0971,y:-234.4145},0).wait(1).to({x:-341.1096,y:-236.1249},0).wait(1).to({x:-341.1221,y:-237.8352},0).wait(1).to({x:-341.1346,y:-239.5456},0).wait(1).to({x:-341.1471,y:-241.256},0).wait(1).to({x:-341.1595,y:-242.9647},0).wait(1).to({x:-341.172,y:-244.6767},0).wait(1).to({x:-341.1845,y:-246.3871},0).wait(1).to({x:-341.197,y:-248.0958},0).wait(1).to({x:-341.2095,y:-249.8079},0).wait(1).to({x:-341.222,y:-251.5182},0).wait(1).to({x:-341.2345,y:-253.2286},0).wait(1).to({x:-341.247,y:-254.939},0).wait(1).to({x:-341.2595,y:-256.6494},0).wait(1).to({x:-341.2719,y:-258.3597},0).wait(1).to({x:-341.2844,y:-260.0701},0).wait(1).to({x:-341.2969,y:-261.7805},0).wait(1).to({x:-341.3094,y:-263.4909},0).wait(1).to({x:-341.3219,y:-265.2012},0).wait(1).to({x:-341.3344,y:-266.9116},0).wait(1).to({x:-341.3469,y:-268.622},0).wait(1).to({x:-341.3594,y:-270.3324},0).wait(1).to({x:-341.3718,y:-272.0427},0).wait(1).to({x:-341.3843,y:-273.7531},0).wait(1).to({x:-341.3968,y:-275.4635},0).wait(1).to({x:-341.4093,y:-277.1739},0).wait(1).to({x:-341.4218,y:-278.8842},0).wait(1).to({x:-341.4343,y:-280.5946},0).wait(1).to({x:-341.4468,y:-282.305},0).wait(1).to({x:-341.4593,y:-284.0154},0).wait(1).to({x:-341.4718,y:-285.7257},0).wait(1).to({x:-341.4842,y:-287.4361},0).wait(1).to({x:-341.4967,y:-289.1465},0).wait(1).to({x:-341.5092,y:-290.8569},0).wait(1).to({x:-341.5217,y:-292.5672},0).wait(1).to({x:-341.5342,y:-294.2776},0).wait(1).to({x:-341.5467,y:-295.988},0).wait(1).to({x:-341.5592,y:-297.6984},0).wait(1).to({x:-341.5717,y:-299.4087},0).wait(1).to({x:-341.5842,y:-301.1191},0).wait(1).to({x:-341.5966,y:-302.8295},0).wait(1).to({x:-341.6091,y:-304.5399},0).wait(1).to({x:-341.6216,y:-306.2502},0).wait(1).to({x:-341.6341,y:-307.9606},0).wait(1).to({x:-341.6466,y:-309.671},0).wait(1).to({x:-341.6591,y:-311.3814},0).wait(1).to({x:-341.6716,y:-313.0917},0).wait(1).to({x:-341.6841,y:-314.8021},0).wait(1).to({x:-341.6965,y:-316.5125},0).wait(1).to({x:-341.709,y:-318.2229},0).wait(1).to({x:-341.7215,y:-319.9332},0).wait(1).to({x:-341.734,y:-321.6436},0).wait(1).to({x:-341.7465,y:-323.354},0).wait(1).to({x:-341.759,y:-325.0644},0).wait(1).to({x:-341.7715,y:-326.7747},0).wait(1).to({x:-341.784,y:-328.4851},0).wait(1).to({x:-341.7965,y:-330.1955},0).wait(1).to({x:-341.8089,y:-331.9059},0).wait(1).to({x:-341.8214,y:-333.6162},0).wait(1).to({x:-341.8339,y:-335.3266},0).wait(1).to({x:-341.8464,y:-337.037},0).wait(1).to({x:-341.8589,y:-338.7474},0).wait(1).to({x:-341.8714,y:-340.4577},0).wait(1).to({x:-341.8839,y:-342.1681},0).wait(1).to({x:-341.8964,y:-343.8785},0).wait(1).to({x:-341.9089,y:-345.5889},0).wait(1).to({x:-341.9213,y:-347.2992},0).wait(1).to({x:-341.9338,y:-349.0096},0).wait(1).to({x:-341.9463,y:-350.72},0).wait(1).to({x:-341.9588,y:-352.4304},0).wait(1).to({x:-341.9713,y:-354.1408},0).wait(1).to({x:-341.9838,y:-355.8511},0).wait(1).to({x:-341.9963,y:-357.5615},0).wait(1).to({x:-342.0088,y:-359.2719},0).wait(1).to({x:-342.0213,y:-360.9822},0).wait(1).to({x:-342.0337,y:-362.6926},0).wait(1).to({x:-342.0462,y:-364.403},0).wait(1).to({x:-342.0587,y:-366.1134},0).wait(1).to({x:-342.0712,y:-367.8237},0).wait(1).to({x:-342.0837,y:-369.5341},0).wait(1).to({x:-342.0962,y:-371.2445},0).wait(1).to({x:-342.1087,y:-372.9549},0).wait(1).to({x:-342.1212,y:-374.6652},0).wait(1).to({x:-342.1336,y:-376.3756},0).wait(1).to({x:-342.1461,y:-378.086},0).wait(1).to({x:-342.1586,y:-379.7964},0).wait(1).to({x:-342.1711,y:-381.5067},0).wait(1).to({x:-342.1836,y:-383.2171},0).wait(1).to({x:-342.1961,y:-384.9275},0).wait(1).to({x:-342.2086,y:-386.6379},0).wait(1).to({x:-342.2211,y:-388.3482},0).wait(1).to({x:-342.2336,y:-390.0586},0).wait(1).to({x:-342.246,y:-391.769},0).wait(1).to({x:-342.2585,y:-393.4794},0).wait(1).to({x:-342.271,y:-395.1897},0).wait(1).to({x:-342.2835,y:-396.9001},0).wait(1).to({x:-342.296,y:-398.6105},0).wait(1).to({x:-342.3085,y:-400.3209},0).wait(1).to({x:-342.321,y:-402.0312},0).wait(1).to({x:-342.3335,y:-403.7416},0).wait(1).to({x:-342.346,y:-405.452},0).wait(1).to({x:-342.3584,y:-407.1624},0).wait(1).to({x:-342.3709,y:-408.8727},0).wait(1).to({x:-342.3834,y:-410.5831},0).wait(1).to({x:-342.3959,y:-412.2935},0).wait(1).to({x:-342.4084,y:-414.0039},0).wait(1).to({x:-342.4209,y:-415.7142},0).wait(1).to({x:-342.4334,y:-417.4246},0).wait(1).to({x:-342.4459,y:-419.135},0).wait(1).to({x:-342.4583,y:-420.8454},0).wait(1).to({x:-342.4708,y:-422.5557},0).wait(1).to({x:-342.4833,y:-424.2661},0).wait(1).to({x:-342.4958,y:-425.9765},0).wait(1).to({x:-342.5083,y:-427.6869},0).wait(1).to({x:-342.5208,y:-429.3972},0).wait(1).to({x:-342.5333,y:-431.1076},0).wait(1).to({x:-342.5458,y:-432.818},0).wait(1).to({x:-342.5583,y:-434.5284},0).wait(1).to({x:-342.5707,y:-436.2387},0).wait(1).to({x:-342.5832,y:-437.9491},0).wait(1).to({x:-342.5957,y:-439.6595},0).wait(1).to({x:-342.6082,y:-441.3699},0).wait(1).to({x:-342.6207,y:-443.0802},0).wait(1).to({x:-342.6332,y:-444.7906},0).wait(1).to({x:-342.6457,y:-446.501},0).wait(1).to({x:-342.6582,y:-448.2114},0).wait(1).to({x:-342.6707,y:-449.9217},0).wait(1).to({x:-342.6831,y:-451.6321},0).wait(1).to({x:-342.6956,y:-453.3425},0).wait(1).to({x:-342.7081,y:-455.0529},0).wait(1).to({x:-342.7206,y:-456.7632},0).wait(1).to({x:-342.7331,y:-458.4736},0).wait(1).to({x:-342.7456,y:-460.184},0).wait(1).to({x:-342.7581,y:-461.8944},0).wait(1).to({x:-342.7706,y:-463.6047},0).wait(1).to({x:-342.783,y:-465.3151},0).wait(1).to({x:-342.7955,y:-467.0255},0).wait(1).to({x:-342.808,y:-468.7359},0).wait(1).to({x:-342.8205,y:-470.4462},0).wait(1).to({x:-342.833,y:-472.1566},0).wait(1).to({x:-342.8455,y:-473.867},0).wait(1).to({x:-342.858,y:-475.5774},0).wait(1).to({x:-342.8705,y:-477.286},0).wait(1).to({x:-342.883,y:-478.9981},0).wait(1).to({x:-342.8954,y:-480.7085},0).wait(1).to({x:-342.9079,y:-482.4172},0).wait(1).to({x:-342.9204,y:-484.1292},0).wait(1).to({x:-342.9329,y:-485.8396},0).wait(1).to({x:-342.9454,y:-487.55},0).wait(1).to({x:-342.9579,y:-489.2604},0).wait(1).to({x:-342.9704,y:-490.9707},0).wait(1).to({x:-342.9829,y:-492.6811},0).wait(1).to({x:-342.9954,y:-494.3915},0).wait(1).to({x:-343.0078,y:-496.1019},0).wait(1).to({x:-343.0203,y:-497.8122},0).wait(1).to({x:-343.0328,y:-499.5226},0).wait(1).to({x:-343.0453,y:-501.233},0).wait(1).to({x:-343.0578,y:-502.9417},0).wait(1).to({x:-343.0703,y:-504.6537},0).wait(1).to({x:-343.0828,y:-506.3641},0).wait(1).to({x:-343.0952,y:-508.0728},0).wait(1).to({x:-343.1078,y:-509.7849},0).wait(1).to({x:-343.1202,y:-511.4952},0).wait(1).to({x:-343.1327,y:-513.2056},0).wait(1).to({x:-343.1452,y:-514.916},0).wait(1).to({x:-343.1577,y:-516.6264},0).wait(1).to({x:-343.1702,y:-518.3368},0).wait(1).to({x:-343.1827,y:-520.0471},0).wait(1).to({x:-343.1952,y:-521.7575},0).wait(1).to({x:-343.2077,y:-523.4679},0).wait(1).to({x:-343.2201,y:-525.1783},0).wait(1).to({x:-343.2326,y:-526.8886},0).wait(1).to({x:-343.2451,y:-528.5973},0).wait(1).to({x:-343.2576,y:-530.3094},0).wait(1).to({x:-343.2701,y:-532.0197},0).wait(1).to({x:-343.2826,y:-533.7284},0).wait(1).to({x:-343.2951,y:-535.4405},0).wait(1).to({x:-343.3076,y:-537.1509},0).wait(1).to({x:-343.3201,y:-538.8612},0).wait(1).to({x:-343.3325,y:-540.5716},0).wait(1).to({x:-343.345,y:-542.282},0).wait(1).to({x:-343.3575,y:-543.9924},0).wait(1).to({x:-343.37,y:-545.7027},0).wait(1).to({x:-343.3825,y:-547.4131},0).wait(1).to({x:-343.395,y:-549.1235},0).wait(1).to({x:-343.4075,y:-550.8339},0).wait(1).to({x:-343.42,y:-552.5442},0).wait(1).to({x:-343.4324,y:-554.2529},0).wait(1).to({x:-343.4449,y:-555.965},0).wait(1).to({x:-343.4574,y:-557.6754},0).wait(1).to({x:-343.4699,y:-559.384},0).wait(1).to({x:-343.4824,y:-561.0961},0).wait(1).to({x:-343.4949,y:-562.8065},0).wait(1).to({x:-343.5074,y:-564.5169},0).wait(1).to({x:-343.5199,y:-566.2272},0).wait(1).to({x:-343.5324,y:-567.9376},0).wait(1).to({x:-343.5448,y:-569.648},0).wait(1).to({x:-343.5573,y:-571.3584},0).wait(1).to({x:-343.5698,y:-573.0687},0).wait(1).to({x:-343.5823,y:-574.7791},0).wait(1).to({x:-343.5948,y:-576.4895},0).wait(1).to({x:-343.6073,y:-578.1999},0).wait(1).to({x:-343.6198,y:-579.9085},0).wait(1).to({x:-343.6323,y:-581.6206},0).wait(1).to({x:-343.6448,y:-583.331},0).wait(1).to({x:-343.6572,y:-585.0397},0).wait(1).to({x:-343.6697,y:-586.7517},0).wait(1).to({x:-343.6822,y:-588.4621},0).wait(1).to({x:-343.6947,y:-590.1725},0).wait(1).to({x:-343.7072,y:-591.8829},0).wait(1).to({x:-343.7197,y:-593.5932},0).wait(1).to({x:-343.7322,y:-595.3036},0).wait(1).to({x:-343.7447,y:-597.014},0).wait(1).to({x:-343.7572,y:-598.7244},0).wait(1).to({x:-343.7696,y:-600.4347},0).wait(1).to({x:-343.7821,y:-602.1451},0).wait(1).to({x:-343.7946,y:-603.8555},0).wait(1).to({x:-343.8071,y:-605.5642},0).wait(1).to({x:-343.8196,y:-607.2762},0).wait(1).to({x:-343.8321,y:-608.9866},0).wait(1).to({x:-343.8446,y:-610.6953},0).wait(1).to({x:-343.8571,y:-612.4074},0).wait(1).to({x:-343.8695,y:-614.1177},0).wait(1).to({x:-343.882,y:-615.8281},0).wait(1).to({x:-343.8945,y:-617.5385},0).wait(1).to({x:-343.907,y:-619.2489},0).wait(1).to({x:-343.9195,y:-620.9592},0).wait(1).to({x:-343.932,y:-622.6696},0).wait(1).to({x:-343.9445,y:-624.38},0).wait(1).to({x:-343.95,y:-626.05},0).wait(1));

	// Layer_1
	this.instance = new lib.ComputerArticle2();
	this.instance.parent = this;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2C547E").s().p("Eg4ZAgMMAAAhAXMBwzAAAMAAABAXg");
	this.shape_1.setTransform(-1.975,-2.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.instance}]},481).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-480,-628,960,1307.6);


(lib.articleone = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		playSound("amazonstart");
	}
	this.frame_529 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(528).call(this.frame_529).wait(1));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D8C2BB").s().p("Eg1cAGQIAAsfMBq4AAAIAAMfg");
	this.shape.setTransform(-23.5,240);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(530));

	// Layer_5
	this.text = new cjs.Text("THE YEAR IS 1994 ...", "30px 'Silom'");
	this.text.lineHeight = 40;
	this.text.lineWidth = 555;
	this.text.parent = this;
	this.text.setTransform(-336.95,202);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({y:199.4164},0).wait(1).to({y:196.8329},0).wait(1).to({y:194.2519},0).wait(1).to({y:191.6658},0).wait(1).to({y:189.0822},0).wait(1).to({y:186.5013},0).wait(1).to({y:183.9177},0).wait(1).to({y:181.3316},0).wait(1).to({y:178.7506},0).wait(1).to({y:176.1645},0).wait(1).to({y:173.5809},0).wait(1).to({y:171},0).wait(1).to({y:168.4138},0).wait(1).to({y:165.8328},0).wait(1).to({y:163.2467},0).wait(1).to({y:160.6632},0).wait(1).to({y:158.0796},0).wait(1).to({y:155.4986},0).wait(1).to({y:152.9125},0).wait(1).to({y:150.3289},0).wait(1).to({y:147.7454},0).wait(1).to({y:145.1618},0).wait(1).to({y:142.5783},0).wait(1).to({y:139.9973},0).wait(1).to({y:137.4112},0).wait(1).to({y:134.8276},0).wait(1).to({y:132.2441},0).wait(1).to({y:129.6631},0).wait(1).to({y:127.077},0).wait(1).to({y:124.4934},0).wait(1).to({y:121.9125},0).wait(1).to({y:119.3263},0).wait(1).to({y:116.7428},0).wait(1).to({y:114.1592},0).wait(1).to({y:111.5757},0).wait(1).to({y:108.9947},0).wait(1).to({y:106.4086},0).wait(1).to({y:103.825},0).wait(1).to({y:101.2414},0).wait(1).to({y:98.6579},0).wait(1).to({y:96.0743},0).wait(1).to({y:93.4908},0).wait(1).to({y:90.9072},0).wait(1).to({y:88.3237},0).wait(1).to({y:85.7427},0).wait(1).to({y:83.1566},0).wait(1).to({y:80.573},0).wait(1).to({y:77.9921},0).wait(1).to({y:75.4059},0).wait(1).to({y:72.8224},0).wait(1).to({y:70.2388},0).wait(1).to({y:67.6553},0).wait(1).to({y:65.0743},0).wait(1).to({y:62.4882},0).wait(1).to({y:59.9046},0).wait(1).to({y:57.3236},0).wait(1).to({y:54.7375},0).wait(1).to({y:52.1539},0).wait(1).to({y:49.573},0).wait(1).to({y:46.9868},0).wait(1).to({y:44.4033},0).wait(1).to({y:41.8223},0).wait(1).to({y:39.2362},0).wait(1).to({y:36.6526},0).wait(1).to({y:34.0717},0).wait(1).to({y:31.4855},0).wait(1).to({y:28.902},0).wait(1).to({y:26.3184},0).wait(1).to({y:23.7349},0).wait(1).to({y:21.1513},0).wait(1).to({y:18.5678},0).wait(1).to({y:15.9868},0).wait(1).to({y:13.4007},0).wait(1).to({y:10.8171},0).wait(1).to({y:8.2361},0).wait(1).to({y:5.65},0).wait(1).to({y:3.0664},0).wait(1).to({y:0.4829},0).wait(1).to({y:-2.1007},0).wait(1).to({y:-4.6842},0).wait(1).to({y:-7.2678},0).wait(1).to({y:-9.8513},0).wait(1).to({y:-12.4349},0).wait(1).to({y:-15.0184},0).wait(1).to({y:-17.602},0).wait(1).to({y:-20.1855},0).wait(1).to({y:-22.7665},0).wait(1).to({y:-25.3526},0).wait(1).to({y:-27.9362},0).wait(1).to({y:-30.5172},0).wait(1).to({y:-33.1033},0).wait(1).to({y:-35.6868},0).wait(1).to({y:-38.2678},0).wait(1).to({y:-40.8539},0).wait(1).to({y:-43.4375},0).wait(1).to({y:-46.0185},0).wait(1).to({y:-48.6046},0).wait(1).to({y:-51.1882},0).wait(1).to({y:-53.7717},0).wait(1).to({y:-56.3553},0).wait(1).to({y:-58.9388},0).wait(1).to({y:-61.5224},0).wait(1).to({y:-64.1059},0).wait(1).to({y:-66.6895},0).wait(1).to({y:-69.273},0).wait(1).to({y:-71.854},0).wait(1).to({y:-74.4401},0).wait(1).to({y:-77.0237},0).wait(1).to({y:-79.6047},0).wait(1).to({y:-82.1908},0).wait(1).to({y:-84.7743},0).wait(1).to({y:-87.3553},0).wait(1).to({y:-89.9414},0).wait(1).to({y:-92.525},0).wait(1).to({y:-95.106},0).wait(1).to({y:-97.6921},0).wait(1).to({y:-100.2757},0).wait(1).to({y:-102.8566},0).wait(1).to({y:-105.4428},0).wait(1).to({y:-108.0263},0).wait(1).to({y:-110.6073},0).wait(1).to({y:-113.1934},0).wait(1).to({y:-115.777},0).wait(1).to({y:-118.3579},0).wait(1).to({y:-120.9441},0).wait(1).to({y:-123.5276},0).wait(1).to({y:-126.1086},0).wait(1).to({y:-128.6947},0).wait(1).to({y:-131.2783},0).wait(1).to({y:-133.8593},0).wait(1).to({y:-136.4454},0).wait(1).to({y:-139.0289},0).wait(1).to({y:-141.6125},0).wait(1).to({y:-144.1961},0).wait(1).to({y:-146.7796},0).wait(1).to({y:-149.3632},0).wait(1).to({y:-151.9467},0).wait(1).to({y:-154.5303},0).wait(1).to({y:-157.1138},0).wait(1).to({y:-159.6974},0).wait(1).to({y:-162.2809},0).wait(1).to({y:-164.8645},0).wait(1).to({y:-167.448},0).wait(1).to({y:-170.029},0).wait(1).to({y:-172.6151},0).wait(1).to({y:-175.1987},0).wait(1).to({y:-177.7797},0).wait(1).to({y:-180.3658},0).wait(1).to({y:-182.9493},0).wait(1).to({y:-185.5303},0).wait(1).to({y:-188.1164},0).wait(1).to({y:-190.7},0).wait(378));

	// Button
	this.nextone_btn = new lib.nextbutton1();
	this.nextone_btn.name = "nextone_btn";
	this.nextone_btn.parent = this;
	this.nextone_btn.setTransform(308.4,153.65);
	this.nextone_btn._off = true;
	new cjs.ButtonHelper(this.nextone_btn, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.nextone_btn).wait(529).to({_off:false},0).wait(1));

	// Layer_1
	this.instance = new lib.ComputerArticle1();
	this.instance.parent = this;
	this.instance.setTransform(1.2,0,1,1,0,0,0,480,267);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("Eg4lAgyMAAAhBkMBxMAAAMAAABBkg");
	this.shape_1.setTransform(3.05,0.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.instance}]},529).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-478.8,-280,960,560);


// stage content:
(lib.AmazonInvazion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{Animation:0,"Animation":229});

	// timeline functions:
	this.frame_0 = function() {
		//this.book.stop();
		//this.book.visible = false;
		this.moneycounter.visible = false;
		this.finalscreen.visible = false;
		this.congrats.visible = false;
		//createjs.Sound.play("letsplay", true, 0, 0, 0, 1);
	}
	this.frame_1 = function() {
		playSound("letsplay");
	}
	this.frame_229 = function() {
		this.stop();
		
		createjs.Touch.enable(stage);
		
		stage.mouseMoveOutside = true;
		
		var root = this;
		var stageHeight = stage.canvas.height;
		var stageWidth = stage.canvas.width;
		var midpoint = root.stage.canvas.width / 2;
		var scaleFactor = stage.scaleX;
		
		//Setting Up Book Generator
		var bookField = new createjs.Container();
		var shoeField = new createjs.Container();
		var bagField = new createjs.Container();
		//bookField.regX = stageWidth / 2;
		
		
		//Setting Score
		var score = 0;
		
		//Setting up mouse and character positon
		var mousex;
		var charx;
		
		//Call root function to set up a new game
		function init() {
			root.finalscreen.visible = false;
			score = 0;
			charx = 450;
			root.gotoAndPlay(Animation);
		}
		
		root.play_btn.addEventListener("click", fl_MouseClickHandler.bind(root));
		
		//What the play button does
		function fl_MouseClickHandler() {
			createjs.Sound.play("button", true, 0, 0, 0, 1);
			root.play_btn.visible = false;
			root.ground.visible = false;
			root.city.visible = false;
			root.cloudsfore.visible = false;
			root.cloudsback.visible = false;
			root.logosfore.visible = false;
			root.logosback.visible = false;
			root.moneycounter.visible = false;
			root.levelone_btn.visible = true;
			root.levelonecomputer.visible = true;
			root.play_btn.removeEventListener("click", fl_MouseClickHandler.bind(root));
			root.levelone_btn.addEventListener("click", fl_MouseClickHandler_2.bind(root));
		}
		
		
		//What the level one button does
		function fl_MouseClickHandler_2() {
			createjs.Sound.stop("letsplay");
			//createjs.Sound.play("amazonstart", true, 0, 0, 0, 1);
			createjs.Sound.play("button");
			root.levelone_btn.visible = false;
			root.levelonecomputer.visible = false;
			root.articleone.visible = true;
			root.articleone.play();
			//root.nextone_btn.visible = true;
			root.levelone_btn.removeEventListener("click", fl_MouseClickHandler_2.bind(root));
			root.articleone.nextone_btn.addEventListener("click", fl_MouseClickHandler_3.bind(root));
		}
		
		/*function fl_ClickToGoToWebPage() {
			window.open("https://fortune.com/1996/12/09/amazon-bookstore-next-big-thing/", "_blank");
		}*/
		
		//What the next button on article 1 page does
		function fl_MouseClickHandler_3() {
			createjs.Sound.play("button");
			//createjs.Sound.stop("amazonstart");
			//root.nextone_btn.visible = false;
			root.articleone.visible = false;
			root.instructions.visible = true;
			root.nexttwo_btn.visible = true;
			//root.articleone.removeEventListener("click", fl_ClickToGoToWebPage);
			root.articleone.nextone_btn.removeEventListener("click", fl_MouseClickHandler_3.bind(root));
			root.nexttwo_btn.addEventListener("click", fl_MouseClickHandler_4.bind(root));
		
		}
		
		//What the next button on instructions page does (sets up the game)
		function fl_MouseClickHandler_4() {
			createjs.Sound.play("button", true, 0, 0, 0, 1);
			createjs.Sound.play("gamemusic", true, 0, 0, 1, 1);
			root.instructions.visible = false;
			root.nexttwo_btn.visible = false;
			root.ground.visible = true;
			root.city.visible = true;
			root.characterobject.visible = true;
			root.moneycounter.visible = true;
			root.city.addChild(bookField);
			root.nexttwo_btn.removeEventListener("click", fl_MouseClickHandler_4.bind(root));
			root.city.addEventListener("click", fl_MouseClickHandler_5.bind(root));
			createjs.Ticker.on("tick", pickUpBook);
			setTimeout(function () {
				bringTheBooks(20);
			}, 800);
		
		
		
		}
		
		//Character movement
		function fl_MouseClickHandler_5() {
			mousex = Math.round(stage.mouseX) / scaleFactor;
			charx = Math.round(root.characterobject.x) / scaleFactor;
			if (mousex < 960 && mousex > 0 && mousex != charx) {
				root.characterobject.x = mousex;
			}
		}
		
		
		function bringTheBooks(booksnumber) {
			i = booksnumber - 1
			if (i >= 0) {
				var fallingBook = new lib.book();
				fallingBook.x = random(-100, stageWidth);
				//fallingBook.y = stageHeight;
				bookField.addChild(fallingBook);
				fallingBook.gotoAndPlay("Falling");
				setTimeout(function () {
					bringTheBooks(i);
				}, 2000);
			} else {
				setTimeout(function () {
					endLevel();
				}, 9000);
			}
		}
		
		function bringTheShoesAndBooks(objectnumber){
			i = objectnumber - 1
			if (i >= 0) {
				var fallingBook = new lib.book();
				var fallingShoe = new lib.shoe();
				fallingBook.x = random(-100, stageWidth);
				fallingShoe.x = random(-100, stageWidth);
				bookField.addChild(fallingBook);
				shoeField.addChild(fallingShoe);
				setTimeout(function () {
					bringTheShoesAndBooks(i);
				}, 2000);
			} else {
				setTimeout(function () {
					endLevel2();
				}, 12000);
			}
		}
		
		function bringAllObjects(objectnumber){
			i = objectnumber - 1
			if (i >= 0) {
				var fallingBook = new lib.book();
				var fallingShoe = new lib.shoe();
				var fallingBag = new lib.bag();
				fallingBook.x = random(-100, stageWidth);
				fallingShoe.x = random(-100, stageWidth);
				fallingBag.x = random(-100, stageWidth);
				bookField.addChild(fallingBook);
				shoeField.addChild(fallingShoe);
				bagField.addChild(fallingBag);
				setTimeout(function () {
					bringAllObjects(i);
				}, 2000);
			} else {
				setTimeout(function () {
					endLevel3();
				}, 15000);
			}
		}
		
		function pickUpBook() {
			for (var j = 0; j < bookField.getNumChildren(); j++) {
				var currentchild = bookField.getChildAt(j);
				var currentx = Math.round(root.characterobject.hitboxcircle.x) / scaleFactor;
				var currenty = Math.round(root.characterobject.hitboxcircle.y) / scaleFactor;
				var currentxx = Math.round(root.characterobject.hitboxcircle2.x) / scaleFactor;
				var currentyy = Math.round(root.characterobject.hitboxcircle2.y) / scaleFactor;
				var pt = root.characterobject.hitboxcircle.localToLocal(currentx, currenty, currentchild);
				var pt2 = root.characterobject.hitboxcircle2.localToLocal(currentxx, currentyy, currentchild);
				if ((currentchild.hitTest(pt.x, pt.y)) || (currentchild.hitTest(pt2.x, pt2.y)))  {
					createjs.Sound.play("books", true, 0, 0, 0, 1);
					score += 10;
					root.moneycounter.text = ("$ -" + score.toString());
					bookField.removeChildAt(j);
				}
			}
		}
		
		function pickUpShoe(){
			for (var j = 0; j < shoeField.getNumChildren(); j++) {
				var currentshoechild = shoeField.getChildAt(j);
				var currentx = Math.round(root.characterobject.hitboxcircle.x) / scaleFactor;
				var currenty = Math.round(root.characterobject.hitboxcircle.y) / scaleFactor;
				var currentxx = Math.round(root.characterobject.hitboxcircle2.x) / scaleFactor;
				var currentyy = Math.round(root.characterobject.hitboxcircle2.y) / scaleFactor;
				var pt2 = root.characterobject.hitboxcircle2.localToLocal(currentxx, currentyy, currentshoechild);
				var pt = root.characterobject.hitboxcircle.localToLocal(currentx, currenty, currentshoechild);
				if ((currentshoechild.hitTest(pt.x, pt.y)) || (currentshoechild.hitTest(pt2.x, pt2.y))) {
					createjs.Sound.play("shoes", true, 0, 0, 0, 1);
					score += 15;
					root.moneycounter.text = ("$ -" + score.toString());
					shoeField.removeChildAt(j);
				}
			}
		}
		
		function pickUpBag(){
			for (var j = 0; j < bagField.getNumChildren(); j++) {
				var currentbagchild = bagField.getChildAt(j);
				var currentx = Math.round(root.characterobject.hitboxcircle.x) / scaleFactor;
				var currenty = Math.round(root.characterobject.hitboxcircle.y) / scaleFactor;
				var currentxx = Math.round(root.characterobject.hitboxcircle2.x) / scaleFactor;
				var currentyy = Math.round(root.characterobject.hitboxcircle2.y) / scaleFactor;
				var pt2 = root.characterobject.hitboxcircle2.localToLocal(currentxx, currentyy, currentbagchild);
				var pt = root.characterobject.hitboxcircle.localToLocal(currentx, currenty, currentbagchild);
				if ((currentbagchild.hitTest(pt.x, pt.y)) || (currentbagchild.hitTest(pt2.x, pt2.y))){
					createjs.Sound.play("bags", true, 0, 0, 0, 1);
					score += 20;
					root.moneycounter.text = ("$ -" + score.toString());
					bagField.removeChildAt(j);
				}
			}
		}
		
		
		//What happens when the first level ends
		function endLevel() {
			createjs.Ticker.off("tick", pickUpBook);
			createjs.Sound.stop("gamemusic");
			createjs.Sound.stop("books");
			root.congrats.scoreupdate.text = ("$" + score.toString());
			bookField.removeAllChildren();
			root.ground.visible = false;
			root.city.visible = false;
			root.characterobject.visible = false;
			root.moneycounter.visible = false;
			root.congrats.visible = true;
			root.congrats_btn.visible = true;
			root.city.removeChild(bookField);
			root.city.removeEventListener("click", fl_MouseClickHandler_5.bind(root));
			root.congrats_btn.addEventListener("click", fl_MouseClickHandler_6.bind(root));
			
		}
		
		//What the next button on the congrats page does
		function fl_MouseClickHandler_6(){
			createjs.Sound.play("button", true, 0, 0, 0, 1);
			root.computertwo.visible = true;
			root.leveltwo_btn.visible = true;
			root.congrats.visible = false;
			root.congrats_btn.visible = false;
			root.congrats_btn.removeEventListener("click", fl_MouseClickHandler_6.bind(root));
			root.leveltwo_btn.addEventListener("click", fl_MouseClickHandler_7.bind(root));
		}
		
		//what the Level 2 button does -goes to article 
		function fl_MouseClickHandler_7(){
			createjs.Sound.play("button", true, 0, 0, 0, 1);
			//createjs.Sound.play("acquisition", true, 0, 0, 0, 1);
			root.computertwo.visible = false;
			root.leveltwo_btn.visible = false;
			root.articletwo.visible = true;
			root.articletwo.play();
			root.leveltwo_btn.removeEventListener("click", fl_MouseClickHandler_7.bind(root));
			root.articletwo.leveltwonext_btn.addEventListener("click", fl_MouseClickHandler_8.bind(root));
		}
		
		//What the next button on the article page does - goes to game
		function fl_MouseClickHandler_8(){
			//createjs.Sound.stop("acquisition");
			createjs.Sound.play("button", true, 0, 0, 0, 1);
			createjs.Sound.play("gamemusic");
			root.city.addChild(bookField);
			root.city.addChild(shoeField);
			root.city.addEventListener("click", fl_MouseClickHandler_5.bind(root));
			createjs.Ticker.on("tick", pickUpBook);
			createjs.Ticker.on("tick", pickUpShoe);
			root.ground.visible = true;
			root.city.visible = true;
			root.characterobject.visible = true;
			root.moneycounter.visible = true;
			root.articletwo.visible = false;
			setTimeout(function () {
				bringTheShoesAndBooks(15);
			}, 800);
		}
		
		//End of level goes into congrats screen
		function endLevel2(){
			createjs.Ticker.off("tick", pickUpBook);
			createjs.Ticker.off("tick", pickUpShoe);
			createjs.Sound.stop("gamemusic");
			createjs.Sound.stop("books");
			createjs.Sound.stop("shoes");
			root.congrats2.scoreupdate2.text = ("$" + score.toString());
			bookField.removeAllChildren();
			shoeField.removeAllChildren();
			root.ground.visible = false;
			root.city.visible = false;
			root.characterobject.visible = false;
			root.moneycounter.visible = false;
			root.congrats2.visible = true;
			root.congrats_btn2.visible = true;
			root.city.removeChild(bookField);
			root.city.removeChild(shoeField);
			root.city.removeEventListener("click", fl_MouseClickHandler_5.bind(root));
			root.congrats_btn2.addEventListener("click", fl_MouseClickHandler_9.bind(root));
		}
		
		//Congrats window after level two
		function fl_MouseClickHandler_9(){
			createjs.Sound.play("button", true, 0, 0, 0, 1);
			root.congrats2.visible = false;
			root.congrats_btn2.visible = false;
			root.computerthree.visible = true;
			root.levelthree_btn.visible = true;
			root.congrats_btn2.removeEventListener("click", fl_MouseClickHandler_9.bind(root));
			root.levelthree_btn.addEventListener("click", fl_MouseClickHandler_10.bind(root));
		}
		
		//Level 3 article window, this next button will take into game
		function fl_MouseClickHandler_10(){
			createjs.Sound.play("button", true, 0, 0, 0, 1);
			//createjs.Sound.play("bags", true, 0, 0, 0, 1);
			root.computerthree.visible = false;
			root.levelthree_btn.visible = false;
			root.articlethree.visible = true;
			root.articlethree.play();
			root.levelthree_btn.removeEventListener("click", fl_MouseClickHandler_10.bind(root));
			root.articlethree.levelthreenext_btn.addEventListener("click", fl_MouseClickHandler_11.bind(root));
		}
		
		//Next button is hit taking into level three
		function fl_MouseClickHandler_11(){
			//createjs.Sound.stop("bags");
			createjs.Sound.play("gamemusic", true, 0, 0, 1, 2);
			createjs.Sound.play("button", true, 0, 0, 0, 1);
			root.city.addChild(bookField);
			root.city.addChild(shoeField);
			root.city.addChild(bagField);
			root.city.addEventListener("click", fl_MouseClickHandler_5.bind(root));
			createjs.Ticker.on("tick", pickUpBook);
			createjs.Ticker.on("tick", pickUpShoe);
			createjs.Ticker.on("tick", pickUpBag);
			root.ground.visible = true;
			root.city.visible = true;
			root.characterobject.visible = true;
			root.moneycounter.visible = true;
			root.articlethree.visible = false;
			setTimeout(function () {
				bringAllObjects(30);
			}, 1200);
		}
		
		function endLevel3(){
			console.log("Level 3 ended.");
			createjs.Ticker.off("tick", pickUpBook);
			createjs.Ticker.off("tick", pickUpShoe);
			createjs.Ticker.off("tick", pickUpBag);
			root.congrats3.scoreupdate3.text = ("$" + score.toString());
			bookField.removeAllChildren();
			shoeField.removeAllChildren();
			bagField.removeAllChildren();
			root.ground.visible = false;
			root.city.visible = false;
			root.characterobject.visible = false;
			root.moneycounter.visible = false;
			root.congrats3.visible = true;
			
			//CONGRATS root.congrats_btn2.visible = true;
			root.city.removeChild(bookField);
			root.city.removeChild(shoeField);
			root.city.removeChild(bagField);
			setTimeout(function(){
				finalScreen();
			}, 6000);
			/*setTimeout(function(){
				createjs.Sound.stop("books");
			}, 8520);
			setTimeout(function(){
				createjs.Sound.stop("bags");
			}, 8520);
			setTimeout(function(){
				createjs.Sound.stop("shoes");
			}, 8520);
			setTimeout(function(){
				createjs.Sound.stop("gamemusic");
			}, 8520);*/
		}
		
		function finalScreen(){
			root.congrats3.visible = false;
			root.finalscreen.visible = true;
			root.finalscreen.play();
			/*setTimeout(function(){
				createjs.Sound.play("likeamazon", true, 0, 0, 0, 1);
			}, 2000);*/
		}
		
		
		function random(min, max) {
			return Math.floor(Math.random() * (max - min + 1) + min);
		}
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(228).call(this.frame_229).wait(1));

	// Level3CompLayers
	this.levelthree_btn = new lib.levelthree_btn();
	this.levelthree_btn.name = "levelthree_btn";
	this.levelthree_btn.parent = this;
	this.levelthree_btn.setTransform(409,202.05);
	this.levelthree_btn.visible = false;
	new cjs.ButtonHelper(this.levelthree_btn, 0, 1, 2);

	this.computerthree = new lib.Computer3();
	this.computerthree.name = "computerthree";
	this.computerthree.parent = this;
	this.computerthree.setTransform(480,280,1,1,0,0,0,0,5);
	this.computerthree.visible = false;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.computerthree},{t:this.levelthree_btn}]},229).wait(1));

	// Level3CompArticle
	this.articlethree = new lib.LevelThreeArticle();
	this.articlethree.name = "articlethree";
	this.articlethree.parent = this;
	this.articlethree.setTransform(480,280);
	this.articlethree.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.articlethree).wait(230));

	// Level2CompLayers
	this.leveltwo_btn = new lib.leveltwo_btn();
	this.leveltwo_btn.name = "leveltwo_btn";
	this.leveltwo_btn.parent = this;
	this.leveltwo_btn.setTransform(414,219.6);
	this.leveltwo_btn.visible = false;
	new cjs.ButtonHelper(this.leveltwo_btn, 0, 1, 2, false, new lib.leveltwo_btn(), 3);

	this.computertwo = new lib.Computer2();
	this.computertwo.name = "computertwo";
	this.computertwo.parent = this;
	this.computertwo.setTransform(480,280,1,1,0,0,0,-10,20);
	this.computertwo.visible = false;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.computertwo},{t:this.leveltwo_btn}]}).to({state:[{t:this.computertwo},{t:this.leveltwo_btn}]},229).wait(1));

	// Level2CompArticle
	this.articletwo = new lib.articletwo();
	this.articletwo.name = "articletwo";
	this.articletwo.parent = this;
	this.articletwo.setTransform(480,280);
	this.articletwo.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.articletwo).wait(230));

	// FinalBit
	this.finalscreen = new lib.FinalScreen();
	this.finalscreen.name = "finalscreen";
	this.finalscreen.parent = this;
	this.finalscreen.setTransform(480,280);

	this.timeline.addTween(cjs.Tween.get(this.finalscreen).wait(230));

	// Congrats3
	this.congrats3 = new lib.Congrats3();
	this.congrats3.name = "congrats3";
	this.congrats3.parent = this;
	this.congrats3.setTransform(367.7,161.65);
	this.congrats3.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.congrats3).wait(230));

	// Congrats2
	this.congrats2 = new lib.congrats2();
	this.congrats2.name = "congrats2";
	this.congrats2.parent = this;
	this.congrats2.setTransform(486.35,161.65);
	this.congrats2.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.congrats2).wait(230));

	// Congrats
	this.congrats = new lib.CongratsText();
	this.congrats.name = "congrats";
	this.congrats.parent = this;
	this.congrats.setTransform(517.5,145.25);
	this.congrats.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.congrats).wait(230));

	// CongratsButton2
	this.congrats_btn2 = new lib.congrats_btn2();
	this.congrats_btn2.name = "congrats_btn2";
	this.congrats_btn2.parent = this;
	this.congrats_btn2.setTransform(839.65,494.85);
	this.congrats_btn2.visible = false;
	new cjs.ButtonHelper(this.congrats_btn2, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.congrats_btn2).wait(230));

	// CongratsButton1
	this.congrats_btn = new lib.congrats_btn();
	this.congrats_btn.name = "congrats_btn";
	this.congrats_btn.parent = this;
	this.congrats_btn.setTransform(839.65,494.85);
	this.congrats_btn.visible = false;
	new cjs.ButtonHelper(this.congrats_btn, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.congrats_btn).wait(230));

	// Instructions2
	this.instructions = new lib.Instructions();
	this.instructions.name = "instructions";
	this.instructions.parent = this;
	this.instructions.setTransform(479.95,280.05,1,1,0,0,0,365.9,64.7);
	this.instructions.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.instructions).wait(230));

	// Instructions
	this.nexttwo_btn = new lib.nexttwo_btn();
	this.nexttwo_btn.name = "nexttwo_btn";
	this.nexttwo_btn.parent = this;
	this.nexttwo_btn.setTransform(865.2,494.9,1,1,0,0,0,79.8,94.8);
	this.nexttwo_btn.visible = false;
	new cjs.ButtonHelper(this.nexttwo_btn, 0, 1, 2);

	this.instructions_1 = new lib.Instructions_1();
	this.instructions_1.name = "instructions_1";
	this.instructions_1.parent = this;
	this.instructions_1.setTransform(358.85,152.05,1,1,0,0,0,340,140);
	this.instructions_1.visible = false;
	this.instructions_1.cache(28,28,624,224);

	this.instructionsbackup = new lib.Instructions_1();
	this.instructionsbackup.name = "instructionsbackup";
	this.instructionsbackup.parent = this;
	this.instructionsbackup.setTransform(358.85,152.05,1,1,0,0,0,340,140);
	this.instructionsbackup.visible = false;
	this.instructionsbackup.cache(28,28,624,224);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instructions_1},{t:this.nexttwo_btn}]}).to({state:[{t:this.instructionsbackup},{t:this.nexttwo_btn}]},229).wait(1));

	// Level1CompArticle
	this.nextone_btn = new lib.nextbutton1();
	this.nextone_btn.name = "nextone_btn";
	this.nextone_btn.parent = this;
	this.nextone_btn.setTransform(748.65,445.2,1,1,0,0,0,79.8,94.8);
	this.nextone_btn.visible = false;
	new cjs.ButtonHelper(this.nextone_btn, 0, 1, 2);

	this.articleframeone = new lib.ComputerArticle1();
	this.articleframeone.name = "articleframeone";
	this.articleframeone.parent = this;
	this.articleframeone.setTransform(480,280,1,1,0,0,0,480,280);
	this.articleframeone.visible = false;
	this.articleframeone.cache(-2,-15,964,577);

	this.articleone = new lib.articleone();
	this.articleone.name = "articleone";
	this.articleone.parent = this;
	this.articleone.setTransform(480,285,1.0268,1.0269,0,0,0,0.1,0.1);
	this.articleone.visible = false;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.articleframeone},{t:this.nextone_btn}]}).to({state:[{t:this.articleone}]},229).wait(1));

	// Level1Button
	this.levelone_btn = new lib.levelonebutton();
	this.levelone_btn.name = "levelone_btn";
	this.levelone_btn.parent = this;
	this.levelone_btn.setTransform(361.55,152.05);
	this.levelone_btn.visible = false;
	new cjs.ButtonHelper(this.levelone_btn, 0, 1, 2, false, new lib.levelonebutton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.levelone_btn).wait(230));

	// Level1Computer
	this.levelonecomputer = new lib.Computer1();
	this.levelonecomputer.name = "levelonecomputer";
	this.levelonecomputer.parent = this;
	this.levelonecomputer.setTransform(480,280,1,1,0,0,0,30,5);
	this.levelonecomputer.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.levelonecomputer).wait(230));

	// PlayButton
	this.play_btn = new lib.PlayButton();
	this.play_btn.name = "play_btn";
	this.play_btn.parent = this;
	this.play_btn.setTransform(606.5,328.5,1,1,0,0,0,585.2,255.2);
	this.play_btn.alpha = 0;
	this.play_btn._off = true;
	new cjs.ButtonHelper(this.play_btn, 0, 1, 2, false, new lib.PlayButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.play_btn).wait(194).to({_off:false},0).wait(1).to({regX:450.2,regY:250.2,x:471.5,y:323.5,alpha:0.04},0).wait(1).to({alpha:0.08},0).wait(1).to({alpha:0.12},0).wait(1).to({alpha:0.16},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.24},0).wait(1).to({alpha:0.28},0).wait(1).to({alpha:0.32},0).wait(1).to({alpha:0.36},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.44},0).wait(1).to({alpha:0.48},0).wait(1).to({alpha:0.52},0).wait(1).to({alpha:0.56},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.64},0).wait(1).to({alpha:0.68},0).wait(1).to({alpha:0.72},0).wait(1).to({alpha:0.76},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.84},0).wait(1).to({alpha:0.88},0).wait(1).to({alpha:0.92},0).wait(1).to({alpha:0.96},0).wait(1).to({alpha:1},0).wait(11));

	// Title
	this.gamelogo = new lib.AmazonInvazionLogo();
	this.gamelogo.name = "gamelogo";
	this.gamelogo.parent = this;
	this.gamelogo.setTransform(463.95,323.95,1,1,0,0,0,465.2,290.2);
	this.gamelogo.cache(248,208,434,164);

	this.timeline.addTween(cjs.Tween.get(this.gamelogo).wait(1).to({y:323.4},0).wait(1).to({y:322.85},0).wait(1).to({y:322.35},0).wait(1).to({y:321.8},0).wait(1).to({y:321.3},0).wait(1).to({y:320.75},0).wait(1).to({y:320.25},0).wait(1).to({y:319.7},0).wait(1).to({y:319.2},0).wait(1).to({y:318.65},0).wait(1).to({y:318.15},0).wait(1).to({y:317.6},0).wait(1).to({y:317.1},0).wait(1).to({y:316.55},0).wait(1).to({y:316.05},0).wait(1).to({y:315.5},0).wait(1).to({y:315},0).wait(1).to({y:314.45},0).wait(1).to({y:313.95},0).wait(1).to({y:313.4},0).wait(1).to({y:312.85},0).wait(1).to({y:312.35},0).wait(1).to({y:311.8},0).wait(1).to({y:311.3},0).wait(1).to({y:310.75},0).wait(1).to({y:310.25},0).wait(1).to({y:309.7},0).wait(1).to({y:309.2},0).wait(1).to({y:308.65},0).wait(1).to({y:308.15},0).wait(1).to({y:307.6},0).wait(1).to({y:307.1},0).wait(1).to({y:306.55},0).wait(1).to({y:306.05},0).wait(1).to({y:305.5},0).wait(1).to({y:305},0).wait(1).to({y:304.45},0).wait(1).to({y:303.95},0).wait(1).to({y:304.4},0).wait(1).to({y:304.9},0).wait(1).to({y:305.4},0).wait(1).to({y:305.85},0).wait(1).to({y:306.35},0).wait(1).to({y:306.85},0).wait(1).to({y:307.35},0).wait(1).to({y:307.8},0).wait(1).to({y:308.3},0).wait(1).to({y:308.8},0).wait(1).to({y:309.3},0).wait(1).to({y:309.75},0).wait(1).to({y:310.25},0).wait(1).to({y:310.75},0).wait(1).to({y:311.2},0).wait(1).to({y:311.7},0).wait(1).to({y:312.2},0).wait(1).to({y:312.7},0).wait(1).to({y:313.15},0).wait(1).to({y:313.65},0).wait(1).to({y:314.15},0).wait(1).to({y:314.65},0).wait(1).to({y:315.1},0).wait(1).to({y:315.6},0).wait(1).to({y:316.1},0).wait(1).to({y:316.55},0).wait(1).to({y:317.05},0).wait(1).to({y:317.55},0).wait(1).to({y:318.05},0).wait(1).to({y:318.5},0).wait(1).to({y:319},0).wait(1).to({y:319.5},0).wait(1).to({y:320},0).wait(1).to({y:320.45},0).wait(1).to({y:320.95},0).wait(1).to({y:321.45},0).wait(1).to({y:321.95},0).wait(1).to({y:321.45},0).wait(1).to({y:320.95},0).wait(1).to({y:320.45},0).wait(1).to({y:319.95},0).wait(1).to({y:319.45},0).wait(1).to({y:318.95},0).wait(1).to({y:318.45},0).wait(1).to({y:317.95},0).wait(1).to({y:317.45},0).wait(1).to({y:316.95},0).wait(1).to({y:316.45},0).wait(1).to({y:315.95},0).wait(1).to({y:315.45},0).wait(1).to({y:314.95},0).wait(1).to({y:314.45},0).wait(1).to({y:313.95},0).wait(1).to({y:313.45},0).wait(1).to({y:312.95},0).wait(1).to({y:312.45},0).wait(1).to({y:311.95},0).wait(1).to({y:311.45},0).wait(1).to({y:310.95},0).wait(1).to({y:310.45},0).wait(1).to({y:309.95},0).wait(1).to({y:309.45},0).wait(1).to({y:308.95},0).wait(1).to({y:308.45},0).wait(1).to({y:307.95},0).wait(1).to({y:307.45},0).wait(1).to({y:306.95},0).wait(1).to({y:306.45},0).wait(1).to({y:305.95},0).wait(1).to({y:305.45},0).wait(1).to({y:304.95},0).wait(1).to({y:304.45},0).wait(1).to({y:303.95},0).wait(1).to({y:304.45},0).wait(1).to({y:305},0).wait(1).to({y:305.5},0).wait(1).to({y:306.05},0).wait(1).to({y:306.55},0).wait(1).to({y:307.1},0).wait(1).to({y:307.65},0).wait(1).to({y:308.15},0).wait(1).to({y:308.7},0).wait(1).to({y:309.2},0).wait(1).to({y:309.75},0).wait(1).to({y:310.3},0).wait(1).to({y:310.8},0).wait(1).to({y:311.35},0).wait(1).to({y:311.85},0).wait(1).to({y:312.4},0).wait(1).to({y:312.95},0).wait(1).to({y:313.45},0).wait(1).to({y:314},0).wait(1).to({y:314.5},0).wait(1).to({y:315.05},0).wait(1).to({y:315.55},0).wait(1).to({y:316.1},0).wait(1).to({y:316.65},0).wait(1).to({y:317.15},0).wait(1).to({y:317.7},0).wait(1).to({y:318.2},0).wait(1).to({y:318.75},0).wait(1).to({y:319.3},0).wait(1).to({y:319.8},0).wait(1).to({y:320.35},0).wait(1).to({y:320.85},0).wait(1).to({y:321.4},0).wait(1).to({y:321.95},0).wait(1).to({y:321.2},0).wait(1).to({y:320.45},0).wait(1).to({y:319.7},0).wait(1).to({y:318.95},0).wait(1).to({y:318.2},0).wait(1).to({y:317.45},0).wait(1).to({y:316.7},0).wait(1).to({y:315.95},0).wait(1).to({y:315.2},0).wait(1).to({y:314.45},0).wait(1).to({y:313.7},0).wait(1).to({y:312.95},0).wait(1).to({y:312.2},0).wait(1).to({y:311.45},0).wait(1).to({y:310.7},0).wait(1).to({y:309.95},0).wait(1).to({y:309.2},0).wait(1).to({y:308.45},0).wait(1).to({y:307.7},0).wait(1).to({y:306.95},0).wait(1).to({y:306.2},0).wait(1).to({y:305.45},0).wait(1).to({y:304.7},0).wait(1).to({y:303.95},0).wait(5).to({alpha:0.9615},0).wait(1).to({alpha:0.9231},0).wait(1).to({alpha:0.8846},0).wait(1).to({alpha:0.8462},0).wait(1).to({alpha:0.8077},0).wait(1).to({alpha:0.7692},0).wait(1).to({alpha:0.7308},0).wait(1).to({alpha:0.6923},0).wait(1).to({alpha:0.6538},0).wait(1).to({alpha:0.6154},0).wait(1).to({alpha:0.5769},0).wait(1).to({alpha:0.5385},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.4615},0).wait(1).to({alpha:0.4231},0).wait(1).to({alpha:0.3846},0).wait(1).to({alpha:0.3462},0).wait(1).to({alpha:0.3077},0).wait(1).to({alpha:0.2692},0).wait(1).to({alpha:0.2308},0).wait(1).to({alpha:0.1923},0).wait(1).to({alpha:0.1538},0).wait(1).to({alpha:0.1154},0).wait(1).to({alpha:0.0769},0).wait(1).to({alpha:0.0385},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(30));

	// MoneyCounter
	this.moneycounter = new cjs.Text("$ 0", "42px 'Silom'");
	this.moneycounter.name = "moneycounter";
	this.moneycounter.lineHeight = 56;
	this.moneycounter.lineWidth = 291;
	this.moneycounter.parent = this;
	this.moneycounter.setTransform(28.05,479.55);
	this.moneycounter._off = true;

	this.timeline.addTween(cjs.Tween.get(this.moneycounter).wait(229).to({_off:false},0).wait(1));

	// CharacterObject
	this.characterobject = new lib.CharacterObject();
	this.characterobject.name = "characterobject";
	this.characterobject.parent = this;
	this.characterobject.setTransform(471.55,364.8,1,1,0,0,0,71.6,85.2);
	this.characterobject.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.characterobject).wait(230));

	// HotAirBalloon
	this.instance = new lib.HotAirBalloon();
	this.instance.parent = this;
	this.instance.setTransform(1010.05,79.55,0.2907,0.2906,0,0,0,254.8,245.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:257,regY:243.4,x:1001.8,y:75.2},0).wait(1).to({x:992.85,y:71.65},0).wait(1).to({x:983.8,y:68.4},0).wait(1).to({x:974.7,y:65.25},0).wait(1).to({x:965.5,y:62.35},0).wait(1).to({x:956.25,y:59.65},0).wait(1).to({x:946.95,y:57.2},0).wait(1).to({x:937.55,y:54.9},0).wait(1).to({x:928.15,y:52.8},0).wait(1).to({x:918.7,y:50.9},0).wait(1).to({x:909.2,y:49.25},0).wait(1).to({x:899.7,y:47.75},0).wait(1).to({x:890.15,y:46.4},0).wait(1).to({x:880.6,y:45.3},0).wait(1).to({x:871,y:44.35},0).wait(1).to({x:861.4,y:43.55},0).wait(1).to({x:851.75,y:42.95},0).wait(1).to({x:842.15,y:42.5},0).wait(1).to({x:832.5,y:42.25},0).wait(1).to({x:822.85,y:42.1},0).wait(1).to({x:813.25,y:42.15},0).wait(1).to({x:803.6,y:42.35},0).wait(1).to({x:793.95,y:42.65},0).wait(1).to({x:784.35,y:43.1},0).wait(1).to({x:774.7,y:43.7},0).wait(1).to({x:765.1,y:44.45},0).wait(1).to({x:755.5,y:45.3},0).wait(1).to({x:745.9,y:46.3},0).wait(1).to({x:736.35,y:47.4},0).wait(1).to({x:726.8,y:48.6},0).wait(1).to({x:717.25,y:49.95},0).wait(1).to({x:707.7,y:51.4},0).wait(1).to({x:698.2,y:52.95},0).wait(1).to({x:688.7,y:54.6},0).wait(1).to({x:679.25,y:56.35},0).wait(1).to({x:669.75,y:58.2},0).wait(1).to({x:664.25,y:60.6},0).wait(1).to({x:658.7,y:63},0).wait(1).to({x:653.15,y:65.3},0).wait(1).to({x:647.6,y:67.55},0).wait(1).to({x:642,y:69.8},0).wait(1).to({x:636.4,y:71.95},0).wait(1).to({x:630.75,y:74.05},0).wait(1).to({x:625.1,y:76.15},0).wait(1).to({x:619.45,y:78.2},0).wait(1).to({x:613.75,y:80.2},0).wait(1).to({x:608.05,y:82.15},0).wait(1).to({x:602.35,y:84.05},0).wait(1).to({x:596.6,y:85.9},0).wait(1).to({x:590.85,y:87.7},0).wait(1).to({x:585.1,y:89.45},0).wait(1).to({x:579.35,y:91.15},0).wait(1).to({x:573.55,y:92.8},0).wait(1).to({x:567.75,y:94.4},0).wait(1).to({x:561.9,y:95.95},0).wait(1).to({x:556.1,y:97.45},0).wait(1).to({x:550.25,y:98.9},0).wait(1).to({x:544.35,y:100.25},0).wait(1).to({x:538.5,y:101.6},0).wait(1).to({x:532.6,y:102.9},0).wait(1).to({x:526.7,y:104.1},0).wait(1).to({x:520.8,y:105.3},0).wait(1).to({x:514.9,y:106.4},0).wait(1).to({x:509,y:107.5},0).wait(1).to({x:503.05,y:108.5},0).wait(1).to({x:497.1,y:109.45},0).wait(1).to({x:491.15,y:110.35},0).wait(1).to({x:485.2,y:111.2},0).wait(1).to({x:479.2,y:112},0).wait(1).to({x:473.25,y:112.75},0).wait(1).to({x:467.25,y:113.4},0).wait(1).to({x:461.25,y:114.05},0).wait(1).to({x:455.25,y:114.6},0).wait(1).to({x:449.25,y:115.1},0).wait(1).to({x:443.25,y:115.55},0).wait(1).to({x:437.25,y:115.95},0).wait(1).to({x:431.25,y:116.3},0).wait(1).to({x:425.25,y:116.6},0).wait(1).to({x:419.2,y:116.8},0).wait(1).to({x:413.2,y:116.95},0).wait(1).to({x:407.15,y:117.1},0).wait(1).to({x:401.15,y:117.15},0).wait(1).to({x:395.15},0).wait(1).to({x:389.1,y:117.05},0).wait(1).to({x:383.1,y:116.95},0).wait(1).to({x:377.05,y:116.8},0).wait(1).to({x:371.05,y:116.55},0).wait(1).to({x:365.05,y:116.25},0).wait(1).to({x:359,y:115.9},0).wait(1).to({x:353,y:115.5},0).wait(1).to({x:347,y:115.05},0).wait(1).to({x:341,y:114.55},0).wait(1).to({x:335,y:114},0).wait(1).to({x:329,y:113.35},0).wait(1).to({x:324.8,y:113.2},0).wait(1).to({x:320.55,y:112.95},0).wait(1).to({x:316.3,y:112.7},0).wait(1).to({x:312.1,y:112.45},0).wait(1).to({x:307.85,y:112.15},0).wait(1).to({x:303.65,y:111.8},0).wait(1).to({x:299.4,y:111.4},0).wait(1).to({x:295.2,y:111},0).wait(1).to({x:290.95,y:110.55},0).wait(1).to({x:286.75,y:110.05},0).wait(1).to({x:282.55,y:109.55},0).wait(1).to({x:278.35,y:109},0).wait(1).to({x:274.15,y:108.45},0).wait(1).to({x:269.95,y:107.85},0).wait(1).to({x:265.75,y:107.2},0).wait(1).to({x:261.55,y:106.55},0).wait(1).to({x:257.35,y:105.8},0).wait(1).to({x:253.2,y:105.1},0).wait(1).to({x:249,y:104.3},0).wait(1).to({x:244.85,y:103.5},0).wait(1).to({x:240.7,y:102.7},0).wait(1).to({x:236.55,y:101.85},0).wait(1).to({x:232.4,y:100.95},0).wait(1).to({x:228.25,y:100},0).wait(1).to({x:224.1,y:99.05},0).wait(1).to({x:220,y:98.05},0).wait(1).to({x:215.85,y:97.05},0).wait(1).to({x:211.75,y:96},0).wait(1).to({x:207.65,y:94.9},0).wait(1).to({x:203.55,y:93.8},0).wait(1).to({x:199.5,y:92.65},0).wait(1).to({x:195.4,y:91.5},0).wait(1).to({x:191.35,y:90.3},0).wait(1).to({x:187.3,y:89.05},0).wait(1).to({x:183.25,y:87.8},0).wait(1).to({x:179.2,y:86.5},0).wait(1).to({x:175.15,y:85.2},0).wait(1).to({x:171.15,y:83.85},0).wait(1).to({x:167.1,y:82.45},0).wait(1).to({x:163.1,y:81.05},0).wait(1).to({x:159.1,y:79.65},0).wait(1).to({x:155.15,y:78.2},0).wait(1).to({x:151.15,y:76.7},0).wait(1).to({x:147.2,y:75.2},0).wait(1).to({x:143.25,y:73.65},0).wait(1).to({x:139.3,y:72.05},0).wait(1).to({x:135.4,y:70.5},0).wait(1).to({x:131.45,y:68.9},0).wait(1).to({x:127.55,y:67.25},0).wait(1).to({x:123.65,y:65.6},0).wait(1).to({x:119.75,y:63.85},0).wait(1).to({x:115.9,y:62.15},0).wait(1).to({x:112.05,y:60.4},0).wait(1).to({x:108.15,y:58.6},0).wait(1).to({x:102.8,y:57.55},0).wait(1).to({x:97.35,y:56.55},0).wait(1).to({x:91.95,y:55.65},0).wait(1).to({x:86.5,y:54.85},0).wait(1).to({x:81.05,y:54.15},0).wait(1).to({x:75.55,y:53.5},0).wait(1).to({x:70.15,y:52.95},0).wait(1).to({x:64.65,y:52.5},0).wait(1).to({x:59.15,y:52.2},0).wait(1).to({x:53.65,y:51.95},0).wait(1).to({x:48.15,y:51.8},0).wait(1).to({x:42.65,y:51.75},0).wait(1).to({x:37.15,y:51.85},0).wait(1).to({x:31.65,y:52.05},0).wait(1).to({x:26.15,y:52.35},0).wait(1).to({x:20.7,y:52.75},0).wait(1).to({x:15.2,y:53.3},0).wait(1).to({x:9.75,y:53.95},0).wait(1).to({x:4.3,y:54.7},0).wait(1).to({x:-1.15,y:55.6},0).wait(1).to({x:-6.55,y:56.6},0).wait(1).to({x:-11.95,y:57.75},0).wait(1).to({x:-17.3,y:59},0).wait(1).to({x:-22.6,y:60.35},0).wait(1).to({x:-27.9,y:61.85},0).wait(1).to({x:-33.15,y:63.5},0).wait(1).to({x:-38.4,y:65.25},0).wait(1).to({x:-43.55,y:67.1},0).wait(1).to({x:-48.7,y:69.1},0).wait(1).to({x:-53.75,y:71.15},0).wait(1).to({x:-58.8,y:73.4},0).wait(1).to({x:-63.8,y:75.75},0).wait(1).to({x:-68.7,y:78.2},0).wait(1).to({x:-73.6,y:80.75},0).wait(26).to({_off:true},1).wait(21));

	// LogosFore
	this.logosfore = new lib.PillPackPlane();
	this.logosfore.name = "logosfore";
	this.logosfore.parent = this;
	this.logosfore.setTransform(1500.8,-80.45,0.4219,0.4215,0,0,180,310.4,47.6);
	this.logosfore.cache(18,168,383,174);

	this.timeline.addTween(cjs.Tween.get(this.logosfore).wait(1).to({regX:209.8,regY:255.3,x:1534.4,y:7.5},0).wait(1).to({x:1525.6,y:7.9},0).wait(1).to({x:1516.8,y:8.25},0).wait(1).to({x:1508,y:8.65},0).wait(1).to({x:1499.2,y:9},0).wait(1).to({x:1490.4,y:9.4},0).wait(1).to({x:1481.6,y:9.75},0).wait(1).to({x:1472.8,y:10.15},0).wait(1).to({x:1464,y:10.5},0).wait(1).to({x:1455.2,y:10.9},0).wait(1).to({x:1446.4,y:11.25},0).wait(1).to({x:1437.6,y:11.65},0).wait(1).to({x:1428.8,y:12},0).wait(1).to({x:1420,y:12.4},0).wait(1).to({x:1411.2,y:12.75},0).wait(1).to({x:1402.4,y:13.15},0).wait(1).to({x:1393.6,y:13.5},0).wait(1).to({x:1384.8,y:13.9},0).wait(1).to({x:1376,y:14.25},0).wait(1).to({x:1367.2,y:14.65},0).wait(1).to({x:1358.4,y:15.05},0).wait(1).to({x:1349.55,y:15.4},0).wait(1).to({x:1340.75,y:15.8},0).wait(1).to({x:1331.95,y:16.15},0).wait(1).to({x:1323.15,y:16.55},0).wait(1).to({x:1314.35,y:16.9},0).wait(1).to({x:1305.55,y:17.3},0).wait(1).to({x:1296.75,y:17.65},0).wait(1).to({x:1287.95,y:18.05},0).wait(1).to({x:1279.15,y:18.4},0).wait(1).to({x:1270.35,y:18.8},0).wait(1).to({x:1261.55,y:19.15},0).wait(1).to({x:1252.75,y:19.55},0).wait(1).to({x:1243.95,y:19.9},0).wait(1).to({x:1235.15,y:20.3},0).wait(1).to({x:1226.35,y:20.65},0).wait(1).to({x:1217.55,y:21.05},0).wait(1).to({x:1208.75,y:21.4},0).wait(1).to({x:1199.95,y:21.8},0).wait(1).to({x:1191.15,y:22.2},0).wait(1).to({x:1182.35,y:22.55},0).wait(1).to({x:1173.55,y:22.95},0).wait(1).to({x:1164.7,y:23.3},0).wait(1).to({x:1155.9,y:23.7},0).wait(1).to({x:1147.1,y:24.05},0).wait(1).to({x:1138.3,y:24.45},0).wait(1).to({x:1129.5,y:24.8},0).wait(1).to({x:1120.7,y:25.2},0).wait(1).to({x:1111.9,y:25.55},0).wait(1).to({x:1103.1,y:25.95},0).wait(1).to({x:1094.3,y:26.3},0).wait(1).to({x:1085.5,y:26.7},0).wait(1).to({x:1076.7,y:27.05},0).wait(1).to({x:1067.9,y:27.45},0).wait(1).to({x:1059.1,y:27.8},0).wait(1).to({x:1050.3,y:28.2},0).wait(1).to({x:1041.5,y:28.55},0).wait(1).to({x:1032.7,y:28.95},0).wait(1).to({x:1023.9,y:29.3},0).wait(1).to({x:1015.1,y:29.7},0).wait(1).to({x:1006.3,y:30.1},0).wait(1).to({x:997.5,y:30.45},0).wait(1).to({x:988.7,y:30.85},0).wait(1).to({x:979.85,y:31.2},0).wait(1).to({x:971.05,y:31.6},0).wait(1).to({x:962.3,y:31.95},0).wait(1).to({x:953.45,y:32.35},0).wait(1).to({x:944.65,y:32.7},0).wait(1).to({x:935.85,y:33.1},0).wait(1).to({x:927.05,y:33.45},0).wait(1).to({x:918.25,y:33.85},0).wait(1).to({x:909.45,y:34.2},0).wait(1).to({x:900.65,y:34.6},0).wait(1).to({x:891.85,y:34.95},0).wait(1).to({x:883.05,y:35.35},0).wait(1).to({x:874.25,y:35.7},0).wait(1).to({x:865.45,y:36.1},0).wait(1).to({x:856.65,y:36.45},0).wait(1).to({x:847.85,y:36.85},0).wait(1).to({x:839.05,y:37.25},0).wait(1).to({x:830.25,y:37.6},0).wait(1).to({x:821.45,y:38},0).wait(1).to({x:812.65,y:38.35},0).wait(1).to({x:803.85,y:38.75},0).wait(1).to({x:795,y:39.1},0).wait(1).to({x:786.2,y:39.5},0).wait(1).to({x:777.4,y:39.85},0).wait(1).to({x:768.6,y:40.25},0).wait(1).to({x:759.8,y:40.6},0).wait(1).to({x:751,y:41},0).wait(1).to({x:742.2,y:41.35},0).wait(1).to({x:733.4,y:41.75},0).wait(1).to({x:724.6,y:42.1},0).wait(1).to({x:715.8,y:42.5},0).wait(1).to({x:707,y:42.85},0).wait(1).to({x:698.2,y:43.25},0).wait(1).to({x:689.4,y:43.6},0).wait(1).to({x:680.6,y:44},0).wait(1).to({x:671.8,y:44.4},0).wait(1).to({x:663,y:44.75},0).wait(1).to({x:654.2,y:45.15},0).wait(1).to({x:645.4,y:45.5},0).wait(1).to({x:636.6,y:45.9},0).wait(1).to({x:627.8,y:46.25},0).wait(1).to({x:619,y:46.65},0).wait(1).to({x:610.15,y:47},0).wait(1).to({x:601.35,y:47.4},0).wait(1).to({x:592.55,y:47.75},0).wait(1).to({x:583.75,y:48.15},0).wait(1).to({x:574.95,y:48.5},0).wait(1).to({x:566.15,y:48.9},0).wait(1).to({x:557.35,y:49.25},0).wait(1).to({x:548.55,y:49.65},0).wait(1).to({x:539.75,y:50},0).wait(1).to({x:530.95,y:50.4},0).wait(1).to({x:522.15,y:50.75},0).wait(1).to({x:513.35,y:51.15},0).wait(1).to({x:504.55,y:51.55},0).wait(1).to({x:495.75,y:51.9},0).wait(1).to({x:486.95,y:52.3},0).wait(1).to({x:478.15,y:52.65},0).wait(1).to({x:469.35,y:53.05},0).wait(1).to({x:460.55,y:53.4},0).wait(1).to({x:451.75,y:53.8},0).wait(1).to({x:442.95,y:54.15},0).wait(1).to({x:434.15,y:54.55},0).wait(1).to({x:425.35,y:54.9},0).wait(1).to({x:416.5,y:55.3},0).wait(1).to({x:407.7,y:55.65},0).wait(1).to({x:398.9,y:56.05},0).wait(1).to({x:390.1,y:56.4},0).wait(1).to({x:381.3,y:56.8},0).wait(1).to({x:372.5,y:57.15},0).wait(1).to({x:363.7,y:57.55},0).wait(1).to({x:354.9,y:57.9},0).wait(1).to({x:346.1,y:58.3},0).wait(1).to({x:337.3,y:58.65},0).wait(1).to({x:328.5,y:59.05},0).wait(1).to({x:319.7,y:59.45},0).wait(1).to({x:310.9,y:59.8},0).wait(1).to({x:302.1,y:60.2},0).wait(1).to({x:293.3,y:60.55},0).wait(1).to({x:284.5,y:60.95},0).wait(1).to({x:275.7,y:61.3},0).wait(1).to({x:266.9,y:61.7},0).wait(1).to({x:258.1,y:62.05},0).wait(1).to({x:249.3,y:62.45},0).wait(1).to({x:240.45,y:62.8},0).wait(1).to({x:231.65,y:63.2},0).wait(1).to({x:222.85,y:63.55},0).wait(1).to({x:214.05,y:63.95},0).wait(1).to({x:205.25,y:64.3},0).wait(1).to({x:196.45,y:64.7},0).wait(1).to({x:187.65,y:65.05},0).wait(1).to({x:178.85,y:65.45},0).wait(1).to({x:170.05,y:65.8},0).wait(1).to({x:161.25,y:66.2},0).wait(1).to({x:152.45,y:66.6},0).wait(1).to({x:143.65,y:66.95},0).wait(1).to({x:134.85,y:67.35},0).wait(1).to({x:126.05,y:67.7},0).wait(1).to({x:117.25,y:68.1},0).wait(1).to({x:108.45,y:68.45},0).wait(1).to({x:99.65,y:68.85},0).wait(1).to({x:90.85,y:69.2},0).wait(1).to({x:82.05,y:69.6},0).wait(1).to({x:73.25,y:69.95},0).wait(1).to({x:64.45,y:70.35},0).wait(1).to({x:55.6,y:70.7},0).wait(1).to({x:46.8,y:71.1},0).wait(1).to({x:38,y:71.45},0).wait(1).to({x:29.2,y:71.85},0).wait(1).to({x:20.4,y:72.2},0).wait(1).to({x:11.6,y:72.6},0).wait(1).to({x:2.8,y:72.95},0).wait(1).to({x:-6,y:73.35},0).wait(1).to({x:-14.8,y:73.75},0).wait(1).to({x:-23.6,y:74.1},0).wait(1).to({x:-32.4,y:74.5},0).wait(1).to({x:-41.2,y:74.85},0).wait(1).to({x:-50,y:75.25},0).wait(1).to({x:-58.8,y:75.6},0).wait(1).to({x:-67.6,y:76},0).wait(1).to({x:-76.4,y:76.35},0).wait(1).to({x:-85.2,y:76.75},0).wait(1).to({x:-93.95,y:77.1},0).wait(1).to({x:-102.75,y:77.5},0).wait(1).to({x:-111.55,y:77.85},0).wait(1).to({x:-120.35,y:78.25},0).wait(1).to({x:-129.15,y:78.6},0).wait(1).to({x:-138,y:79},0).wait(1).to({x:-146.8,y:79.35},0).wait(1).to({x:-155.6,y:79.75},0).wait(1).to({x:-164.4,y:80.1},0).wait(1).to({x:-173.2,y:80.5},0).wait(1).to({x:-182,y:80.9},0).wait(1).to({x:-190.8,y:81.25},0).wait(1).to({x:-199.6,y:81.65},0).wait(1).to({x:-208.4,y:82},0).wait(1).to({x:-217.2,y:82.4},0).wait(1).to({x:-226,y:82.75},0).wait(1).to({x:-234.8,y:83.15},0).wait(1).to({x:-243.6,y:83.5},0).wait(1).to({x:-252.4,y:83.9},0).wait(1).to({x:-261.2,y:84.25},0).wait(1).to({x:-270,y:84.65},0).wait(1).to({x:-278.8,y:85},0).wait(1).to({x:-291.95,y:148.6},0).to({_off:true},1).wait(21));

	// CloudsFore
	this.cloudsfore = new lib.CloudsFore();
	this.cloudsfore.name = "cloudsfore";
	this.cloudsfore.parent = this;
	this.cloudsfore.setTransform(-283.95,57.5,1,1,0,0,0,418,118.5);
	this.cloudsfore.cache(-2,-2,732,241);

	this.timeline.addTween(cjs.Tween.get(this.cloudsfore).wait(1).to({regX:364,x:-330.05},0).wait(1).to({x:-322.2},0).wait(1).to({x:-314.35},0).wait(1).to({x:-306.5},0).wait(1).to({x:-298.65},0).wait(1).to({x:-290.8},0).wait(1).to({x:-282.95},0).wait(1).to({x:-275.1},0).wait(1).to({x:-267.25},0).wait(1).to({x:-259.35},0).wait(1).to({x:-251.5},0).wait(1).to({x:-243.65},0).wait(1).to({x:-235.8},0).wait(1).to({x:-227.95},0).wait(1).to({x:-220.1},0).wait(1).to({x:-212.25},0).wait(1).to({x:-204.4},0).wait(1).to({x:-196.55},0).wait(1).to({x:-188.7},0).wait(1).to({x:-180.8},0).wait(1).to({x:-172.95},0).wait(1).to({x:-165.1},0).wait(1).to({x:-157.25},0).wait(1).to({x:-149.4},0).wait(1).to({x:-141.55},0).wait(1).to({x:-133.7},0).wait(1).to({x:-125.85},0).wait(1).to({x:-118},0).wait(1).to({x:-110.1},0).wait(1).to({x:-102.25},0).wait(1).to({x:-94.4},0).wait(1).to({x:-86.55},0).wait(1).to({x:-78.7},0).wait(1).to({x:-70.85},0).wait(1).to({x:-63},0).wait(1).to({x:-55.15},0).wait(1).to({x:-47.25},0).wait(1).to({x:-39.4},0).wait(1).to({x:-31.55},0).wait(1).to({x:-23.7},0).wait(1).to({x:-15.85},0).wait(1).to({x:-8},0).wait(1).to({x:-0.15},0).wait(1).to({x:7.7},0).wait(1).to({x:15.55},0).wait(1).to({x:23.45},0).wait(1).to({x:31.3},0).wait(1).to({x:39.15},0).wait(1).to({x:47},0).wait(1).to({x:54.85},0).wait(1).to({x:62.7},0).wait(1).to({x:70.55},0).wait(1).to({x:78.4},0).wait(1).to({x:86.25},0).wait(1).to({x:94.15},0).wait(1).to({x:102},0).wait(1).to({x:109.85},0).wait(1).to({x:117.7},0).wait(1).to({x:125.55},0).wait(1).to({x:133.4},0).wait(1).to({x:141.25},0).wait(1).to({x:149.1},0).wait(1).to({x:156.95},0).wait(1).to({x:164.85},0).wait(1).to({x:172.7},0).wait(1).to({x:180.55},0).wait(1).to({x:188.4},0).wait(1).to({x:196.25},0).wait(1).to({x:204.1},0).wait(1).to({x:211.95},0).wait(1).to({x:219.8},0).wait(1).to({x:227.65},0).wait(1).to({x:235.5},0).wait(1).to({x:243.4},0).wait(1).to({x:251.25},0).wait(1).to({x:259.1},0).wait(1).to({x:266.95},0).wait(1).to({x:274.8},0).wait(1).to({x:282.65},0).wait(1).to({x:290.5},0).wait(1).to({x:298.35},0).wait(1).to({x:306.25},0).wait(1).to({x:314.1},0).wait(1).to({x:321.95},0).wait(1).to({x:329.8},0).wait(1).to({x:337.65},0).wait(1).to({x:345.5},0).wait(1).to({x:353.35},0).wait(1).to({x:361.2},0).wait(1).to({x:369},0).wait(1).to({x:376.9},0).wait(1).to({x:384.75},0).wait(1).to({x:392.6},0).wait(1).to({x:400.45},0).wait(1).to({x:408.3},0).wait(1).to({x:416.15},0).wait(1).to({x:424},0).wait(1).to({x:431.85},0).wait(1).to({x:439.7},0).wait(1).to({x:447.55},0).wait(1).to({x:455.45},0).wait(1).to({x:463.3},0).wait(1).to({x:471.15},0).wait(1).to({x:479},0).wait(1).to({x:486.85},0).wait(1).to({x:494.7},0).wait(1).to({x:502.55},0).wait(1).to({x:510.4},0).wait(1).to({x:518.3},0).wait(1).to({x:526.15},0).wait(1).to({x:534},0).wait(1).to({x:541.85},0).wait(1).to({x:549.7},0).wait(1).to({x:557.55},0).wait(1).to({x:565.4},0).wait(1).to({x:573.25},0).wait(1).to({x:581.1},0).wait(1).to({x:588.95},0).wait(1).to({x:596.85},0).wait(1).to({x:604.7},0).wait(1).to({x:612.55},0).wait(1).to({x:620.4},0).wait(1).to({x:628.25},0).wait(1).to({x:636.1},0).wait(1).to({x:643.95},0).wait(1).to({x:651.8},0).wait(1).to({x:659.7},0).wait(1).to({x:667.55},0).wait(1).to({x:675.4},0).wait(1).to({x:683.25},0).wait(1).to({x:691.1},0).wait(1).to({x:698.95},0).wait(1).to({x:706.8},0).wait(1).to({x:714.65},0).wait(1).to({x:722.5},0).wait(1).to({x:730.4},0).wait(1).to({x:738.25},0).wait(1).to({x:746.1},0).wait(1).to({x:753.95},0).wait(1).to({x:761.8},0).wait(1).to({x:769.65},0).wait(1).to({x:777.5},0).wait(1).to({x:785.35},0).wait(1).to({x:793.2},0).wait(1).to({x:801.1},0).wait(1).to({x:808.9},0).wait(1).to({x:816.8},0).wait(1).to({x:824.65},0).wait(1).to({x:832.5},0).wait(1).to({x:840.35},0).wait(1).to({x:848.2},0).wait(1).to({x:856.05},0).wait(1).to({x:863.9},0).wait(1).to({x:871.8},0).wait(1).to({x:879.65},0).wait(1).to({x:887.5},0).wait(1).to({x:895.35},0).wait(1).to({x:903.2},0).wait(1).to({x:911.05},0).wait(1).to({x:918.9},0).wait(1).to({x:926.75},0).wait(1).to({x:934.6},0).wait(1).to({x:942.5},0).wait(1).to({x:950.35},0).wait(1).to({x:958.2},0).wait(1).to({x:966.05},0).wait(1).to({x:973.9},0).wait(1).to({x:981.75},0).wait(1).to({x:989.6},0).wait(1).to({x:997.45},0).wait(1).to({x:1005.3},0).wait(1).to({x:1013.2},0).wait(1).to({x:1021.05},0).wait(1).to({x:1028.9},0).wait(1).to({x:1036.75},0).wait(1).to({x:1044.6},0).wait(1).to({x:1052.45},0).wait(1).to({x:1060.3},0).wait(1).to({x:1068.15},0).wait(1).to({x:1076},0).wait(1).to({x:1083.9},0).wait(1).to({x:1091.75},0).wait(1).to({x:1099.6},0).wait(1).to({x:1107.45},0).wait(1).to({x:1115.3},0).wait(1).to({x:1123.15},0).wait(1).to({x:1131},0).wait(1).to({x:1138.85},0).wait(1).to({x:1146.7},0).wait(1).to({x:1154.6},0).wait(1).to({x:1162.4},0).wait(1).to({x:1170.3},0).wait(1).to({x:1178.15},0).wait(1).to({x:1186},0).wait(1).to({x:1193.85},0).wait(1).to({x:1201.7},0).wait(1).to({x:1209.55},0).wait(1).to({x:1217.4},0).wait(1).to({x:1225.3},0).wait(1).to({x:1233.1},0).wait(1).to({x:1241},0).wait(1).to({x:1248.85},0).wait(1).to({x:1256.7},0).wait(1).to({x:1264.55},0).wait(1).to({x:1272.4},0).wait(1).to({x:1280.25},0).wait(1).to({x:1288.1},0).wait(1).to({x:1296},0).to({_off:true},1).wait(21));

	// Background
	this.ground = new lib.Ground();
	this.ground.name = "ground";
	this.ground.parent = this;
	this.ground.setTransform(480,505.05,1,1,0,0,0,0,-55.2);

	this.city = new lib.City();
	this.city.name = "city";
	this.city.parent = this;
	this.city.setTransform(480,245,1,1,0,0,0,480,245);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.city},{t:this.ground}]}).to({state:[{t:this.city},{t:this.ground}]},67).to({state:[{t:this.city},{t:this.ground}]},162).wait(1));

	// ZapposBezosFlyDown
	this.instance_1 = new lib.ZapposBezos();
	this.instance_1.parent = this;
	this.instance_1.setTransform(235,-78.1,0.255,0.2549,0,0,0,256.6,221.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:257.1,regY:312.5,x:239.85,y:-52.4},0).wait(1).to({x:244.6,y:-50},0).wait(1).to({x:249.35,y:-47.55},0).wait(1).to({x:254,y:-45},0).wait(1).to({x:258.7,y:-42.45},0).wait(1).to({x:263.35,y:-39.8},0).wait(1).to({x:267.95,y:-37.1},0).wait(1).to({x:272.5,y:-34.4},0).wait(1).to({x:277.05,y:-31.6},0).wait(1).to({x:281.55,y:-28.7},0).wait(1).to({x:286,y:-25.8},0).wait(1).to({x:290.4,y:-22.8},0).wait(1).to({x:294.8,y:-19.8},0).wait(1).to({x:299.15,y:-16.65},0).wait(1).to({x:303.4,y:-13.5},0).wait(1).to({x:307.65,y:-10.25},0).wait(1).to({x:311.85,y:-6.95},0).wait(1).to({x:316,y:-3.6},0).wait(1).to({x:320.05,y:-0.2},0).wait(1).to({x:324.1,y:3.3},0).wait(1).to({x:328.05,y:6.85},0).wait(1).to({x:331.95,y:10.5},0).wait(1).to({x:335.8,y:14.2},0).wait(1).to({x:339.55,y:17.95},0).wait(1).to({x:343.25,y:21.8},0).wait(1).to({x:346.9,y:25.7},0).wait(1).to({x:350.45,y:29.7},0).wait(1).to({x:353.9,y:33.75},0).wait(1).to({x:357.25,y:37.9},0).wait(1).to({x:360.55,y:42.05},0).wait(1).to({x:363.75,y:46.35},0).wait(1).to({x:366.85,y:50.7},0).wait(1).to({x:369.85,y:55.1},0).wait(1).to({x:372.75,y:59.55},0).wait(1).to({x:375.55,y:64.1},0).wait(1).to({x:378.2,y:68.7},0).wait(1).to({x:380.75,y:73.4},0).wait(1).to({x:383.2,y:78.15},0).wait(1).to({x:385.5,y:82.9},0).wait(1).to({x:387.7,y:87.75},0).wait(1).to({x:389.75,y:92.65},0).wait(1).to({x:391.65,y:97.65},0).wait(1).to({x:393.4,y:102.65},0).wait(1).to({x:395.05,y:107.75},0).wait(1).to({x:396.5,y:112.9},0).wait(1).to({x:397.85,y:118.05},0).wait(1).to({x:399,y:123.25},0).wait(1).to({x:400,y:128.45},0).wait(1).to({x:400.85,y:133.75},0).wait(1).to({x:401.55,y:139},0).wait(1).to({x:402.05,y:144.35},0).wait(1).to({x:402.45,y:149.65},0).wait(1).to({x:402.6,y:154.95},0).wait(1).to({x:402.85,y:158.35},0).wait(1).to({x:403,y:161.7},0).wait(1).to({x:403.1,y:165.1},0).wait(1).to({x:403.2,y:168.45},0).wait(1).to({x:403.25,y:171.8},0).wait(1).to({x:403.2,y:175.2},0).wait(1).to({x:403.15,y:178.55},0).wait(1).to({x:403,y:181.95},0).wait(1).to({x:402.8,y:185.3},0).wait(1).to({x:402.55,y:188.65},0).wait(1).to({x:402.25,y:192},0).wait(1).to({x:401.85,y:195.35},0).wait(1).to({x:401.35,y:198.7},0).wait(1).to({x:400.8,y:202},0).wait(1).to({x:400.2,y:205.3},0).wait(1).to({x:399.45,y:208.6},0).wait(1).to({x:398.65,y:211.9},0).wait(1).to({x:397.75,y:215.15},0).wait(1).to({x:396.7,y:218.35},0).wait(1).to({x:395.6,y:221.5},0).wait(1).to({x:394.35,y:224.65},0).wait(1).to({x:392.95,y:227.75},0).wait(1).to({x:391.5,y:230.75},0).wait(1).to({x:389.85,y:233.7},0).wait(1).to({x:388.1,y:236.55},0).wait(1).to({x:386.2,y:239.35},0).wait(1).to({x:384.15,y:242.05},0).wait(1).to({x:382,y:244.6},0).wait(1).to({x:379.65,y:247.1},0).wait(1).to({x:377.25,y:249.4},0).wait(1).to({x:374.7,y:251.6},0).wait(1).to({x:372,y:253.65},0).wait(1).to({x:369.2,y:255.55},0).wait(1).to({x:366.35,y:257.3},0).wait(1).to({x:363.35,y:258.9},0).wait(1).to({x:360.3,y:260.35},0).wait(1).to({x:357.2,y:261.65},0).wait(1).to({x:354.05,y:262.8},0).wait(1).to({x:350.85,y:263.8},0).wait(1).to({x:347.6,y:264.65},0).wait(1).to({x:344.3,y:265.4},0).wait(1).to({x:341,y:266.05},0).wait(1).to({x:337.65,y:266.55},0).wait(1).to({x:334.3,y:266.95},0).wait(1).to({x:330.95,y:267.25},0).wait(1).to({x:327.6,y:267.45},0).wait(1).to({x:324.2,y:267.6},0).wait(1).to({x:320.85},0).wait(1).to({x:317.45,y:267.55},0).wait(1).to({x:314.1,y:267.45},0).wait(1).to({x:310.75,y:267.25},0).wait(1).to({x:307.4,y:266.95},0).wait(1).to({x:304.05,y:266.65},0).wait(1).to({x:300.7,y:266.25},0).wait(1).to({x:297.35,y:265.8},0).wait(1).to({x:294,y:265.3},0).wait(1).to({x:290.7,y:264.75},0).wait(1).to({x:287.35,y:264.2},0).wait(1).to({x:284.05,y:263.55},0).wait(1).to({x:280.75,y:262.85},0).wait(1).to({x:277.45,y:262.15},0).wait(1).to({x:274.2,y:261.35},0).wait(1).to({x:270.9,y:260.6},0).wait(1).to({x:267.65,y:259.75},0).wait(1).to({x:264.35,y:258.85},0).wait(1).to({x:260.65,y:257.9},0).wait(1).to({x:256.9,y:256.95},0).wait(1).to({x:253.2,y:256.05},0).wait(1).to({x:249.45,y:255.15},0).wait(1).to({x:245.7,y:254.35},0).wait(1).to({x:241.95,y:253.6},0).wait(1).to({x:238.15,y:252.85},0).wait(1).to({x:234.4,y:252.2},0).wait(1).to({x:230.6,y:251.6},0).wait(1).to({x:226.75,y:251.1},0).wait(1).to({x:222.95,y:250.65},0).wait(1).to({x:219.1,y:250.35},0).wait(1).to({x:215.3,y:250.1},0).wait(1).to({x:211.45,y:249.95},0).wait(1).to({x:207.6,y:250},0).wait(1).to({x:203.75,y:250.15},0).wait(1).to({x:199.95,y:250.5},0).wait(1).to({x:196.15,y:251.05},0).wait(1).to({x:192.4,y:251.85},0).wait(1).to({x:188.7,y:252.95},0).wait(1).to({x:185.15,y:254.45},0).wait(1).to({x:181.8,y:256.25},0).wait(1).to({x:178.7,y:258.55},0).wait(1).to({x:176,y:261.25},0).wait(1).to({x:173.75,y:264.4},0).wait(1).to({x:172.05,y:267.8},0).wait(1).to({x:170.85,y:271.45},0).wait(1).to({x:170.1,y:275.25},0).wait(1).to({x:169.75,y:279.05},0).wait(1).to({y:282.9},0).wait(1).to({x:170.05,y:286.7},0).wait(1).to({x:170.55,y:290.55},0).wait(1).to({x:171.25,y:294.3},0).wait(1).to({x:172.1,y:298.05},0).wait(1).to({x:173.15,y:301.75},0).wait(1).to({x:174.25,y:305.45},0).wait(1).to({x:175.5,y:309.05},0).wait(1).to({x:176.85,y:312.65},0).wait(1).to({x:178.25,y:316.25},0).wait(1).to({x:179.7,y:319.8},0).wait(1).to({x:181.25,y:323.3},0).wait(1).to({x:182.9,y:326.8},0).wait(1).to({x:184.55,y:330.25},0).wait(1).to({x:186.25,y:333.7},0).wait(1).to({x:188,y:337.1},0).wait(1).to({x:189.8,y:340.5},0).wait(1).to({x:191.65,y:343.9},0).wait(1).to({x:193.5,y:347.25},0).wait(1).to({x:195.4,y:350.55},0).wait(1).to({x:197.35,y:353.9},0).wait(1).to({x:199.3,y:357.2},0).wait(1).to({x:201.25,y:360.5},0).wait(1).to({x:203.3,y:363.8},0).wait(1).to({x:205.3,y:367.05},0).wait(1).to({x:207.35,y:370.3},0).wait(1).to({x:209.45,y:373.55},0).wait(1).to({x:211.5,y:376.75},0).wait(1).to({x:213.6,y:379.95},0).wait(1).to({x:217.6,y:382.8},0).wait(1).to({x:221.65,y:385.6},0).wait(1).to({x:225.7,y:388.35},0).wait(1).to({x:229.8,y:391.1},0).wait(1).to({x:233.95,y:393.75},0).wait(1).to({x:238.1,y:396.35},0).wait(1).to({x:242.25,y:398.95},0).wait(1).to({x:246.45,y:401.5},0).wait(1).to({x:250.7,y:404},0).wait(1).to({x:254.95,y:406.45},0).wait(1).to({x:259.2,y:408.9},0).wait(1).to({x:263.5,y:411.3},0).wait(1).to({x:267.8,y:413.65},0).wait(1).to({x:272.1,y:415.95},0).wait(1).to({x:276.45,y:418.25},0).wait(1).to({x:280.8,y:420.5},0).wait(1).to({x:285.15,y:422.75},0).wait(1).to({x:289.55,y:424.95},0).wait(1).to({x:293.95,y:427.15},0).wait(1).to({x:298.35,y:429.3},0).wait(1).to({x:302.8,y:431.4},0).wait(1).to({x:307.25,y:433.5},0).wait(1).to({x:311.7,y:435.55},0).wait(1).to({x:316.15,y:437.6},0).wait(1).to({x:320.65,y:439.6},0).wait(1).to({x:325.1,y:441.6},0).wait(1).to({x:329.6,y:443.55},0).to({_off:true},1).wait(26));

	// CloudBack
	this.cloudsback = new lib.CloudsBack();
	this.cloudsback.name = "cloudsback";
	this.cloudsback.parent = this;
	this.cloudsback.setTransform(1287.95,126.5,1,1,0,0,0,356,117.5);
	this.cloudsback.cache(-2,-2,716,239);

	this.timeline.addTween(cjs.Tween.get(this.cloudsback).wait(1).to({x:1280.25,y:126.6},0).wait(1).to({x:1272.6,y:126.7},0).wait(1).to({x:1264.95,y:126.8},0).wait(1).to({x:1257.25,y:126.9},0).wait(1).to({x:1249.6,y:127.05},0).wait(1).to({x:1241.95,y:127.15},0).wait(1).to({x:1234.25,y:127.25},0).wait(1).to({x:1226.6,y:127.35},0).wait(1).to({x:1218.95,y:127.45},0).wait(1).to({x:1211.3,y:127.6},0).wait(1).to({x:1203.6,y:127.7},0).wait(1).to({x:1195.95,y:127.8},0).wait(1).to({x:1188.3,y:127.9},0).wait(1).to({x:1180.6,y:128},0).wait(1).to({x:1172.95,y:128.15},0).wait(1).to({x:1165.3,y:128.25},0).wait(1).to({x:1157.6,y:128.35},0).wait(1).to({x:1149.95,y:128.45},0).wait(1).to({x:1142.3,y:128.55},0).wait(1).to({x:1134.65,y:128.7},0).wait(1).to({x:1126.95,y:128.8},0).wait(1).to({x:1119.3,y:128.9},0).wait(1).to({x:1111.65,y:129},0).wait(1).to({x:1103.95,y:129.1},0).wait(1).to({x:1096.3,y:129.25},0).wait(1).to({x:1088.65,y:129.35},0).wait(1).to({x:1080.95,y:129.45},0).wait(1).to({x:1073.3,y:129.55},0).wait(1).to({x:1065.65,y:129.65},0).wait(1).to({x:1058,y:129.8},0).wait(1).to({x:1050.3,y:129.9},0).wait(1).to({x:1042.65,y:130},0).wait(1).to({x:1035,y:130.1},0).wait(1).to({x:1027.3,y:130.2},0).wait(1).to({x:1019.65,y:130.35},0).wait(1).to({x:1012,y:130.45},0).wait(1).to({x:1004.35,y:130.55},0).wait(1).to({x:996.65,y:130.65},0).wait(1).to({x:989,y:130.75},0).wait(1).to({x:981.35,y:130.9},0).wait(1).to({x:973.65,y:131},0).wait(1).to({x:966,y:131.1},0).wait(1).to({x:958.35,y:131.2},0).wait(1).to({x:950.65,y:131.3},0).wait(1).to({x:943,y:131.45},0).wait(1).to({x:935.35,y:131.55},0).wait(1).to({x:927.7,y:131.65},0).wait(1).to({x:920,y:131.75},0).wait(1).to({x:912.35,y:131.85},0).wait(1).to({x:904.7,y:132},0).wait(1).to({x:897,y:132.1},0).wait(1).to({x:889.35,y:132.2},0).wait(1).to({x:881.7,y:132.3},0).wait(1).to({x:874,y:132.4},0).wait(1).to({x:866.35,y:132.55},0).wait(1).to({x:858.7,y:132.65},0).wait(1).to({x:851.05,y:132.75},0).wait(1).to({x:843.35,y:132.85},0).wait(1).to({x:835.7,y:132.95},0).wait(1).to({x:828.05,y:133.1},0).wait(1).to({x:820.35,y:133.2},0).wait(1).to({x:812.7,y:133.3},0).wait(1).to({x:805.05,y:133.4},0).wait(1).to({x:797.4,y:133.5},0).wait(1).to({x:789.7,y:133.65},0).wait(1).to({x:782.05,y:133.75},0).wait(1).to({x:774.4,y:133.85},0).wait(1).to({x:766.7,y:133.95},0).wait(1).to({x:759.05,y:134.05},0).wait(1).to({x:751.4,y:134.2},0).wait(1).to({x:743.7,y:134.3},0).wait(1).to({x:736.05,y:134.4},0).wait(1).to({x:728.4,y:134.5},0).wait(1).to({x:720.75,y:134.6},0).wait(1).to({x:713.05,y:134.75},0).wait(1).to({x:705.4,y:134.85},0).wait(1).to({x:697.75,y:134.95},0).wait(1).to({x:690.05,y:135.05},0).wait(1).to({x:682.4,y:135.15},0).wait(1).to({x:674.75,y:135.3},0).wait(1).to({x:667.05,y:135.4},0).wait(1).to({x:659.4,y:135.5},0).wait(1).to({x:651.75,y:135.6},0).wait(1).to({x:644.1,y:135.7},0).wait(1).to({x:636.4,y:135.85},0).wait(1).to({x:628.75,y:135.95},0).wait(1).to({x:621.1,y:136.05},0).wait(1).to({x:613.4,y:136.15},0).wait(1).to({x:605.75,y:136.25},0).wait(1).to({x:598.1,y:136.4},0).wait(1).to({x:590.45,y:136.5},0).wait(1).to({x:582.75,y:136.6},0).wait(1).to({x:575.1,y:136.7},0).wait(1).to({x:567.45,y:136.8},0).wait(1).to({x:559.75,y:136.95},0).wait(1).to({x:552.1,y:137.05},0).wait(1).to({x:544.45,y:137.15},0).wait(1).to({x:536.75,y:137.25},0).wait(1).to({x:529.1,y:137.35},0).wait(1).to({x:521.45,y:137.5},0).wait(1).to({x:513.8,y:137.6},0).wait(1).to({x:506.1,y:137.7},0).wait(1).to({x:498.45,y:137.8},0).wait(1).to({x:490.8,y:137.9},0).wait(1).to({x:483.1,y:138.05},0).wait(1).to({x:475.45,y:138.15},0).wait(1).to({x:467.8,y:138.25},0).wait(1).to({x:460.1,y:138.35},0).wait(1).to({x:452.45,y:138.45},0).wait(1).to({x:444.8,y:138.6},0).wait(1).to({x:437.15,y:138.7},0).wait(1).to({x:429.45,y:138.8},0).wait(1).to({x:421.8,y:138.9},0).wait(1).to({x:414.15,y:139},0).wait(1).to({x:406.45,y:139.15},0).wait(1).to({x:398.8,y:139.25},0).wait(1).to({x:391.15,y:139.35},0).wait(1).to({x:383.45,y:139.45},0).wait(1).to({x:375.8,y:139.55},0).wait(1).to({x:368.15,y:139.7},0).wait(1).to({x:360.5,y:139.8},0).wait(1).to({x:352.85,y:139.9},0).wait(1).to({x:345.2,y:140},0).wait(1).to({x:337.55,y:140.1},0).wait(1).to({x:329.85,y:140.25},0).wait(1).to({x:322.2,y:140.35},0).wait(1).to({x:314.55,y:140.45},0).wait(1).to({x:306.9,y:140.55},0).wait(1).to({x:299.2,y:140.65},0).wait(1).to({x:291.55,y:140.8},0).wait(1).to({x:283.9,y:140.9},0).wait(1).to({x:276.2,y:141},0).wait(1).to({x:268.55,y:141.1},0).wait(1).to({x:260.9,y:141.2},0).wait(1).to({x:253.2,y:141.35},0).wait(1).to({x:245.55,y:141.45},0).wait(1).to({x:237.9,y:141.55},0).wait(1).to({x:230.25,y:141.65},0).wait(1).to({x:222.55,y:141.75},0).wait(1).to({x:214.9,y:141.9},0).wait(1).to({x:207.25,y:142},0).wait(1).to({x:199.55,y:142.1},0).wait(1).to({x:191.9,y:142.2},0).wait(1).to({x:184.25,y:142.3},0).wait(1).to({x:176.55,y:142.45},0).wait(1).to({x:168.9,y:142.55},0).wait(1).to({x:161.25,y:142.65},0).wait(1).to({x:153.6,y:142.75},0).wait(1).to({x:145.9,y:142.85},0).wait(1).to({x:138.25,y:143},0).wait(1).to({x:130.6,y:143.1},0).wait(1).to({x:122.9,y:143.2},0).wait(1).to({x:115.25,y:143.3},0).wait(1).to({x:107.6,y:143.4},0).wait(1).to({x:99.95,y:143.55},0).wait(1).to({x:92.25,y:143.65},0).wait(1).to({x:84.6,y:143.75},0).wait(1).to({x:76.95,y:143.85},0).wait(1).to({x:69.25,y:143.95},0).wait(1).to({x:61.6,y:144.1},0).wait(1).to({x:53.95,y:144.2},0).wait(1).to({x:46.25,y:144.3},0).wait(1).to({x:38.6,y:144.4},0).wait(1).to({x:30.95,y:144.5},0).wait(1).to({x:23.3,y:144.65},0).wait(1).to({x:15.6,y:144.75},0).wait(1).to({x:7.95,y:144.85},0).wait(1).to({x:0.3,y:144.95},0).wait(1).to({x:-7.4,y:145.05},0).wait(1).to({x:-15.05,y:145.2},0).wait(1).to({x:-22.7,y:145.3},0).wait(1).to({x:-30.4,y:145.4},0).wait(1).to({x:-38.05,y:145.5},0).wait(1).to({x:-45.7,y:145.6},0).wait(1).to({x:-53.35,y:145.75},0).wait(1).to({x:-61.05,y:145.85},0).wait(1).to({x:-68.7,y:145.95},0).wait(1).to({x:-76.35,y:146.05},0).wait(1).to({x:-84.05,y:146.15},0).wait(1).to({x:-91.7,y:146.3},0).wait(1).to({x:-99.35,y:146.4},0).wait(1).to({x:-107,y:146.5},0).wait(1).to({x:-114.7,y:146.6},0).wait(1).to({x:-122.35,y:146.7},0).wait(1).to({x:-130,y:146.85},0).wait(1).to({x:-137.7,y:146.95},0).wait(1).to({x:-145.35,y:147.05},0).wait(1).to({x:-153,y:147.15},0).wait(1).to({x:-160.7,y:147.25},0).wait(1).to({x:-168.35,y:147.4},0).wait(1).to({x:-176,y:147.5},0).wait(1).to({x:-183.65,y:147.6},0).wait(1).to({x:-191.35,y:147.7},0).wait(1).to({x:-199,y:147.8},0).wait(1).to({x:-206.65,y:147.95},0).wait(1).to({x:-214.35,y:148.05},0).wait(1).to({x:-222,y:148.15},0).wait(1).to({x:-229.65,y:148.25},0).wait(1).to({x:-237.35,y:148.35},0).wait(1).to({x:-245,y:148.5},0).wait(1).to({x:-252.65,y:148.6},0).wait(1).to({x:-260.3,y:148.7},0).wait(1).to({x:-268,y:148.8},0).wait(1).to({x:-275.65,y:148.9},0).wait(1).to({x:-283.3,y:149.05},0).wait(1).to({x:-291,y:149.15},0).wait(1).to({x:-298.65,y:149.25},0).wait(1).to({x:-306.3,y:149.35},0).wait(1).to({x:-314,y:149.5},0).to({_off:true},1).wait(20));

	// LogosBack
	this.logosback = new lib.Blimp();
	this.logosback.name = "logosback";
	this.logosback.parent = this;
	this.logosback.setTransform(-494.75,54.85,0.3006,0.3004,0,0,0,307.2,45.1);

	this.timeline.addTween(cjs.Tween.get(this.logosback).wait(1).to({regX:249.8,regY:257.3,x:-504,y:118.6},0).wait(1).to({x:-496.05,y:118.65},0).wait(1).to({x:-488.05,y:118.7},0).wait(1).to({x:-480.1},0).wait(1).to({x:-472.1,y:118.75},0).wait(1).to({x:-464.15,y:118.8},0).wait(1).to({x:-456.2,y:118.85},0).wait(1).to({x:-448.2},0).wait(1).to({x:-440.25,y:118.9},0).wait(1).to({x:-432.25,y:118.95},0).wait(1).to({x:-424.3},0).wait(1).to({x:-416.35,y:119},0).wait(1).to({x:-408.35,y:119.05},0).wait(1).to({x:-400.4,y:119.1},0).wait(1).to({x:-392.4},0).wait(1).to({x:-384.45,y:119.15},0).wait(1).to({x:-376.45,y:119.2},0).wait(1).to({x:-368.5,y:119.25},0).wait(1).to({x:-360.55},0).wait(1).to({x:-352.55,y:119.3},0).wait(1).to({x:-344.6,y:119.35},0).wait(1).to({x:-336.6},0).wait(1).to({x:-328.65,y:119.4},0).wait(1).to({x:-320.7,y:119.45},0).wait(1).to({x:-312.7,y:119.5},0).wait(1).to({x:-304.75},0).wait(1).to({x:-296.75,y:119.55},0).wait(1).to({x:-288.8,y:119.6},0).wait(1).to({x:-280.85,y:119.65},0).wait(1).to({x:-272.85},0).wait(1).to({x:-264.9,y:119.7},0).wait(1).to({x:-256.9,y:119.75},0).wait(1).to({x:-248.95},0).wait(1).to({x:-240.95,y:119.8},0).wait(1).to({x:-233,y:119.85},0).wait(1).to({x:-225.05,y:119.9},0).wait(1).to({x:-217.05},0).wait(1).to({x:-209.1,y:119.95},0).wait(1).to({x:-201.1,y:120},0).wait(1).to({x:-193.15,y:120.05},0).wait(1).to({x:-185.2},0).wait(1).to({x:-177.2,y:120.1},0).wait(1).to({x:-169.25,y:120.15},0).wait(1).to({x:-161.25},0).wait(1).to({x:-153.3,y:120.2},0).wait(1).to({x:-145.35,y:120.25},0).wait(1).to({x:-137.35,y:120.3},0).wait(1).to({x:-129.4},0).wait(1).to({x:-121.4,y:120.35},0).wait(1).to({x:-113.45,y:120.4},0).wait(1).to({x:-105.45,y:120.45},0).wait(1).to({x:-97.5},0).wait(1).to({x:-89.55,y:120.5},0).wait(1).to({x:-81.55,y:120.55},0).wait(1).to({x:-73.6},0).wait(1).to({x:-65.65,y:120.6},0).wait(1).to({x:-57.65,y:120.65},0).wait(1).to({x:-49.7,y:120.7},0).wait(1).to({x:-41.7},0).wait(1).to({x:-33.75,y:120.75},0).wait(1).to({x:-25.75,y:120.8},0).wait(1).to({x:-17.8,y:120.85},0).wait(1).to({x:-9.85},0).wait(1).to({x:-1.85,y:120.9},0).wait(1).to({x:6.1,y:120.95},0).wait(1).to({x:14.1},0).wait(1).to({x:22.05,y:121},0).wait(1).to({x:30.05,y:121.05},0).wait(1).to({x:38,y:121.1},0).wait(1).to({x:45.95},0).wait(1).to({x:53.95,y:121.15},0).wait(1).to({x:61.9,y:121.2},0).wait(1).to({x:69.9,y:121.25},0).wait(1).to({x:77.8},0).wait(1).to({x:85.75,y:121.3},0).wait(1).to({x:93.75,y:121.35},0).wait(1).to({x:101.7},0).wait(1).to({x:109.7,y:121.4},0).wait(1).to({x:117.65,y:121.45},0).wait(1).to({x:125.6,y:121.5},0).wait(1).to({x:133.6},0).wait(1).to({x:141.55,y:121.55},0).wait(1).to({x:149.55,y:121.6},0).wait(1).to({x:157.5,y:121.65},0).wait(1).to({x:165.5},0).wait(1).to({x:173.45,y:121.7},0).wait(1).to({x:181.4,y:121.75},0).wait(1).to({x:189.4},0).wait(1).to({x:197.35,y:121.8},0).wait(1).to({x:205.35,y:121.85},0).wait(1).to({x:213.3,y:121.9},0).wait(1).to({x:221.25},0).wait(1).to({x:229.25,y:121.95},0).wait(1).to({x:237.2,y:122},0).wait(1).to({x:245.2,y:122.05},0).wait(1).to({x:253.15},0).wait(1).to({x:261.1,y:122.1},0).wait(1).to({x:269.1,y:122.15},0).wait(1).to({x:277.05},0).wait(1).to({x:285.05,y:122.2},0).wait(1).to({x:293,y:122.25},0).wait(1).to({x:301,y:122.3},0).wait(1).to({x:308.95},0).wait(1).to({x:316.9,y:122.35},0).wait(1).to({x:324.9,y:122.4},0).wait(1).to({x:332.85,y:122.45},0).wait(1).to({x:340.85},0).wait(1).to({x:348.8,y:122.5},0).wait(1).to({x:356.75,y:122.55},0).wait(1).to({x:364.75},0).wait(1).to({x:372.7,y:122.6},0).wait(1).to({x:380.65,y:122.65},0).wait(1).to({x:388.65,y:122.7},0).wait(1).to({x:396.6},0).wait(1).to({x:404.6,y:122.75},0).wait(1).to({x:412.55,y:122.8},0).wait(1).to({x:420.55,y:122.85},0).wait(1).to({x:428.5},0).wait(1).to({x:436.5,y:122.9},0).wait(1).to({x:444.45,y:122.95},0).wait(1).to({x:452.4},0).wait(1).to({x:460.4,y:123},0).wait(1).to({x:468.35,y:123.05},0).wait(1).to({x:476.3,y:123.1},0).wait(1).to({x:484.3},0).wait(1).to({x:492.25,y:123.15},0).wait(1).to({x:500.25,y:123.2},0).wait(1).to({x:508.2,y:123.25},0).wait(1).to({x:516.15},0).wait(1).to({x:524.15,y:123.3},0).wait(1).to({x:532.1,y:123.35},0).wait(1).to({x:540.1},0).wait(1).to({x:548.05,y:123.4},0).wait(1).to({x:556.05,y:123.45},0).wait(1).to({x:564,y:123.5},0).wait(1).to({x:572},0).wait(1).to({x:579.95,y:123.55},0).wait(1).to({x:587.9,y:123.6},0).wait(1).to({x:595.9,y:123.65},0).wait(1).to({x:603.85},0).wait(1).to({x:611.8,y:123.7},0).wait(1).to({x:619.8,y:123.75},0).wait(1).to({x:627.75},0).wait(1).to({x:635.75,y:123.8},0).wait(1).to({x:643.7,y:123.85},0).wait(1).to({x:651.7,y:123.9},0).wait(1).to({x:659.65},0).wait(1).to({x:667.6,y:123.95},0).wait(1).to({x:675.6,y:124},0).wait(1).to({x:683.55,y:124.05},0).wait(1).to({x:691.55},0).wait(1).to({x:699.5,y:124.1},0).wait(1).to({x:707.45,y:124.15},0).wait(1).to({x:715.45},0).wait(1).to({x:723.4,y:124.2},0).wait(1).to({x:731.4,y:124.25},0).wait(1).to({x:739.35,y:124.3},0).wait(1).to({x:747.3},0).wait(1).to({x:755.3,y:124.35},0).wait(1).to({x:763.25,y:124.4},0).wait(1).to({x:771.25,y:124.45},0).wait(1).to({x:779.2},0).wait(1).to({x:787.2,y:124.5},0).wait(1).to({x:795.15,y:124.55},0).wait(1).to({x:803.1},0).wait(1).to({x:811.1,y:124.6},0).wait(1).to({x:819.05,y:124.65},0).wait(1).to({x:827.05,y:124.7},0).wait(1).to({x:835},0).wait(1).to({x:843,y:124.75},0).wait(1).to({x:850.95,y:124.8},0).wait(1).to({x:858.9,y:124.85},0).wait(1).to({x:866.9},0).wait(1).to({x:874.85,y:124.9},0).wait(1).to({x:882.85,y:124.95},0).wait(1).to({x:890.8},0).wait(1).to({x:898.75,y:125},0).wait(1).to({x:906.75,y:125.05},0).wait(1).to({x:914.7,y:125.1},0).wait(1).to({x:922.7},0).wait(1).to({x:930.65,y:125.15},0).wait(1).to({x:938.6,y:125.2},0).wait(1).to({x:946.6,y:125.25},0).wait(1).to({x:954.55},0).wait(1).to({x:962.55,y:125.3},0).wait(1).to({x:970.5,y:125.35},0).wait(1).to({x:978.5},0).wait(1).to({x:986.45,y:125.4},0).wait(1).to({x:994.4,y:125.45},0).wait(1).to({x:1002.4,y:125.5},0).wait(1).to({x:1010.35},0).wait(1).to({x:1018.3,y:125.55},0).wait(1).to({x:1026.3,y:125.6},0).wait(1).to({x:1034.25,y:125.65},0).wait(1).to({x:1042.25},0).wait(1).to({x:1050.2,y:125.7},0).wait(1).to({x:1058.2,y:125.75},0).wait(1).to({x:1066.15},0).wait(1).to({x:1074.1,y:125.8},0).wait(1).to({x:1082.1,y:125.85},0).wait(1).to({x:1090.05,y:125.9},0).wait(1).to({x:1098.05},0).wait(1).to({x:1106,y:125.95},0).wait(1).to({x:1114,y:126},0).wait(1).to({x:1121.95,y:126.05},0).wait(1).to({x:1129.9},0).wait(1).to({x:1137.9,y:126.1},0).wait(1).to({x:1145.85,y:126.15},0).wait(1).to({x:1153.8},0).wait(1).to({x:1161.8,y:126.2},0).wait(1).to({x:1169.75,y:126.25},0).wait(1).to({x:1177.75,y:126.3},0).wait(1).to({x:1185.7},0).wait(1).to({x:1193.7,y:126.35},0).wait(1).to({x:1201.65,y:126.4},0).wait(1).to({x:1209.6,y:126.45},0).wait(1).to({x:1217.6},0).wait(1).to({x:1225.55,y:126.5},0).wait(1).to({x:1233.55,y:126.55},0).wait(1).to({x:1241.5},0).wait(1).to({x:1250.1,y:130.5},0).wait(1).to({x:1258.7,y:134.4},0).wait(1).to({x:1267.3,y:138.35},0).wait(1).to({x:1275.9,y:142.25},0).wait(1).to({x:1284.5,y:146.2},0).wait(1).to({x:1293.05,y:150.1},0).to({_off:true},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-222,174.8,1882,1060.4);
// library properties:
lib.properties = {
	id: 'ACDE9F99630047F197000D061E6E426B',
	width: 960,
	height: 560,
	fps: 24,
	color: "#3DA8F3",
	opacity: 1.00,
	manifest: [
		{src:"images/AmazonInvazion_atlas_.png", id:"AmazonInvazion_atlas_"},
		{src:"sounds/gamemusic.mp3", id:"gamemusic"},
		{src:"sounds/letsplay.mp3", id:"letsplay"},
		{src:"sounds/button.mp3", id:"button"},
		{src:"sounds/books.mp3", id:"books"},
		{src:"sounds/amazonstart.mp3", id:"amazonstart"},
		{src:"sounds/likeamazon.mp3", id:"likeamazon"},
		{src:"sounds/pageturn.mp3", id:"pageturn"},
		{src:"sounds/shoes.mp3", id:"shoes"},
		{src:"sounds/bags.mp3", id:"bags"},
		{src:"sounds/acquisition.mp3", id:"acquisition"},
		{src:"sounds/worldtakeover.mp3", id:"worldtakeover"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['ACDE9F99630047F197000D061E6E426B'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;